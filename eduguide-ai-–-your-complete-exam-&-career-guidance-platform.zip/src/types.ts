export type ExamCategory =
  | "Engineering Exams"
  | "Medical Exams"
  | "Government Exams"
  | "Banking Exams"
  | "Railway Exams"
  | "Police and Defence Exams"
  | "Technology Exams"
  | "Study Abroad Exams";

export interface ExamSection {
  name: string;
  questions: number;
  marks: number;
  durationMinutes?: number;
}

export interface ExamPattern {
  mode: string;
  duration: string;
  totalQuestions: number;
  totalMarks: number;
  markingScheme: string;
  negativeMarking: string;
  stages?: string[];
  sections: ExamSection[];
}

export interface SyllabusSubject {
  subject: string;
  weightage?: string;
  topics: string[];
}

export interface ApplicationFee {
  general: string;
  reserved: string;
  female?: string;
  paymentModes: string[];
}

export interface ImportantDates {
  applicationStart: string;
  applicationEnd: string;
  admitCardDate: string;
  examDate: string;
  resultDate: string;
  cycleYear: string;
}

export interface RequiredDocument {
  name: string;
  specifications: string;
  fileFormat: string;
  maxSize: string;
  isMandatory: boolean;
}

export interface StepByStepGuidance {
  registrationProcess: string[];
  requiredDocuments: RequiredDocument[];
  formFillingSteps: string[];
  uploadInstructions: string[];
  paymentProcess: string[];
  finalSubmissionChecklist: string[];
  officialVerificationNotice: string;
}

export interface LearningResource {
  id: string;
  title: string;
  type: "strategy" | "syllabus" | "subject" | "pyq" | "application_walkthrough" | "application";
  subject?: string;
  duration: string;
  instructorOrChannel: string;
  videoUrl: string;
  thumbnailGradient: string;
  keyTakeaways: string[];
  viewsCount?: string;
}

export interface Exam {
  id: string;
  name: string;
  fullName: string;
  slug: string;
  category: ExamCategory;
  shortDescription: string;
  overview: string;
  eligibilityLevel: string;
  ageLimit: {
    minAge: number;
    maxAge: number;
    relaxation: string;
  };
  educationalQualification: string[];
  attemptsAllowed: string;
  examPattern: ExamPattern;
  syllabus: SyllabusSubject[];
  importantTopics: string[];
  applicationFee: ApplicationFee;
  officialConductingBody: string;
  officialWebsite: string;
  isOfficialVerified: boolean;
  upcomingImportantDate: {
    label: string;
    date: string;
    type: "registration" | "admitCard" | "exam" | "result";
    isUrgent?: boolean;
  };
  importantDates: ImportantDates;
  stepByStepGuidance: StepByStepGuidance;
  learningResources: LearningResource[];
  tags: string[];
  trending: boolean;
  salaryOrPerks?: string;
  careerProspects: string[];
}

export interface StudentProfile {
  id?: string;
  name: string;
  email: string;
  educationLevel: string;
  degreeOrBranch: string;
  targetYear?: string;
  interests?: string[];
  careerGoals?: string;
  targetExams: string[];
  preferredCategories?: ExamCategory[];
  savedExams: string[]; // exam ids
  reminders?: ExamReminder[];
  notificationPreferences: {
    deadlineAlerts: boolean;
    admitCardAlerts: boolean;
    resultAlerts?: boolean;
    newExamAnnouncements: boolean;
  };
}

export interface ExamReminder {
  id: string;
  examId: string;
  examName: string;
  eventTitle: string;
  eventDate: string;
  eventType: "registration" | "admitCard" | "exam" | "result";
  remindBeforeDays: number;
  isCompleted?: boolean;
}

export interface StudyPlan {
  id: string;
  examId: string;
  examName: string;
  timeframe: string;
  dailyStudyHours: string;
  createdAt: string;
  dailySchedule: {
    slot: string;
    duration: string;
    activity: string;
    focus: string;
  }[];
  phases: {
    phase: string;
    duration: string;
    title: string;
    keyObjectives: string[];
    milestone: string;
  }[];
  highYieldTopics: string[];
  weeklyMilestones: {
    week: string;
    deliverable: string;
    targetMockScore: string;
  }[];
}

export interface AIGuidanceResponse {
  summary: string;
  recommendedExams: {
    examName: string;
    category: string;
    matchPercentage: number;
    rationale: string;
    eligibilityAnalysis: string;
    careerScope: string;
    preparationRunway: string;
  }[];
  nextSteps: string[];
  expertAdvice: string;
}

export interface NotificationItem {
  id: string;
  examId?: string;
  title: string;
  message: string;
  date: string;
  type: "urgent" | "update" | "admit_card" | "result" | "announcement";
  read: boolean;
  linkText?: string;
  actionUrl?: string;
}
