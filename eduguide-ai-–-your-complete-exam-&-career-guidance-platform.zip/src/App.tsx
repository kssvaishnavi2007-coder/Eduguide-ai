import React, { useState, useEffect } from "react";
import { Navbar } from "./components/Navbar";
import { HomeView } from "./components/HomeView";
import { ExploreExamsView } from "./components/ExploreExamsView";
import { ExamDetailView } from "./components/ExamDetailView";
import { TimelineView } from "./components/TimelineView";
import { AIAssistantView } from "./components/AIAssistantView";
import { StudyPlannerView } from "./components/StudyPlannerView";
import { LearningHubView } from "./components/LearningHubView";
import { DashboardView } from "./components/DashboardView";
import { SearchModal } from "./components/SearchModal";
import { NotificationModal } from "./components/NotificationModal";
import { VideoModal } from "./components/VideoModal";

import {
  Exam,
  ExamCategory,
  StudentProfile,
  StudyPlan,
  ExamReminder,
  NotificationItem,
  LearningResource,
} from "./types";
import { EXAMS_DATABASE, MOCK_NOTIFICATIONS } from "./data/examsData";
import {
  GraduationCap,
  ShieldCheck,
  Sparkles,
  Heart,
  ExternalLink,
  Compass,
  Calendar,
  BookOpen,
  Video,
} from "lucide-react";

export default function App() {
  // Navigation State
  const [currentTab, setCurrentTab] = useState<string>("home");
  const [selectedCategory, setSelectedCategory] = useState<ExamCategory | "All">("All");
  const [selectedExam, setSelectedExam] = useState<Exam | null>(null);

  // Saved Exams (Bookmark) State
  const [savedExamIds, setSavedExamIds] = useState<string[]>(() => {
    const saved = localStorage.getItem("eduguide_saved_exams");
    return saved ? JSON.parse(saved) : ["jee-main", "gate-cse", "upsc-cse"];
  });

  // Reminders State
  const [reminders, setReminders] = useState<ExamReminder[]>(() => {
    const saved = localStorage.getItem("eduguide_reminders");
    return saved
      ? JSON.parse(saved)
      : [
          {
            id: "rem-1",
            examId: "jee-main",
            examName: "JEE Main 2026",
            eventTitle: "JEE Main - Session 1 Registration Closing",
            eventDate: "2026-03-05",
            eventType: "registration",
            remindBeforeDays: 3,
          },
          {
            id: "rem-2",
            examId: "upsc-cse",
            examName: "UPSC CSE 2026",
            eventTitle: "UPSC CSE - Preliminary Examination Day",
            eventDate: "2026-05-24",
            eventType: "exam",
            remindBeforeDays: 7,
          },
        ];
  });

  // Student Profile State
  const [profile, setProfile] = useState<StudentProfile>(() => {
    const saved = localStorage.getItem("eduguide_profile");
    return saved
      ? JSON.parse(saved)
      : {
          id: "student-user-1",
          name: "Aman Sharma",
          email: "aman.student@eduguide.ai",
          educationLevel: "Undergraduate (B.Tech)",
          degreeOrBranch: "Computer Science & Engineering",
          targetExams: ["GATE CSE", "UPSC CSE", "AWS Solutions"],
          savedExams: ["jee-main", "gate-cse", "upsc-cse"],
          notificationPreferences: {
            deadlineAlerts: true,
            admitCardAlerts: true,
            newExamAnnouncements: true,
          },
        };
  });

  // Active Study Plan State
  const [activeStudyPlan, setActiveStudyPlan] = useState<StudyPlan | null>(() => {
    const saved = localStorage.getItem("eduguide_active_study_plan");
    return saved ? JSON.parse(saved) : null;
  });

  // Notifications State
  const [notifications, setNotifications] = useState<NotificationItem[]>(MOCK_NOTIFICATIONS);

  // Modals State
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [isNotificationsOpen, setIsNotificationsOpen] = useState(false);
  const [activeVideoModalResource, setActiveVideoModalResource] = useState<LearningResource | null>(null);

  // AI Guidance Prompt Transfer
  const [aiPromptData, setAiPromptData] = useState<{
    educationLevel: string;
    degreeOrBranch: string;
    interests: string;
    careerGoals: string;
  } | null>(null);

  // Planner Preselected Exam
  const [plannerPreselectedExam, setPlannerPreselectedExam] = useState<Exam | null>(null);

  // Sync state to local storage
  useEffect(() => {
    localStorage.setItem("eduguide_saved_exams", JSON.stringify(savedExamIds));
  }, [savedExamIds]);

  useEffect(() => {
    localStorage.setItem("eduguide_reminders", JSON.stringify(reminders));
  }, [reminders]);

  useEffect(() => {
    localStorage.setItem("eduguide_profile", JSON.stringify(profile));
  }, [profile]);

  useEffect(() => {
    if (activeStudyPlan) {
      localStorage.setItem("eduguide_active_study_plan", JSON.stringify(activeStudyPlan));
    }
  }, [activeStudyPlan]);

  // Handlers
  const handleToggleSaveExam = (examId: string) => {
    setSavedExamIds((prev) => {
      const next = prev.includes(examId) ? prev.filter((id) => id !== examId) : [...prev, examId];
      setProfile((p) => ({ ...p, savedExams: next }));
      return next;
    });
  };

  const handleAddReminder = (reminderData: Omit<ExamReminder, "id">) => {
    const newRem: ExamReminder = {
      ...reminderData,
      id: `rem-${Date.now()}`,
    };
    setReminders((prev) => [...prev, newRem]);
  };

  const handleDeleteReminder = (reminderId: string) => {
    setReminders((prev) => prev.filter((r) => r.id !== reminderId));
  };

  const handleSelectExam = (exam: Exam) => {
    setSelectedExam(exam);
    setCurrentTab("exam-detail");
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const handleSelectCategoryFromHome = (category: ExamCategory) => {
    setSelectedCategory(category);
    setCurrentTab("explore");
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const handleLaunchStudyPlannerForExam = (exam: Exam) => {
    setPlannerPreselectedExam(exam);
    setCurrentTab("planner");
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const handleStartAIGuidanceWithPrompt = (promptData: {
    educationLevel: string;
    degreeOrBranch: string;
    interests: string;
    careerGoals: string;
  }) => {
    setAiPromptData(promptData);
    setCurrentTab("ai-assistant");
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const handleMarkAllNotificationsRead = () => {
    setNotifications((prev) => prev.map((n) => ({ ...n, read: true })));
  };

  const handleSelectExamById = (examId: string) => {
    const target = EXAMS_DATABASE.find((e) => e.id === examId);
    if (target) {
      handleSelectExam(target);
    }
  };

  const unreadNotificationsCount = notifications.filter((n) => !n.read).length;

  return (
    <div className="min-h-screen flex flex-col bg-slate-50/70 text-slate-900 font-['Plus_Jakarta_Sans',sans-serif] antialiased selection:bg-blue-600 selection:text-white">
      {/* Top Navbar Component */}
      <Navbar
        currentTab={currentTab}
        setCurrentTab={(tab) => {
          setCurrentTab(tab);
          if (tab !== "exam-detail") setSelectedExam(null);
          window.scrollTo({ top: 0, behavior: "smooth" });
        }}
        savedExamsCount={savedExamIds.length}
        unreadNotificationsCount={unreadNotificationsCount}
        onOpenSearch={() => setIsSearchOpen(true)}
        onOpenNotifications={() => setIsNotificationsOpen(true)}
      />

      {/* Main Content Router / View Switcher */}
      <main className="flex-1">
        {currentTab === "home" && (
          <HomeView
            exams={EXAMS_DATABASE}
            onSelectExam={handleSelectExam}
            onNavigateToTab={(tab) => {
              setCurrentTab(tab);
              window.scrollTo({ top: 0, behavior: "smooth" });
            }}
            onSelectCategory={handleSelectCategoryFromHome}
            savedExamIds={savedExamIds}
            onToggleSaveExam={handleToggleSaveExam}
            onStartAIGuidanceWithPrompt={handleStartAIGuidanceWithPrompt}
          />
        )}

        {currentTab === "explore" && (
          <ExploreExamsView
            exams={EXAMS_DATABASE}
            selectedCategory={selectedCategory}
            onSelectCategory={setSelectedCategory}
            onSelectExam={handleSelectExam}
            savedExamIds={savedExamIds}
            onToggleSaveExam={handleToggleSaveExam}
          />
        )}

        {currentTab === "exam-detail" && selectedExam && (
          <ExamDetailView
            exam={selectedExam}
            onBack={() => {
              setCurrentTab("explore");
              window.scrollTo({ top: 0, behavior: "smooth" });
            }}
            isSaved={savedExamIds.includes(selectedExam.id)}
            onToggleSave={handleToggleSaveExam}
            onAddReminder={handleAddReminder}
            onLaunchStudyPlannerForExam={handleLaunchStudyPlannerForExam}
            onOpenVideoModal={(res) => setActiveVideoModalResource(res)}
          />
        )}

        {currentTab === "timeline" && (
          <TimelineView
            exams={EXAMS_DATABASE}
            savedExamIds={savedExamIds}
            reminders={reminders}
            onAddReminder={handleAddReminder}
            onDeleteReminder={handleDeleteReminder}
            onSelectExam={handleSelectExam}
          />
        )}

        {currentTab === "ai-assistant" && (
          <AIAssistantView
            exams={EXAMS_DATABASE}
            onSelectExam={handleSelectExam}
            onLaunchStudyPlannerForExam={handleLaunchStudyPlannerForExam}
            initialPromptData={aiPromptData}
          />
        )}

        {currentTab === "planner" && (
          <StudyPlannerView
            exams={EXAMS_DATABASE}
            activeStudyPlan={activeStudyPlan}
            onSaveStudyPlan={(plan) => setActiveStudyPlan(plan)}
            targetExamPreselected={plannerPreselectedExam}
          />
        )}

        {currentTab === "learning" && (
          <LearningHubView
            exams={EXAMS_DATABASE}
            onOpenVideoModal={(res) => setActiveVideoModalResource(res)}
            onSelectExam={handleSelectExam}
          />
        )}

        {currentTab === "dashboard" && (
          <DashboardView
            exams={EXAMS_DATABASE}
            profile={profile}
            onUpdateProfile={(p) => setProfile(p)}
            savedExamIds={savedExamIds}
            onToggleSaveExam={handleToggleSaveExam}
            onSelectExam={handleSelectExam}
            reminders={reminders}
            onDeleteReminder={handleDeleteReminder}
            activeStudyPlan={activeStudyPlan}
            onNavigateToTab={(tab) => {
              setCurrentTab(tab);
              window.scrollTo({ top: 0, behavior: "smooth" });
            }}
            onLaunchStudyPlannerForExam={handleLaunchStudyPlannerForExam}
          />
        )}
      </main>

      {/* Global Modals */}
      <SearchModal
        isOpen={isSearchOpen}
        onClose={() => setIsSearchOpen(false)}
        exams={EXAMS_DATABASE}
        onSelectExam={handleSelectExam}
        onNavigateToCategory={(cat) => {
          setSelectedCategory(cat as any);
          setCurrentTab("explore");
        }}
      />

      <NotificationModal
        isOpen={isNotificationsOpen}
        onClose={() => setIsNotificationsOpen(false)}
        notifications={notifications}
        profile={profile}
        onUpdateProfile={(p) => setProfile(p)}
        onMarkAllAsRead={handleMarkAllNotificationsRead}
        onSelectExamById={handleSelectExamById}
      />

      <VideoModal
        resource={activeVideoModalResource}
        onClose={() => setActiveVideoModalResource(null)}
      />

      {/* Footer */}
      <footer className="bg-slate-900 text-slate-400 text-xs border-t border-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8">
            {/* Brand column */}
            <div className="lg:col-span-2 space-y-3">
              <div className="flex items-center gap-2 text-white">
                <div className="w-8 h-8 rounded-lg bg-blue-600 flex items-center justify-center font-bold">
                  <GraduationCap className="w-5 h-5 text-white" />
                </div>
                <span className="text-lg font-bold font-['Outfit',sans-serif]">EduGuide AI</span>
              </div>
              <p className="text-slate-400 text-xs leading-relaxed max-w-sm">
                “One Platform. Every Exam. Complete Guidance.”
                Centralized knowledge repository, AI career mentorship, and smart timeline synchronization for all national & international competitive examinations.
              </p>
              <div className="flex items-center gap-2 text-emerald-400 text-[11px] pt-1">
                <ShieldCheck className="w-4 h-4" />
                <span>Information verified directly against official conducting authority circulars.</span>
              </div>
            </div>

            {/* Quick Navigation */}
            <div className="space-y-2.5">
              <h4 className="font-bold text-white text-xs uppercase tracking-wider">Core Navigation</h4>
              <ul className="space-y-1.5 text-slate-400">
                <li>
                  <button onClick={() => setCurrentTab("home")} className="hover:text-white transition-colors">
                    Home
                  </button>
                </li>
                <li>
                  <button onClick={() => setCurrentTab("explore")} className="hover:text-white transition-colors">
                    Explore 100+ Exams
                  </button>
                </li>
                <li>
                  <button onClick={() => setCurrentTab("timeline")} className="hover:text-white transition-colors">
                    Smart Exam Timeline
                  </button>
                </li>
                <li>
                  <button onClick={() => setCurrentTab("planner")} className="hover:text-white transition-colors">
                    AI Study Planner
                  </button>
                </li>
                <li>
                  <button onClick={() => setCurrentTab("learning")} className="hover:text-white transition-colors">
                    Learning Video Hub
                  </button>
                </li>
                <li>
                  <button onClick={() => setCurrentTab("dashboard")} className="hover:text-white transition-colors">
                    Student Dashboard
                  </button>
                </li>
              </ul>
            </div>

            {/* Exam Categories */}
            <div className="space-y-2.5">
              <h4 className="font-bold text-white text-xs uppercase tracking-wider">Exam Disciplines</h4>
              <ul className="space-y-1.5 text-slate-400">
                {["Engineering Exams", "Medical Exams", "Government Exams", "Banking Exams", "Railway Exams", "Police & Defence"].map((cat) => (
                  <li key={cat}>
                    <button
                      onClick={() => {
                        setSelectedCategory(cat as any);
                        setCurrentTab("explore");
                      }}
                      className="hover:text-white transition-colors"
                    >
                      {cat}
                    </button>
                  </li>
                ))}
              </ul>
            </div>

            {/* Verification and Portal Compliance */}
            <div className="space-y-2.5">
              <h4 className="font-bold text-white text-xs uppercase tracking-wider">Compliance & Sources</h4>
              <p className="text-[11px] text-slate-400 leading-relaxed">
                Always verify dates and application instructions with the official portal links provided on each exam profile.
              </p>
              <div className="p-3 bg-white/5 rounded-xl border border-white/10 space-y-1 text-[11px]">
                <div className="text-white font-semibold flex items-center gap-1">
                  <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
                  <span>Powered by Gemini AI</span>
                </div>
                <p className="text-slate-400">Real-time intelligent exam recommendations and roadmap synthesis.</p>
              </div>
            </div>
          </div>

          <div className="pt-8 border-t border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-4 text-[11px] text-slate-500">
            <div>
              © 2026-2027 EduGuide AI. All rights reserved. Built for competitive exam aspirants.
            </div>
            <div className="flex items-center gap-4">
              <span>Privacy Policy</span>
              <span>•</span>
              <span>Terms of Service</span>
              <span>•</span>
              <span>Official Portals Sync</span>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
