import React, { useState, useMemo } from "react";
import {
  Calendar,
  Clock,
  Filter,
  Bookmark,
  Bell,
  CheckCircle2,
  AlertTriangle,
  ArrowRight,
  Download,
  Plus,
  Trash2,
  Sparkles,
  ShieldCheck,
} from "lucide-react";
import { Exam, ExamCategory, ExamReminder } from "../types";
import { EXAM_CATEGORIES } from "../data/examsData";

interface TimelineViewProps {
  exams: Exam[];
  savedExamIds: string[];
  reminders: ExamReminder[];
  onAddReminder: (reminder: Omit<ExamReminder, "id">) => void;
  onDeleteReminder: (reminderId: string) => void;
  onSelectExam: (exam: Exam) => void;
}

interface TimelineEvent {
  id: string;
  examId: string;
  examName: string;
  category: ExamCategory;
  title: string;
  date: string;
  type: "registration" | "admitCard" | "exam" | "result";
  isUrgent?: boolean;
}

export const TimelineView: React.FC<TimelineViewProps> = ({
  exams,
  savedExamIds,
  reminders,
  onAddReminder,
  onDeleteReminder,
  onSelectExam,
}) => {
  const [filterMode, setFilterMode] = useState<"all" | "saved">("all");
  const [selectedCategory, setSelectedCategory] = useState<ExamCategory | "All">("All");
  const [selectedEventType, setSelectedEventType] = useState<string>("All");
  const [showAddReminderModal, setShowAddReminderModal] = useState(false);
  const [customReminderExamId, setCustomReminderExamId] = useState(exams[0]?.id || "");
  const [customEventTitle, setCustomEventTitle] = useState("");
  const [customEventDate, setCustomEventDate] = useState("");
  const [customEventType, setCustomEventType] = useState<ExamReminder["eventType"]>("registration");
  const [customLeadDays, setCustomLeadDays] = useState(3);
  const [notificationStatus, setNotificationStatus] = useState<string | null>(null);

  // Flatten all exams into chronological timeline events
  const timelineEvents = useMemo(() => {
    const events: TimelineEvent[] = [];

    const sourceExams = filterMode === "saved"
      ? exams.filter((e) => savedExamIds.includes(e.id))
      : exams;

    sourceExams.forEach((exam) => {
      // 1. Application Open
      events.push({
        id: `${exam.id}-app-start`,
        examId: exam.id,
        examName: exam.name,
        category: exam.category,
        title: "Application Registration Opens",
        date: exam.importantDates.applicationStart,
        type: "registration",
      });

      // 2. Application Deadline
      events.push({
        id: `${exam.id}-app-end`,
        examId: exam.id,
        examName: exam.name,
        category: exam.category,
        title: "Registration Closing Deadline",
        date: exam.importantDates.applicationEnd,
        type: "registration",
        isUrgent: true,
      });

      // 3. Admit Card Release
      events.push({
        id: `${exam.id}-admit`,
        examId: exam.id,
        examName: exam.name,
        category: exam.category,
        title: "Admit Card / Hall Ticket Release",
        date: exam.importantDates.admitCardDate,
        type: "admitCard",
      });

      // 4. Exam Day
      events.push({
        id: `${exam.id}-exam-day`,
        examId: exam.id,
        examName: exam.name,
        category: exam.category,
        title: "Examination Day",
        date: exam.importantDates.examDate,
        type: "exam",
      });

      // 5. Result Date
      events.push({
        id: `${exam.id}-result`,
        examId: exam.id,
        examName: exam.name,
        category: exam.category,
        title: "Result & Cutoff Announcement",
        date: exam.importantDates.resultDate,
        type: "result",
      });
    });

    return events
      .filter((ev) => {
        const matchesCategory = selectedCategory === "All" || ev.category === selectedCategory;
        const matchesType = selectedEventType === "All" || ev.type === selectedEventType;
        return matchesCategory && matchesType;
      })
      .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
  }, [exams, filterMode, savedExamIds, selectedCategory, selectedEventType]);

  const handleCreateCustomReminder = (e: React.FormEvent) => {
    e.preventDefault();
    const targetExam = exams.find((e) => e.id === customReminderExamId) || exams[0];
    onAddReminder({
      examId: targetExam.id,
      examName: targetExam.name,
      eventTitle: customEventTitle || `${targetExam.name} Milestone`,
      eventDate: customEventDate || "2026-04-15",
      eventType: customEventType,
      remindBeforeDays: customLeadDays,
    });
    setShowAddReminderModal(false);
    setNotificationStatus("Reminder successfully added!");
    setTimeout(() => setNotificationStatus(null), 3000);
  };

  const downloadICSFile = () => {
    let icsContent = "BEGIN:VCALENDAR\nVERSION:2.0\nPRODID:-//EduGuide AI//Exam Timeline//EN\n";
    timelineEvents.slice(0, 20).forEach((ev) => {
      const cleanDate = ev.date.replace(/-/g, "");
      icsContent += `BEGIN:VEVENT\nSUMMARY:${ev.examName} - ${ev.title}\nDESCRIPTION:Official competitive exam event organized via EduGuide AI.\nDTSTART;VALUE=DATE:${cleanDate}\nDTEND;VALUE=DATE:${cleanDate}\nEND:VEVENT\n`;
    });
    icsContent += "END:VCALENDAR";

    const blob = new Blob([icsContent], { type: "text/calendar;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.setAttribute("download", "eduguide-exam-schedule.ics");
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8 pb-24">
      {/* Header & Action */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-50 border border-blue-200 text-blue-700 text-xs font-semibold">
            <Calendar className="w-3.5 h-3.5" />
            <span>Smart Exam Timeline & Calendar Sync</span>
          </div>
          <h1 className="text-3xl sm:text-4xl font-extrabold text-slate-900 font-['Outfit',sans-serif] tracking-tight mt-1">
            Official Competitive Exam Schedule
          </h1>
          <p className="text-sm text-slate-600 max-w-2xl mt-1">
            Track key application opening dates, closing deadlines, admit card releases, and exam sessions. Never miss a single registration window.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            id="download-calendar-btn"
            onClick={downloadICSFile}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold text-slate-700 bg-white hover:bg-slate-50 border border-slate-200 shadow-xs transition-colors"
            title="Download iCal file for Google Calendar / Apple Calendar"
          >
            <Download className="w-4 h-4 text-blue-600" />
            <span>Export Calendar (.ICS)</span>
          </button>
          <button
            id="create-reminder-btn"
            onClick={() => setShowAddReminderModal(true)}
            className="flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold bg-blue-600 hover:bg-blue-700 text-white shadow-md shadow-blue-500/20 transition-all"
          >
            <Plus className="w-4 h-4" />
            <span>Custom Reminder</span>
          </button>
        </div>
      </div>

      {notificationStatus && (
        <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-xl text-xs font-semibold flex items-center gap-2 animate-in fade-in">
          <CheckCircle2 className="w-4 h-4 text-emerald-600" />
          {notificationStatus}
        </div>
      )}

      {/* Filter and Scope Bar */}
      <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          {/* Scope Toggle: All vs Saved Only */}
          <div className="flex items-center bg-slate-100 p-1 rounded-xl border border-slate-200">
            <button
              id="timeline-filter-all"
              onClick={() => setFilterMode("all")}
              className={`px-4 py-1.5 rounded-lg text-xs font-bold transition-all ${
                filterMode === "all"
                  ? "bg-white text-blue-700 shadow-xs"
                  : "text-slate-600 hover:text-slate-900"
              }`}
            >
              All Exams ({exams.length})
            </button>
            <button
              id="timeline-filter-saved"
              onClick={() => setFilterMode("saved")}
              className={`px-4 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 ${
                filterMode === "saved"
                  ? "bg-white text-blue-700 shadow-xs"
                  : "text-slate-600 hover:text-slate-900"
              }`}
            >
              <Bookmark className="w-3.5 h-3.5 fill-current" />
              <span>Saved Exams Only ({savedExamIds.length})</span>
            </button>
          </div>

          {/* Event Type Filter Pills */}
          <div className="flex flex-wrap items-center gap-1.5 text-xs">
            <span className="text-slate-400 font-medium mr-1">Event Type:</span>
            {[
              { id: "All", label: "All Events" },
              { id: "registration", label: "Application & Deadlines" },
              { id: "admitCard", label: "Admit Cards" },
              { id: "exam", label: "Exam Days" },
              { id: "result", label: "Results" },
            ].map((type) => (
              <button
                key={type.id}
                onClick={() => setSelectedEventType(type.id)}
                className={`px-2.5 py-1 rounded-md transition-colors ${
                  selectedEventType === type.id
                    ? "bg-blue-600 text-white font-semibold"
                    : "bg-slate-100 hover:bg-slate-200 text-slate-700"
                }`}
              >
                {type.label}
              </button>
            ))}
          </div>
        </div>

        {/* Category Pill Filters */}
        <div className="flex items-center gap-1.5 overflow-x-auto text-xs pt-2 border-t border-slate-100">
          <span className="text-slate-400 font-medium shrink-0">Category:</span>
          <button
            onClick={() => setSelectedCategory("All")}
            className={`shrink-0 px-2.5 py-1 rounded-md transition-colors ${
              selectedCategory === "All"
                ? "bg-indigo-100 text-indigo-800 font-bold border border-indigo-200"
                : "bg-slate-50 text-slate-600 hover:bg-slate-100 border border-slate-200"
            }`}
          >
            All Disciplines
          </button>
          {EXAM_CATEGORIES.map((c) => (
            <button
              key={c.id}
              onClick={() => setSelectedCategory(c.id)}
              className={`shrink-0 px-2.5 py-1 rounded-md transition-colors ${
                selectedCategory === c.id
                  ? "bg-indigo-100 text-indigo-800 font-bold border border-indigo-200"
                  : "bg-slate-50 text-slate-600 hover:bg-slate-100 border border-slate-200"
              }`}
            >
              {c.label}
            </button>
          ))}
        </div>
      </div>

      {/* Main Timeline Events Stream & Reminders Sidebar */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Chronological Stream (8 cols) */}
        <div className="lg:col-span-8 space-y-4">
          <div className="flex items-center justify-between text-xs text-slate-500 pb-1">
            <span>Chronological Event Stream ({timelineEvents.length} milestones)</span>
            <span className="text-blue-600 font-medium">Sorted by Upcoming Date</span>
          </div>

          {timelineEvents.length > 0 ? (
            <div className="relative pl-6 border-l-2 border-slate-200 space-y-6">
              {timelineEvents.map((ev) => {
                const targetExam = exams.find((e) => e.id === ev.examId);
                const hasReminder = reminders.some(
                  (r) => r.examId === ev.examId && r.eventDate === ev.date
                );

                return (
                  <div key={ev.id} className="relative group">
                    {/* Node Dot */}
                    <div
                      className={`absolute -left-[31px] top-4 w-4 h-4 rounded-full border-4 border-white shadow-xs ${
                        ev.type === "exam"
                          ? "bg-blue-600 ring-2 ring-blue-400"
                          : ev.isUrgent
                          ? "bg-rose-500 ring-2 ring-rose-400 animate-pulse"
                          : ev.type === "admitCard"
                          ? "bg-indigo-500"
                          : "bg-slate-400"
                      }`}
                    />

                    {/* Event Card */}
                    <div
                      className={`p-4 sm:p-5 rounded-2xl border transition-all ${
                        ev.isUrgent
                          ? "bg-rose-50/40 border-rose-200 hover:border-rose-300"
                          : ev.type === "exam"
                          ? "bg-blue-50/40 border-blue-200 hover:border-blue-300"
                          : "bg-white border-slate-200 hover:border-slate-300 shadow-xs"
                      }`}
                    >
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-2 border-b border-slate-100">
                        <div className="flex items-center gap-2">
                          <span
                            onClick={() => targetExam && onSelectExam(targetExam)}
                            className="text-base font-bold text-slate-900 hover:text-blue-600 cursor-pointer"
                          >
                            {ev.examName}
                          </span>
                          <span className="text-[10px] px-2 py-0.5 rounded-full bg-slate-100 text-slate-600 font-semibold">
                            {ev.category}
                          </span>
                          {ev.isUrgent && (
                            <span className="text-[10px] px-2 py-0.5 rounded-full bg-rose-100 text-rose-700 font-bold uppercase">
                              Deadline Approaching
                            </span>
                          )}
                        </div>

                        <div className="flex items-center gap-1.5 text-xs font-mono font-bold text-slate-800 bg-slate-50 px-2.5 py-1 rounded-lg border border-slate-200/80 self-start sm:self-auto">
                          <Calendar className="w-3.5 h-3.5 text-blue-600" />
                          <span>{ev.date}</span>
                        </div>
                      </div>

                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pt-3">
                        <div>
                          <p className="text-sm font-semibold text-slate-800">{ev.title}</p>
                          <p className="text-xs text-slate-500 mt-0.5">
                            Official milestone synchronized from {targetExam?.officialConductingBody || "Conducting Authority"}.
                          </p>
                        </div>

                        <div className="flex items-center gap-2 shrink-0">
                          {hasReminder ? (
                            <span className="inline-flex items-center gap-1 text-xs font-bold text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-lg border border-emerald-200">
                              <CheckCircle2 className="w-3.5 h-3.5" /> Reminder Set
                            </span>
                          ) : (
                            <button
                              onClick={() => {
                                onAddReminder({
                                  examId: ev.examId,
                                  examName: ev.examName,
                                  eventTitle: `${ev.examName} - ${ev.title}`,
                                  eventDate: ev.date,
                                  eventType: ev.type,
                                  remindBeforeDays: 3,
                                });
                                setNotificationStatus(`Reminder set for ${ev.examName} (${ev.title})`);
                                setTimeout(() => setNotificationStatus(null), 3000);
                              }}
                              className="px-3 py-1.5 bg-slate-100 hover:bg-blue-600 hover:text-white text-slate-700 text-xs font-semibold rounded-lg transition-colors flex items-center gap-1"
                            >
                              <Bell className="w-3.5 h-3.5" />
                              <span>Set Reminder</span>
                            </button>
                          )}

                          {targetExam && (
                            <button
                              onClick={() => onSelectExam(targetExam)}
                              className="p-1.5 text-slate-400 hover:text-blue-600 rounded-lg hover:bg-slate-100"
                              title="View Exam Profile"
                            >
                              <ArrowRight className="w-4 h-4" />
                            </button>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          ) : (
            <div className="bg-white rounded-2xl border border-slate-200 p-12 text-center space-y-3">
              <Calendar className="w-10 h-10 text-slate-300 mx-auto" />
              <h3 className="text-base font-bold text-slate-800">No events match your current filter</h3>
              <p className="text-xs text-slate-500">
                Switch from "Saved Exams Only" back to "All Exams" or reset category filters.
              </p>
              <button
                onClick={() => {
                  setFilterMode("all");
                  setSelectedCategory("All");
                  setSelectedEventType("All");
                }}
                className="px-4 py-1.5 bg-blue-600 text-white rounded-lg text-xs font-semibold"
              >
                Reset Filters
              </button>
            </div>
          )}
        </div>

        {/* Reminders & Alerts Manager Sidebar (4 cols) */}
        <div className="lg:col-span-4 space-y-6">
          {/* Active Reminders Card */}
          <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <span className="p-1.5 rounded-lg bg-blue-50 text-blue-600">
                  <Bell className="w-4 h-4" />
                </span>
                <h3 className="text-sm font-bold text-slate-900 font-['Outfit',sans-serif]">
                  My Active Reminders ({reminders.length})
                </h3>
              </div>
            </div>

            {reminders.length > 0 ? (
              <div className="space-y-2.5 max-h-96 overflow-y-auto">
                {reminders.map((rem) => (
                  <div
                    key={rem.id}
                    className="p-3 bg-slate-50 rounded-xl border border-slate-200/80 flex items-start justify-between gap-2"
                  >
                    <div>
                      <h4 className="text-xs font-bold text-slate-900">{rem.eventTitle}</h4>
                      <div className="flex items-center gap-2 mt-1 text-[11px] text-slate-500">
                        <span className="font-mono font-medium text-blue-700">{rem.eventDate}</span>
                        <span>•</span>
                        <span>Alert: {rem.remindBeforeDays} days prior</span>
                      </div>
                    </div>
                    <button
                      onClick={() => onDeleteReminder(rem.id)}
                      className="p-1 text-slate-400 hover:text-rose-600 rounded-md hover:bg-rose-50 transition-colors"
                      title="Remove reminder"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))}
              </div>
            ) : (
              <div className="py-6 text-center text-xs text-slate-500 space-y-1">
                <p>No reminders scheduled yet.</p>
                <p className="text-[11px] text-slate-400">
                  Click "Set Reminder" next to any exam milestone to get alerted before deadlines.
                </p>
              </div>
            )}
          </div>

          {/* Tips Card */}
          <div className="bg-gradient-to-tr from-slate-900 to-indigo-950 text-white rounded-2xl p-5 space-y-3 shadow-md">
            <div className="flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-amber-300" />
              <h4 className="text-xs font-bold font-['Outfit',sans-serif]">Pro Preparation Tip</h4>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed">
              Always complete application fee payments at least 48 hours prior to the closing deadline to avoid server congestions on conducting agency servers.
            </p>
          </div>
        </div>
      </div>

      {/* Custom Reminder Modal */}
      {showAddReminderModal && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="w-full max-w-md bg-white rounded-2xl shadow-2xl border border-slate-200 p-6 space-y-4 animate-in fade-in">
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <h3 className="text-base font-bold text-slate-900">Set Custom Exam Milestone Reminder</h3>
              <button
                onClick={() => setShowAddReminderModal(false)}
                className="text-slate-400 hover:text-slate-600 text-sm font-bold"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleCreateCustomReminder} className="space-y-3.5 text-xs">
              <div>
                <label className="font-bold text-slate-700 block mb-1">Target Exam:</label>
                <select
                  value={customReminderExamId}
                  onChange={(e) => setCustomReminderExamId(e.target.value)}
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-lg text-slate-800 font-medium"
                >
                  {exams.map((e) => (
                    <option key={e.id} value={e.id}>
                      {e.name} - {e.fullName}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">Milestone Title:</label>
                <input
                  type="text"
                  required
                  value={customEventTitle}
                  onChange={(e) => setCustomEventTitle(e.target.value)}
                  placeholder="e.g. Fee Payment Cutoff or Mock Test 1"
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-lg text-slate-800"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Milestone Date:</label>
                  <input
                    type="date"
                    required
                    value={customEventDate}
                    onChange={(e) => setCustomEventDate(e.target.value)}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-lg text-slate-800"
                  />
                </div>
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Lead Time Alert:</label>
                  <select
                    value={customLeadDays}
                    onChange={(e) => setCustomLeadDays(Number(e.target.value))}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-lg text-slate-800"
                  >
                    <option value={1}>1 day before</option>
                    <option value={3}>3 days before</option>
                    <option value={7}>7 days before</option>
                    <option value={14}>14 days before</option>
                  </select>
                </div>
              </div>

              <div className="pt-3 flex justify-end gap-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowAddReminderModal(false)}
                  className="px-3 py-2 bg-slate-100 text-slate-700 rounded-lg font-medium"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-bold shadow-xs"
                >
                  Save Reminder
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
