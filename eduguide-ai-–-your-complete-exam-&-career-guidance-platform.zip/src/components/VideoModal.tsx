import React, { useState } from "react";
import {
  X,
  Play,
  Pause,
  CheckCircle2,
  BookOpen,
  Share2,
  Clock,
  Sparkles,
  ExternalLink,
  Volume2,
  Maximize2,
} from "lucide-react";
import { LearningResource } from "../types";

interface VideoModalProps {
  resource: LearningResource | null;
  onClose: () => void;
}

export const VideoModal: React.FC<VideoModalProps> = ({ resource, onClose }) => {
  const [isPlaying, setIsPlaying] = useState(true);
  const [activeTab, setActiveTab] = useState<"takeaways" | "notes">("takeaways");
  const [userNote, setUserNote] = useState("");
  const [savedNotes, setSavedNotes] = useState<string[]>([]);

  if (!resource) return null;

  const handleAddNote = (e: React.FormEvent) => {
    e.preventDefault();
    if (!userNote.trim()) return;
    setSavedNotes((prev) => [...prev, userNote.trim()]);
    setUserNote("");
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/75 backdrop-blur-xs flex items-center justify-center p-4 sm:p-6">
      <div className="w-full max-w-4xl bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden animate-in fade-in zoom-in-95 duration-150 flex flex-col max-h-[90vh]">
        {/* Modal Top Bar */}
        <div className="p-4 bg-slate-900 text-white flex items-center justify-between border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <span className="text-[10px] px-2.5 py-0.5 rounded-full bg-blue-600 font-bold uppercase">
              {resource.type.replace("_", " ")}
            </span>
            <h3 className="text-sm font-bold truncate max-w-md sm:max-w-xl text-slate-100">
              {resource.title}
            </h3>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg bg-white/10 hover:bg-white/20 text-slate-300 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Video Player Canvas Simulation */}
        <div className={`relative h-64 sm:h-80 bg-gradient-to-tr ${resource.thumbnailGradient} flex flex-col justify-between p-6 text-white shrink-0`}>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-rose-500 animate-ping"></span>
              <span className="text-xs font-bold bg-black/40 px-2 py-0.5 rounded-md backdrop-blur-xs">
                HD 1080p Masterclass
              </span>
            </div>
            <span className="text-xs font-mono bg-black/50 px-2 py-0.5 rounded">
              Duration: {resource.duration}
            </span>
          </div>

          {/* Central Play/Pause button */}
          <div className="text-center space-y-2">
            <button
              onClick={() => setIsPlaying(!isPlaying)}
              className="w-16 h-16 rounded-full bg-white/20 hover:bg-white/30 backdrop-blur-md flex items-center justify-center mx-auto shadow-2xl transition-transform hover:scale-105"
            >
              {isPlaying ? (
                <Pause className="w-8 h-8 text-white fill-current" />
              ) : (
                <Play className="w-8 h-8 text-white fill-current ml-1" />
              )}
            </button>
            <p className="text-xs font-semibold text-slate-200 drop-shadow-md">
              {isPlaying ? "Playing Stream..." : "Paused"}
            </p>
          </div>

          {/* Player controls bottom bar */}
          <div className="bg-black/60 backdrop-blur-md -mx-6 -mb-6 p-3 px-6 flex items-center justify-between text-xs">
            <div className="flex items-center gap-3">
              <span className="text-slate-300">{resource.instructorOrChannel}</span>
              <span>•</span>
              <span className="text-slate-400">{resource.viewsCount}</span>
            </div>
            <div className="flex items-center gap-3 text-slate-300">
              <Volume2 className="w-4 h-4 cursor-pointer hover:text-white" />
              <Maximize2 className="w-4 h-4 cursor-pointer hover:text-white" />
            </div>
          </div>
        </div>

        {/* Interactive Bottom Sheet */}
        <div className="flex-1 overflow-y-auto p-6 space-y-5 bg-white">
          <div className="flex border-b border-slate-200 pb-2 gap-4">
            <button
              onClick={() => setActiveTab("takeaways")}
              className={`text-xs font-bold pb-2 border-b-2 flex items-center gap-1.5 transition-colors ${
                activeTab === "takeaways"
                  ? "border-blue-600 text-blue-600"
                  : "border-transparent text-slate-500 hover:text-slate-800"
              }`}
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>Core Key Takeaways</span>
            </button>
            <button
              onClick={() => setActiveTab("notes")}
              className={`text-xs font-bold pb-2 border-b-2 flex items-center gap-1.5 transition-colors ${
                activeTab === "notes"
                  ? "border-blue-600 text-blue-600"
                  : "border-transparent text-slate-500 hover:text-slate-800"
              }`}
            >
              <BookOpen className="w-3.5 h-3.5" />
              <span>My Study Notes ({savedNotes.length})</span>
            </button>
          </div>

          {activeTab === "takeaways" ? (
            <div className="space-y-3">
              <h4 className="text-xs font-bold text-slate-800 uppercase tracking-wider">
                Summary & High-Yield Examination Points:
              </h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                {resource.keyTakeaways.map((point, idx) => (
                  <div
                    key={idx}
                    className="p-3 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-700 flex items-start gap-2 leading-relaxed"
                  >
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                    <span>{point}</span>
                  </div>
                ))}
              </div>
            </div>
          ) : (
            <div className="space-y-4">
              <form onSubmit={handleAddNote} className="flex gap-2">
                <input
                  type="text"
                  value={userNote}
                  onChange={(e) => setUserNote(e.target.value)}
                  placeholder="Type a key concept or timestamp note to remember..."
                  className="flex-1 px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-blue-500/20"
                />
                <button
                  type="submit"
                  className="px-4 py-2 bg-blue-600 text-white rounded-xl text-xs font-bold hover:bg-blue-700 transition-colors"
                >
                  Add Note
                </button>
              </form>

              {savedNotes.length > 0 ? (
                <div className="space-y-2">
                  {savedNotes.map((note, idx) => (
                    <div
                      key={idx}
                      className="p-3 bg-amber-50/60 border border-amber-200 rounded-xl text-xs text-slate-800 flex items-start justify-between"
                    >
                      <span>📝 {note}</span>
                      <span className="text-[10px] text-slate-400">Note #{idx + 1}</span>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-xs text-slate-400 italic">No notes created yet for this video session.</p>
              )}
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 bg-slate-50 border-t border-slate-200 flex items-center justify-between text-xs text-slate-500">
          <span>EduGuide AI Curated Open Learning Library</span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 bg-slate-800 hover:bg-slate-900 text-white rounded-lg text-xs font-bold"
          >
            Close Player
          </button>
        </div>
      </div>
    </div>
  );
};
