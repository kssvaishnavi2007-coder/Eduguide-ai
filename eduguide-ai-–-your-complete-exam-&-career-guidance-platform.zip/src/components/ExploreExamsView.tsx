import React, { useState, useMemo } from "react";
import {
  Search,
  Filter,
  Compass,
  Bookmark,
  Calendar,
  ShieldCheck,
  ArrowRight,
  SlidersHorizontal,
  LayoutGrid,
  List,
  Sparkles,
  ExternalLink,
  ChevronDown,
  X,
} from "lucide-react";
import { Exam, ExamCategory } from "../types";
import { EXAM_CATEGORIES } from "../data/examsData";

interface ExploreExamsViewProps {
  exams: Exam[];
  selectedCategory: ExamCategory | "All";
  onSelectCategory: (cat: ExamCategory | "All") => void;
  onSelectExam: (exam: Exam) => void;
  savedExamIds: string[];
  onToggleSaveExam: (examId: string) => void;
}

export const ExploreExamsView: React.FC<ExploreExamsViewProps> = ({
  exams,
  selectedCategory,
  onSelectCategory,
  onSelectExam,
  savedExamIds,
  onToggleSaveExam,
}) => {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedEligibility, setSelectedEligibility] = useState<string>("All");
  const [sortBy, setSortBy] = useState<"deadline" | "popular" | "alphabetical">("deadline");
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid");

  // Distinct eligibility levels
  const eligibilityOptions = [
    "All",
    "10th Pass",
    "12th Pass (Science)",
    "12th Pass (Any)",
    "Graduate (Engineering)",
    "Graduate (Any)",
    "Medical Graduate (MBBS)",
    "Professional Certification",
  ];

  // Filtering logic
  const filteredExams = useMemo(() => {
    return exams.filter((exam) => {
      const matchesCategory =
        selectedCategory === "All" || exam.category === selectedCategory;

      const matchesEligibility =
        selectedEligibility === "All" || exam.eligibilityLevel === selectedEligibility;

      const matchesSearch =
        !searchQuery.trim() ||
        exam.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        exam.fullName.toLowerCase().includes(searchQuery.toLowerCase()) ||
        exam.shortDescription.toLowerCase().includes(searchQuery.toLowerCase()) ||
        exam.tags.some((t) => t.toLowerCase().includes(searchQuery.toLowerCase())) ||
        exam.officialConductingBody.toLowerCase().includes(searchQuery.toLowerCase());

      return matchesCategory && matchesEligibility && matchesSearch;
    }).sort((a, b) => {
      if (sortBy === "deadline") {
        return (
          new Date(a.upcomingImportantDate.date).getTime() -
          new Date(b.upcomingImportantDate.date).getTime()
        );
      }
      if (sortBy === "alphabetical") {
        return a.name.localeCompare(b.name);
      }
      if (sortBy === "popular") {
        return (b.trending ? 1 : 0) - (a.trending ? 1 : 0);
      }
      return 0;
    });
  }, [exams, selectedCategory, selectedEligibility, searchQuery, sortBy]);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8 pb-20">
      {/* Directory Header */}
      <div className="space-y-3">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-50 border border-blue-200 text-blue-700 text-xs font-semibold">
          <Compass className="w-3.5 h-3.5" />
          <span>Centralized Competitive Exams Directory</span>
        </div>
        <h1 className="text-3xl sm:text-4xl font-extrabold text-slate-900 font-['Outfit',sans-serif] tracking-tight">
          Explore Competitive Examinations
        </h1>
        <p className="text-sm sm:text-base text-slate-600 max-w-3xl leading-relaxed">
          Comprehensive, verified profiles for national & international entrance tests across engineering, medical, government services, banking, railways, defense, tech, and overseas admissions.
        </p>
      </div>

      {/* Filter Toolbar Card */}
      <div className="bg-white rounded-2xl shadow-xs border border-slate-200 p-5 space-y-5">
        {/* Search input & Sort & View Mode */}
        <div className="flex flex-col md:flex-row gap-3 items-center justify-between">
          <div className="relative w-full md:max-w-md">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              id="directory-search-input"
              type="text"
              placeholder="Search by exam name, conducting body (NTA, UPSC, SSC), or keywords..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm text-slate-800 placeholder-slate-400 focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-all"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery("")}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 p-1"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          <div className="flex items-center gap-2.5 w-full md:w-auto justify-between md:justify-end">
            {/* Sort Dropdown */}
            <div className="flex items-center gap-1.5 text-xs text-slate-600">
              <span className="font-medium shrink-0">Sort:</span>
              <select
                id="sort-select"
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as any)}
                className="bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1.5 text-xs font-semibold text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-blue-500/20"
              >
                <option value="deadline">Upcoming Deadlines</option>
                <option value="popular">Trending / Popularity</option>
                <option value="alphabetical">Alphabetical (A - Z)</option>
              </select>
            </div>

            {/* View Mode Toggle */}
            <div className="flex items-center bg-slate-100 p-0.5 rounded-lg border border-slate-200">
              <button
                onClick={() => setViewMode("grid")}
                className={`p-1.5 rounded-md ${
                  viewMode === "grid"
                    ? "bg-white text-blue-600 shadow-xs"
                    : "text-slate-500 hover:text-slate-800"
                }`}
                title="Grid view"
              >
                <LayoutGrid className="w-4 h-4" />
              </button>
              <button
                onClick={() => setViewMode("list")}
                className={`p-1.5 rounded-md ${
                  viewMode === "list"
                    ? "bg-white text-blue-600 shadow-xs"
                    : "text-slate-500 hover:text-slate-800"
                }`}
                title="List view"
              >
                <List className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>

        {/* Category Filter Chips */}
        <div className="space-y-2">
          <div className="flex items-center justify-between text-xs font-bold text-slate-700">
            <span>Exam Category:</span>
            {selectedCategory !== "All" && (
              <button
                onClick={() => onSelectCategory("All")}
                className="text-blue-600 hover:underline font-normal"
              >
                Reset Category
              </button>
            )}
          </div>
          <div className="flex flex-wrap gap-2">
            <button
              id="cat-pill-all"
              onClick={() => onSelectCategory("All")}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                selectedCategory === "All"
                  ? "bg-blue-600 text-white shadow-xs"
                  : "bg-slate-100 hover:bg-slate-200 text-slate-700"
              }`}
            >
              All Categories ({exams.length})
            </button>
            {EXAM_CATEGORIES.map((cat) => {
              const isSelected = selectedCategory === cat.id;
              const count = exams.filter((e) => e.category === cat.id).length;
              return (
                <button
                  key={cat.id}
                  id={`cat-pill-${cat.id.toLowerCase().replace(/ /g, "-")}`}
                  onClick={() => onSelectCategory(cat.id)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all flex items-center gap-1.5 ${
                    isSelected
                      ? "bg-blue-600 text-white shadow-xs"
                      : "bg-slate-100 hover:bg-slate-200 text-slate-700"
                  }`}
                >
                  <span>{cat.label}</span>
                  <span className={`text-[10px] px-1.5 py-0.2 rounded-full ${isSelected ? "bg-blue-700 text-white" : "bg-slate-200 text-slate-600"}`}>
                    {count}
                  </span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Eligibility Level Chips */}
        <div className="space-y-2 pt-2 border-t border-slate-100">
          <div className="flex items-center justify-between text-xs font-bold text-slate-700">
            <span>Eligibility Level:</span>
            {selectedEligibility !== "All" && (
              <button
                onClick={() => setSelectedEligibility("All")}
                className="text-blue-600 hover:underline font-normal"
              >
                Reset Eligibility
              </button>
            )}
          </div>
          <div className="flex flex-wrap gap-1.5 text-xs">
            {eligibilityOptions.map((opt) => (
              <button
                key={opt}
                onClick={() => setSelectedEligibility(opt)}
                className={`px-2.5 py-1 rounded-md text-xs font-medium transition-colors ${
                  selectedEligibility === opt
                    ? "bg-indigo-100 text-indigo-800 font-semibold border border-indigo-300"
                    : "bg-slate-50 hover:bg-slate-100 text-slate-600 border border-slate-200"
                }`}
              >
                {opt}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Search results summary */}
      <div className="flex items-center justify-between text-sm text-slate-500">
        <div>
          Showing <strong className="text-slate-900 font-bold">{filteredExams.length}</strong> exam profiles
          {selectedCategory !== "All" && <span> in <span className="text-blue-600 font-semibold">{selectedCategory}</span></span>}
        </div>
        {(searchQuery || selectedCategory !== "All" || selectedEligibility !== "All") && (
          <button
            onClick={() => {
              setSearchQuery("");
              onSelectCategory("All");
              setSelectedEligibility("All");
            }}
            className="text-xs text-rose-600 hover:text-rose-800 font-semibold flex items-center gap-1"
          >
            <X className="w-3.5 h-3.5" /> Clear all filters
          </button>
        )}
      </div>

      {/* Exams Results Render */}
      {filteredExams.length > 0 ? (
        viewMode === "grid" ? (
          /* Grid View Layout */
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredExams.map((exam) => {
              const isSaved = savedExamIds.includes(exam.id);
              return (
                <div
                  key={exam.id}
                  id={`exam-directory-card-${exam.id}`}
                  className="group bg-white rounded-2xl border border-slate-200/90 shadow-xs hover:shadow-lg hover:border-blue-300 transition-all duration-200 flex flex-col justify-between overflow-hidden"
                >
                  <div className="p-5 space-y-3.5">
                    {/* Top Row: Category tag, Official badge, Bookmark button */}
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex flex-wrap items-center gap-1.5">
                        <span className="text-[11px] px-2.5 py-1 rounded-md bg-blue-50 text-blue-700 font-bold border border-blue-100">
                          {exam.category}
                        </span>
                        {exam.isOfficialVerified && (
                          <span className="inline-flex items-center gap-0.5 text-[10px] text-emerald-700 bg-emerald-50 px-1.5 py-0.5 rounded font-medium border border-emerald-200">
                            <ShieldCheck className="w-3 h-3 text-emerald-600" /> Official
                          </span>
                        )}
                      </div>
                      <button
                        onClick={() => onToggleSaveExam(exam.id)}
                        className={`p-1.5 rounded-lg border transition-colors ${
                          isSaved
                            ? "bg-blue-600 text-white border-blue-600"
                            : "bg-slate-50 text-slate-400 hover:text-blue-600 hover:bg-slate-100 border-slate-200"
                        }`}
                        title={isSaved ? "Saved in your dashboard" : "Save this exam"}
                      >
                        <Bookmark className="w-4 h-4 fill-current" />
                      </button>
                    </div>

                    {/* Name & Short Description */}
                    <div>
                      <h3
                        onClick={() => onSelectExam(exam)}
                        className="text-lg font-bold text-slate-900 group-hover:text-blue-600 cursor-pointer transition-colors"
                      >
                        {exam.name}
                      </h3>
                      <p className="text-xs text-slate-500 font-medium line-clamp-1">{exam.fullName}</p>
                      <p className="text-xs text-slate-600 mt-2 line-clamp-2 leading-relaxed">
                        {exam.shortDescription}
                      </p>
                    </div>

                    {/* Eligibility & Upcoming Important Date */}
                    <div className="p-3 bg-slate-50 rounded-xl space-y-2 text-xs border border-slate-100">
                      <div className="flex items-center justify-between">
                        <span className="text-slate-400 font-medium">Eligibility:</span>
                        <span className="font-semibold text-slate-800 text-right truncate max-w-[65%]">
                          {exam.eligibilityLevel}
                        </span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-slate-400 font-medium">Next Date:</span>
                        <span className="font-semibold text-blue-700 text-right truncate max-w-[65%] flex items-center gap-1 justify-end">
                          <Calendar className="w-3 h-3 text-blue-500" />
                          {exam.upcomingImportantDate.label} ({exam.upcomingImportantDate.date})
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Card Bottom CTA */}
                  <div className="px-5 py-3 bg-slate-50 border-t border-slate-100 flex items-center justify-between">
                    <span className="text-[11px] text-slate-500 font-medium truncate max-w-[50%]">
                      {exam.officialConductingBody}
                    </span>
                    <button
                      onClick={() => onSelectExam(exam)}
                      className="px-3.5 py-1.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold rounded-lg shadow-xs transition-colors flex items-center gap-1"
                    >
                      <span>View Profile</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          /* List View Layout */
          <div className="bg-white rounded-2xl border border-slate-200 shadow-xs divide-y divide-slate-100 overflow-hidden">
            {filteredExams.map((exam) => {
              const isSaved = savedExamIds.includes(exam.id);
              return (
                <div
                  key={exam.id}
                  id={`exam-list-item-${exam.id}`}
                  onClick={() => onSelectExam(exam)}
                  className="p-4 sm:p-5 hover:bg-blue-50/50 cursor-pointer transition-colors flex flex-col sm:flex-row sm:items-center justify-between gap-4"
                >
                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 rounded-xl bg-blue-100 text-blue-700 font-bold flex items-center justify-center text-sm shrink-0">
                      {exam.name.slice(0, 3)}
                    </div>
                    <div className="space-y-1">
                      <div className="flex flex-wrap items-center gap-2">
                        <h3 className="text-base font-bold text-slate-900 hover:text-blue-600">
                          {exam.name}
                        </h3>
                        <span className="text-xs px-2 py-0.5 rounded-md bg-slate-100 text-slate-600 font-medium">
                          {exam.category}
                        </span>
                        {exam.isOfficialVerified && (
                          <span className="inline-flex items-center gap-0.5 text-[10px] text-emerald-700 bg-emerald-50 px-1.5 py-0.5 rounded font-medium">
                            <ShieldCheck className="w-3 h-3" /> Official
                          </span>
                        )}
                      </div>
                      <p className="text-xs text-slate-500 font-medium">{exam.fullName} • {exam.officialConductingBody}</p>
                      <p className="text-xs text-slate-600 line-clamp-1 max-w-2xl">{exam.shortDescription}</p>
                    </div>
                  </div>

                  <div className="flex items-center gap-4 shrink-0 justify-between sm:justify-end border-t sm:border-t-0 pt-2 sm:pt-0">
                    <div className="text-right text-xs">
                      <div className="font-semibold text-slate-800">{exam.eligibilityLevel}</div>
                      <div className="text-blue-700 font-medium flex items-center gap-1 sm:justify-end mt-0.5">
                        <Calendar className="w-3 h-3" />
                        {exam.upcomingImportantDate.label}: {exam.upcomingImportantDate.date}
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          onToggleSaveExam(exam.id);
                        }}
                        className={`p-2 rounded-lg border ${
                          isSaved
                            ? "bg-blue-600 text-white border-blue-600"
                            : "bg-slate-50 text-slate-400 hover:text-blue-600 border-slate-200"
                        }`}
                      >
                        <Bookmark className="w-4 h-4 fill-current" />
                      </button>
                      <button
                        onClick={() => onSelectExam(exam)}
                        className="px-3.5 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-xs font-semibold flex items-center gap-1"
                      >
                        Profile <ArrowRight className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )
      ) : (
        /* Empty State */
        <div className="bg-white rounded-2xl border border-slate-200 p-12 text-center space-y-4">
          <Compass className="w-12 h-12 text-slate-300 mx-auto" />
          <h3 className="text-lg font-bold text-slate-800">No matching exams found</h3>
          <p className="text-xs text-slate-500 max-w-md mx-auto">
            Try adjusting your search query or reset category and eligibility filters to see all available examinations.
          </p>
          <button
            onClick={() => {
              setSearchQuery("");
              onSelectCategory("All");
              setSelectedEligibility("All");
            }}
            className="px-4 py-2 bg-blue-600 text-white rounded-xl text-xs font-semibold shadow-xs"
          >
            Reset All Filters
          </button>
        </div>
      )}
    </div>
  );
};
