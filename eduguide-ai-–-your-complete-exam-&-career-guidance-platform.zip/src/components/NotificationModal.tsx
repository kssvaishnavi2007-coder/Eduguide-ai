import React, { useState } from "react";
import {
  Bell,
  X,
  CheckCircle2,
  AlertTriangle,
  Calendar,
  Sparkles,
  ShieldCheck,
  Mail,
  ChevronRight,
  Sliders,
} from "lucide-react";
import { NotificationItem, StudentProfile } from "../types";

interface NotificationModalProps {
  isOpen: boolean;
  onClose: () => void;
  notifications: NotificationItem[];
  profile: StudentProfile;
  onUpdateProfile: (updated: StudentProfile) => void;
  onMarkAllAsRead: () => void;
  onSelectExamById: (examId: string) => void;
}

export const NotificationModal: React.FC<NotificationModalProps> = ({
  isOpen,
  onClose,
  notifications,
  profile,
  onUpdateProfile,
  onMarkAllAsRead,
  onSelectExamById,
}) => {
  const [activeTab, setActiveTab] = useState<"alerts" | "preferences">("alerts");
  const [subscribedEmail, setSubscribedEmail] = useState(profile.email || "student@eduguide.ai");
  const [subscribedSuccess, setSubscribedSuccess] = useState(false);

  if (!isOpen) return null;

  const handleTogglePref = (key: keyof StudentProfile["notificationPreferences"]) => {
    const updated = {
      ...profile,
      notificationPreferences: {
        ...profile.notificationPreferences,
        [key]: !profile.notificationPreferences[key],
      },
    };
    onUpdateProfile(updated);
  };

  const handleSaveEmail = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdateProfile({ ...profile, email: subscribedEmail });
    setSubscribedSuccess(true);
    setTimeout(() => setSubscribedSuccess(false), 3000);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div
        id="notification-modal-container"
        className="w-full max-w-xl bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden animate-in fade-in zoom-in-95 duration-150"
      >
        {/* Header */}
        <div className="p-5 bg-gradient-to-r from-blue-900 to-indigo-900 text-white flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-white/10 flex items-center justify-center border border-white/20">
              <Bell className="w-5 h-5 text-amber-300 animate-bounce" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-lg font-bold font-['Outfit',sans-serif]">Don't Miss Any Exam</h3>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-amber-400/20 text-amber-300 font-semibold border border-amber-300/30">
                  Live Radar
                </span>
              </div>
              <p className="text-xs text-slate-300">
                Official notifications, registration deadlines, admit cards & result alerts.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-slate-200 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab switchers */}
        <div className="flex border-b border-slate-200 bg-slate-50 px-4">
          <button
            id="tab-alerts-list"
            onClick={() => setActiveTab("alerts")}
            className={`py-3 px-4 text-sm font-semibold border-b-2 flex items-center gap-2 transition-colors ${
              activeTab === "alerts"
                ? "border-blue-600 text-blue-600"
                : "border-transparent text-slate-500 hover:text-slate-800"
            }`}
          >
            <Bell className="w-4 h-4" />
            Active Alerts ({notifications.length})
          </button>
          <button
            id="tab-alert-prefs"
            onClick={() => setActiveTab("preferences")}
            className={`py-3 px-4 text-sm font-semibold border-b-2 flex items-center gap-2 transition-colors ${
              activeTab === "preferences"
                ? "border-blue-600 text-blue-600"
                : "border-transparent text-slate-500 hover:text-slate-800"
            }`}
          >
            <Sliders className="w-4 h-4" />
            Alert Preferences & Email Sync
          </button>
        </div>

        {/* Content body */}
        <div className="p-5 max-h-[440px] overflow-y-auto">
          {activeTab === "alerts" ? (
            <div className="space-y-3">
              <div className="flex items-center justify-between pb-2 border-b border-slate-100 text-xs text-slate-500">
                <span>Real-time official updates matching your profile</span>
                <button
                  onClick={onMarkAllAsRead}
                  className="text-blue-600 hover:text-blue-800 font-medium cursor-pointer"
                >
                  Mark all as read
                </button>
              </div>

              {notifications.map((notif) => (
                <div
                  key={notif.id}
                  id={`notif-card-${notif.id}`}
                  className={`p-3.5 rounded-xl border transition-all ${
                    notif.type === "urgent"
                      ? "bg-rose-50/50 border-rose-200"
                      : notif.type === "admit_card"
                      ? "bg-blue-50/50 border-blue-200"
                      : "bg-slate-50/60 border-slate-200"
                  }`}
                >
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex items-start gap-2.5">
                      {notif.type === "urgent" ? (
                        <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
                      ) : notif.type === "admit_card" ? (
                        <Calendar className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" />
                      ) : (
                        <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                      )}
                      <div>
                        <h4 className="text-sm font-semibold text-slate-900">{notif.title}</h4>
                        <p className="text-xs text-slate-600 mt-1 leading-relaxed">{notif.message}</p>
                        <div className="flex items-center gap-3 mt-2 text-[11px] text-slate-400">
                          <span>{notif.date}</span>
                          {notif.examId && (
                            <button
                              onClick={() => {
                                onSelectExamById(notif.examId!);
                                onClose();
                              }}
                              className="text-blue-600 hover:text-blue-800 font-semibold flex items-center gap-0.5"
                            >
                              {notif.linkText || "View Exam Profile"} <ChevronRight className="w-3 h-3" />
                            </button>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="space-y-5">
              <div>
                <h4 className="text-sm font-bold text-slate-900 mb-1">Targeted Exam Alert Subscriptions</h4>
                <p className="text-xs text-slate-500 mb-3">
                  Toggle which notifications you wish to receive based on your education & target exam selections.
                </p>

                <div className="space-y-2.5">
                  <label className="flex items-center justify-between p-3 rounded-xl border border-slate-200 bg-slate-50 hover:bg-slate-100 cursor-pointer">
                    <div>
                      <span className="text-xs font-semibold text-slate-800 block">Registration Deadline Reminders</span>
                      <span className="text-[11px] text-slate-500">Alert me 7 days & 48 hours before official application windows close</span>
                    </div>
                    <input
                      type="checkbox"
                      checked={profile.notificationPreferences.deadlineAlerts}
                      onChange={() => handleTogglePref("deadlineAlerts")}
                      className="w-4 h-4 text-blue-600 rounded border-slate-300 focus:ring-blue-500"
                    />
                  </label>

                  <label className="flex items-center justify-between p-3 rounded-xl border border-slate-200 bg-slate-50 hover:bg-slate-100 cursor-pointer">
                    <div>
                      <span className="text-xs font-semibold text-slate-800 block">Admit Card / Hall Ticket Releases</span>
                      <span className="text-[11px] text-slate-500">Immediate notice when official download portals go live</span>
                    </div>
                    <input
                      type="checkbox"
                      checked={profile.notificationPreferences.admitCardAlerts}
                      onChange={() => handleTogglePref("admitCardAlerts")}
                      className="w-4 h-4 text-blue-600 rounded border-slate-300 focus:ring-blue-500"
                    />
                  </label>

                  <label className="flex items-center justify-between p-3 rounded-xl border border-slate-200 bg-slate-50 hover:bg-slate-100 cursor-pointer">
                    <div>
                      <span className="text-xs font-semibold text-slate-800 block">New Exam Announcements & Vacancy Circulars</span>
                      <span className="text-[11px] text-slate-500">Get notified when new eligibility openings match your degree</span>
                    </div>
                    <input
                      type="checkbox"
                      checked={profile.notificationPreferences.newExamAnnouncements}
                      onChange={() => handleTogglePref("newExamAnnouncements")}
                      className="w-4 h-4 text-blue-600 rounded border-slate-300 focus:ring-blue-500"
                    />
                  </label>
                </div>
              </div>

              {/* Email sync simulator */}
              <form onSubmit={handleSaveEmail} className="p-4 rounded-xl bg-blue-50/70 border border-blue-200">
                <div className="flex items-center gap-2 mb-2">
                  <Mail className="w-4 h-4 text-blue-700" />
                  <span className="text-xs font-bold text-blue-900">Email & Mobile Notification Channel</span>
                </div>
                <p className="text-[11px] text-blue-800 mb-2">
                  Receive consolidated weekly exam bulletins and urgent countdown reminders straight to your inbox.
                </p>
                <div className="flex gap-2">
                  <input
                    type="email"
                    required
                    value={subscribedEmail}
                    onChange={(e) => setSubscribedEmail(e.target.value)}
                    placeholder="Enter your student email..."
                    className="flex-1 px-3 py-1.5 text-xs bg-white rounded-lg border border-blue-300 focus:outline-hidden focus:ring-2 focus:ring-blue-500"
                  />
                  <button
                    type="submit"
                    className="px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-xs font-semibold transition-colors"
                  >
                    Save Email
                  </button>
                </div>
                {subscribedSuccess && (
                  <p className="text-xs text-emerald-700 font-medium mt-1.5 flex items-center gap-1">
                    <CheckCircle2 className="w-3.5 h-3.5" /> Email subscription preferences saved successfully!
                  </p>
                )}
              </form>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 bg-slate-50 border-t border-slate-200 flex items-center justify-between text-xs text-slate-500">
          <div className="flex items-center gap-1.5">
            <ShieldCheck className="w-4 h-4 text-emerald-600" />
            <span>Anti-spam: Only verified official exam circulars</span>
          </div>
          <button
            onClick={onClose}
            className="px-4 py-1.5 bg-slate-800 hover:bg-slate-900 text-white font-medium rounded-lg text-xs"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
