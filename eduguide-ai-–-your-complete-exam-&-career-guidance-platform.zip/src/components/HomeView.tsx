import React, { useState } from "react";
import {
  Search,
  Sparkles,
  Compass,
  ArrowRight,
  ShieldCheck,
  Calendar,
  Clock,
  BookOpen,
  CheckCircle2,
  Cpu,
  Stethoscope,
  Landmark,
  Building2,
  Train,
  Shield,
  Terminal,
  Globe2,
  TrendingUp,
  Bookmark,
  ChevronRight,
  Target,
  Zap,
  Award,
  Video,
  ExternalLink,
} from "lucide-react";
import { Exam, ExamCategory } from "../types";
import { EXAM_CATEGORIES } from "../data/examsData";

interface HomeViewProps {
  exams: Exam[];
  onSelectExam: (exam: Exam) => void;
  onNavigateToTab: (tab: string) => void;
  onSelectCategory: (category: ExamCategory) => void;
  savedExamIds: string[];
  onToggleSaveExam: (examId: string) => void;
  onStartAIGuidanceWithPrompt?: (promptData: { educationLevel: string; degreeOrBranch: string; interests: string; careerGoals: string }) => void;
}

export const HomeView: React.FC<HomeViewProps> = ({
  exams,
  onSelectExam,
  onNavigateToTab,
  onSelectCategory,
  savedExamIds,
  onToggleSaveExam,
  onStartAIGuidanceWithPrompt,
}) => {
  const [searchQuery, setSearchQuery] = useState("");

  const getCategoryIcon = (iconName: string) => {
    switch (iconName) {
      case "Cpu": return Cpu;
      case "Stethoscope": return Stethoscope;
      case "Landmark": return Landmark;
      case "Building2": return Building2;
      case "Train": return Train;
      case "Shield": return Shield;
      case "Terminal": return Terminal;
      case "Globe2": return Globe2;
      default: return Compass;
    }
  };

  const trendingExams = exams.filter((e) => e.trending).slice(0, 6);
  const upcomingDeadlines = [...exams]
    .sort((a, b) => new Date(a.upcomingImportantDate.date).getTime() - new Date(b.upcomingImportantDate.date).getTime())
    .slice(0, 4);

  const filteredSearchSuggestions = searchQuery.trim()
    ? exams.filter(
        (e) =>
          e.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
          e.fullName.toLowerCase().includes(searchQuery.toLowerCase()) ||
          e.category.toLowerCase().includes(searchQuery.toLowerCase()) ||
          e.tags.some((t) => t.toLowerCase().includes(searchQuery.toLowerCase()))
      ).slice(0, 5)
    : [];

  const handleHeroSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (filteredSearchSuggestions.length > 0) {
      onSelectExam(filteredSearchSuggestions[0]);
    } else {
      onNavigateToTab("explore");
    }
  };

  return (
    <div className="space-y-16 pb-20">
      {/* 1. HERO SECTION */}
      <section className="relative overflow-hidden bg-gradient-to-b from-blue-950 via-slate-900 to-slate-950 text-white pt-14 pb-20 px-4 sm:px-6 lg:px-8 border-b border-slate-800">
        {/* Ambient background glow elements */}
        <div className="absolute top-0 left-1/4 w-96 h-96 bg-blue-600/15 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-indigo-600/15 rounded-full blur-3xl pointer-events-none" />

        <div className="max-w-5xl mx-auto text-center relative z-10 space-y-6">
          {/* Trust Badge */}
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-blue-500/10 border border-blue-400/20 text-blue-300 text-xs sm:text-sm font-medium backdrop-blur-md">
            <Sparkles className="w-4 h-4 text-blue-400" />
            <span>EduGuide AI – Verified Multi-Exam Knowledge Engine</span>
          </div>

          {/* Main Hero Headline */}
          <h1 className="text-3xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight font-['Outfit',sans-serif] text-white leading-tight">
            Your Complete Guide for <br className="hidden sm:inline" />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 via-indigo-300 to-cyan-400">
              Every Competitive Exam
            </span>
          </h1>

          {/* Subtitle & Tagline */}
          <p className="text-base sm:text-lg text-slate-300 max-w-3xl mx-auto leading-relaxed font-normal">
            <strong className="text-white font-semibold">“One Platform. Every Exam. Complete Guidance.”</strong> Stop searching dozens of fragmented portals. Discover eligibility, master complete syllabi, plan daily revision schedules, and track official deadlines in one place.
          </p>

          {/* Interactive Search Bar in Hero */}
          <div className="max-w-2xl mx-auto pt-2 relative">
            <form onSubmit={handleHeroSearchSubmit} className="relative flex items-center">
              <div className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400">
                <Search className="w-5 h-5" />
              </div>
              <input
                id="hero-search-input"
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search any exam (e.g. JEE Main, NEET, UPSC CSE, GATE, SBI PO, GRE)..."
                className="w-full pl-12 pr-32 py-4 bg-white/10 hover:bg-white/15 focus:bg-white text-slate-100 focus:text-slate-900 placeholder-slate-400 rounded-2xl border border-white/20 focus:border-blue-500 shadow-xl focus:outline-hidden transition-all text-sm sm:text-base backdrop-blur-md"
              />
              <button
                type="submit"
                id="hero-search-submit-btn"
                className="absolute right-2 top-1/2 -translate-y-1/2 px-4 py-2.5 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white rounded-xl text-xs sm:text-sm font-semibold shadow-md transition-all flex items-center gap-1.5"
              >
                <span>Search</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </form>

            {/* Live Autocomplete suggestions */}
            {filteredSearchSuggestions.length > 0 && (
              <div className="absolute top-full left-0 right-0 mt-2 bg-white text-slate-900 rounded-xl shadow-2xl border border-slate-200 overflow-hidden z-30 text-left animate-in fade-in zoom-in-95 duration-150">
                <div className="p-2 space-y-1">
                  {filteredSearchSuggestions.map((item) => (
                    <div
                      key={item.id}
                      onClick={() => {
                        onSelectExam(item);
                        setSearchQuery("");
                      }}
                      className="p-2.5 hover:bg-blue-50 rounded-lg cursor-pointer flex items-center justify-between transition-colors"
                    >
                      <div className="flex items-center gap-2.5">
                        <span className="w-7 h-7 rounded bg-blue-100 text-blue-700 flex items-center justify-center text-xs font-bold">
                          {item.name.slice(0, 2)}
                        </span>
                        <div>
                          <p className="text-sm font-bold text-slate-900">{item.name}</p>
                          <p className="text-xs text-slate-500">{item.category} • {item.eligibilityLevel}</p>
                        </div>
                      </div>
                      <span className="text-xs text-blue-600 font-semibold flex items-center gap-1">
                        View Profile <ChevronRight className="w-3.5 h-3.5" />
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Popular quick tags */}
            <div className="flex flex-wrap items-center justify-center gap-2 pt-4 text-xs text-slate-400">
              <span className="font-medium text-slate-300">Popular Searches:</span>
              {["JEE Main", "UPSC IAS", "NEET UG", "GATE CSE", "SBI PO", "AWS Solutions", "GRE"].map((tag) => (
                <button
                  key={tag}
                  type="button"
                  onClick={() => {
                    const match = exams.find((e) => e.name.toLowerCase().includes(tag.toLowerCase()));
                    if (match) onSelectExam(match);
                  }}
                  className="px-2.5 py-1 bg-white/5 hover:bg-white/15 text-slate-200 rounded-md border border-white/10 transition-colors"
                >
                  {tag}
                </button>
              ))}
            </div>
          </div>

          {/* Quick Metrics Bar */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 max-w-4xl mx-auto pt-6 text-slate-200">
            <div className="p-3.5 rounded-xl bg-white/5 border border-white/10 backdrop-blur-xs">
              <div className="text-xl sm:text-2xl font-extrabold text-white font-['Outfit',sans-serif]">100+</div>
              <div className="text-xs text-slate-400 mt-0.5">Competitive Exams</div>
            </div>
            <div className="p-3.5 rounded-xl bg-white/5 border border-white/10 backdrop-blur-xs">
              <div className="text-xl sm:text-2xl font-extrabold text-emerald-400 font-['Outfit',sans-serif]">100%</div>
              <div className="text-xs text-slate-400 mt-0.5">Verified Official Data</div>
            </div>
            <div className="p-3.5 rounded-xl bg-white/5 border border-white/10 backdrop-blur-xs">
              <div className="text-xl sm:text-2xl font-extrabold text-blue-400 font-['Outfit',sans-serif]">AI-Powered</div>
              <div className="text-xs text-slate-400 mt-0.5">Career & Study Roadmaps</div>
            </div>
            <div className="p-3.5 rounded-xl bg-white/5 border border-white/10 backdrop-blur-xs">
              <div className="text-xl sm:text-2xl font-extrabold text-amber-400 font-['Outfit',sans-serif]">Live Radar</div>
              <div className="text-xs text-slate-400 mt-0.5">Deadline & Admit Alerts</div>
            </div>
          </div>
        </div>
      </section>

      {/* 2. UPCOMING IMPORTANT DEADLINES RADAR BAR */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 -mt-6 sm:-mt-10 relative z-20">
        <div className="bg-white rounded-2xl shadow-xl border border-slate-200/90 p-5 sm:p-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-100">
            <div className="flex items-center gap-2.5">
              <span className="p-2 rounded-lg bg-amber-50 text-amber-600 border border-amber-200">
                <Clock className="w-5 h-5" />
              </span>
              <div>
                <h3 className="text-base font-bold text-slate-900 font-['Outfit',sans-serif]">
                  Upcoming Important Deadlines & Events
                </h3>
                <p className="text-xs text-slate-500">
                  Critical registration windows, admit card releases, and examination dates.
                </p>
              </div>
            </div>
            <button
              onClick={() => onNavigateToTab("timeline")}
              className="text-xs font-semibold text-blue-600 hover:text-blue-800 flex items-center gap-1 self-start sm:self-center"
            >
              View Full Exam Timeline <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5 pt-4">
            {upcomingDeadlines.map((exam) => (
              <div
                key={exam.id}
                id={`deadline-card-${exam.id}`}
                onClick={() => onSelectExam(exam)}
                className="group p-3.5 rounded-xl border border-slate-200/80 bg-slate-50/50 hover:bg-blue-50/60 hover:border-blue-200 cursor-pointer transition-all duration-150 relative"
              >
                <div className="flex items-start justify-between">
                  <span className="font-bold text-sm text-slate-900 group-hover:text-blue-700 truncate">
                    {exam.name}
                  </span>
                  <span
                    className={`text-[10px] px-2 py-0.5 rounded-full font-bold uppercase ${
                      exam.upcomingImportantDate.isUrgent
                        ? "bg-rose-100 text-rose-700 border border-rose-200 animate-pulse"
                        : "bg-blue-100 text-blue-700"
                    }`}
                  >
                    {exam.upcomingImportantDate.type}
                  </span>
                </div>
                <div className="text-xs font-semibold text-slate-700 mt-2 flex items-center gap-1.5">
                  <Calendar className="w-3.5 h-3.5 text-slate-400" />
                  <span>{exam.upcomingImportantDate.label}</span>
                </div>
                <div className="flex items-center justify-between text-xs text-slate-500 mt-2 pt-2 border-t border-slate-200/60">
                  <span className="font-mono font-medium text-slate-700">{exam.upcomingImportantDate.date}</span>
                  <span className="text-[11px] text-blue-600 font-semibold group-hover:underline">
                    View Details →
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 3. EXPLORE EXAM CATEGORIES */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-3">
          <div>
            <div className="text-xs font-bold text-blue-600 uppercase tracking-wider mb-1">
              Explore by Discipline
            </div>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 font-['Outfit',sans-serif]">
              Explore Exam Categories
            </h2>
            <p className="text-sm text-slate-600 mt-1">
              Select your domain to browse eligibility criteria, syllabi, and application dates.
            </p>
          </div>
          <button
            onClick={() => onNavigateToTab("explore")}
            className="text-sm font-semibold text-blue-600 hover:text-blue-800 flex items-center gap-1 self-start sm:self-end"
          >
            Browse All Exams ({exams.length}) <ChevronRight className="w-4 h-4" />
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {EXAM_CATEGORIES.map((cat) => {
            const Icon = getCategoryIcon(cat.iconName);
            const categoryExamsCount = exams.filter((e) => e.category === cat.id).length;
            return (
              <div
                key={cat.id}
                id={`cat-card-${cat.id.toLowerCase().replace(/ /g, "-")}`}
                onClick={() => onSelectCategory(cat.id)}
                className="group relative bg-white rounded-2xl p-5 border border-slate-200/90 shadow-xs hover:shadow-md hover:border-blue-300 transition-all duration-200 cursor-pointer flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <div className={`w-12 h-12 rounded-xl bg-gradient-to-tr ${cat.gradient} text-white flex items-center justify-center shadow-md group-hover:scale-105 transition-transform`}>
                      <Icon className="w-6 h-6" />
                    </div>
                    <span className="text-xs font-bold px-2 py-1 bg-slate-100 text-slate-600 rounded-lg group-hover:bg-blue-50 group-hover:text-blue-700 transition-colors">
                      {categoryExamsCount || cat.count} Exams
                    </span>
                  </div>
                  <h3 className="text-base font-bold text-slate-900 group-hover:text-blue-600 transition-colors">
                    {cat.label}
                  </h3>
                  <p className="text-xs text-slate-500 mt-1.5 line-clamp-2 leading-relaxed">
                    {cat.description}
                  </p>
                </div>

                <div className="pt-4 mt-3 border-t border-slate-100 flex items-center justify-between text-xs font-semibold text-blue-600 group-hover:text-blue-700">
                  <span>Explore Directory</span>
                  <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* 4. TRENDING EXAMS SHOWCASE */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="p-1.5 rounded-lg bg-rose-50 text-rose-600 border border-rose-200">
              <TrendingUp className="w-5 h-5" />
            </span>
            <div>
              <h2 className="text-2xl font-extrabold text-slate-900 font-['Outfit',sans-serif]">
                Trending Competitive Exams
              </h2>
              <p className="text-xs text-slate-500">
                Most viewed examinations with upcoming registration cycles.
              </p>
            </div>
          </div>
          <button
            onClick={() => onNavigateToTab("explore")}
            className="text-xs sm:text-sm font-semibold text-blue-600 hover:text-blue-800 flex items-center gap-1"
          >
            View All <ChevronRight className="w-4 h-4" />
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {trendingExams.map((exam) => {
            const isSaved = savedExamIds.includes(exam.id);
            return (
              <div
                key={exam.id}
                id={`trending-card-${exam.id}`}
                className="bg-white rounded-2xl border border-slate-200/90 shadow-xs hover:shadow-lg hover:border-blue-300 transition-all duration-200 flex flex-col justify-between overflow-hidden"
              >
                <div className="p-5 space-y-3">
                  {/* Card Top Row */}
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex items-center gap-2">
                      <span className="text-xs px-2.5 py-1 rounded-md bg-blue-50 text-blue-700 font-semibold border border-blue-100">
                        {exam.category}
                      </span>
                      {exam.isOfficialVerified && (
                        <span className="inline-flex items-center gap-0.5 text-[11px] text-emerald-700 bg-emerald-50 px-1.5 py-0.5 rounded font-medium">
                          <ShieldCheck className="w-3 h-3 text-emerald-600" /> Verified
                        </span>
                      )}
                    </div>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onToggleSaveExam(exam.id);
                      }}
                      className={`p-1.5 rounded-lg border transition-colors ${
                        isSaved
                          ? "bg-blue-600 text-white border-blue-600"
                          : "bg-slate-50 text-slate-400 hover:text-blue-600 hover:bg-slate-100 border-slate-200"
                      }`}
                      title={isSaved ? "Remove from saved exams" : "Save to my dashboard"}
                    >
                      <Bookmark className="w-4 h-4 fill-current" />
                    </button>
                  </div>

                  {/* Exam Title & Body */}
                  <div>
                    <h3
                      onClick={() => onSelectExam(exam)}
                      className="text-lg font-bold text-slate-900 hover:text-blue-600 cursor-pointer transition-colors"
                    >
                      {exam.name}
                    </h3>
                    <p className="text-xs text-slate-500 font-medium">{exam.fullName}</p>
                    <p className="text-xs text-slate-600 mt-2 line-clamp-2 leading-relaxed">
                      {exam.shortDescription}
                    </p>
                  </div>

                  {/* Highlights Grid */}
                  <div className="p-3 bg-slate-50 rounded-xl space-y-1.5 text-xs text-slate-600 border border-slate-100">
                    <div className="flex items-center justify-between">
                      <span className="text-slate-400">Eligibility:</span>
                      <span className="font-semibold text-slate-800 text-right truncate max-w-[60%]">
                        {exam.eligibilityLevel}
                      </span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-slate-400">Next Milestone:</span>
                      <span className="font-semibold text-blue-700 text-right truncate max-w-[60%]">
                        {exam.upcomingImportantDate.label} ({exam.upcomingImportantDate.date})
                      </span>
                    </div>
                  </div>
                </div>

                {/* Card Action Footer */}
                <div className="px-5 py-3.5 bg-slate-50/80 border-t border-slate-100 flex items-center justify-between">
                  <span className="text-xs text-slate-500 font-medium">
                    {exam.officialConductingBody}
                  </span>
                  <button
                    onClick={() => onSelectExam(exam)}
                    className="px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold rounded-lg shadow-xs transition-colors flex items-center gap-1"
                  >
                    <span>View Profile</span>
                    <ArrowRight className="w-3 h-3" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* 5. HOW EDUGUIDE AI WORKS */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-gradient-to-tr from-slate-900 to-indigo-950 text-white rounded-3xl p-8 sm:p-12 shadow-2xl relative overflow-hidden">
          <div className="text-center max-w-3xl mx-auto space-y-3 mb-12">
            <span className="px-3 py-1 rounded-full bg-blue-500/20 text-blue-300 text-xs font-semibold border border-blue-400/30">
              Complete Exam Mastery Engine
            </span>
            <h2 className="text-2xl sm:text-4xl font-extrabold font-['Outfit',sans-serif]">
              How EduGuide AI Powers Your Preparation
            </h2>
            <p className="text-slate-300 text-sm sm:text-base">
              From early exploration to the exam day hall ticket, we streamline every critical step.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 relative z-10">
            <div className="bg-white/5 border border-white/10 rounded-2xl p-5 space-y-3 backdrop-blur-xs hover:bg-white/10 transition-colors">
              <div className="w-10 h-10 rounded-xl bg-blue-600 text-white flex items-center justify-center font-bold text-base">
                1
              </div>
              <h3 className="text-lg font-bold text-white">Discover & Match</h3>
              <p className="text-xs text-slate-300 leading-relaxed">
                Filter exams across 8 categories or let our AI analyze your degree, branch, and goals for tailored career roadmaps.
              </p>
            </div>

            <div className="bg-white/5 border border-white/10 rounded-2xl p-5 space-y-3 backdrop-blur-xs hover:bg-white/10 transition-colors">
              <div className="w-10 h-10 rounded-xl bg-indigo-600 text-white flex items-center justify-center font-bold text-base">
                2
              </div>
              <h3 className="text-lg font-bold text-white">Understand Deeply</h3>
              <p className="text-xs text-slate-300 leading-relaxed">
                Access verified age criteria, exam patterns, full syllabi checklists, and official fee details without ambiguity.
              </p>
            </div>

            <div className="bg-white/5 border border-white/10 rounded-2xl p-5 space-y-3 backdrop-blur-xs hover:bg-white/10 transition-colors">
              <div className="w-10 h-10 rounded-xl bg-violet-600 text-white flex items-center justify-center font-bold text-base">
                3
              </div>
              <h3 className="text-lg font-bold text-white">Personalized Study Plan</h3>
              <p className="text-xs text-slate-300 leading-relaxed">
                Generate custom daily study time-slots, high-yield topic targets, and weekly mock test revision schedules.
              </p>
            </div>

            <div className="bg-white/5 border border-white/10 rounded-2xl p-5 space-y-3 backdrop-blur-xs hover:bg-white/10 transition-colors">
              <div className="w-10 h-10 rounded-xl bg-emerald-600 text-white flex items-center justify-center font-bold text-base">
                4
              </div>
              <h3 className="text-lg font-bold text-white">Apply & Never Miss</h3>
              <p className="text-xs text-slate-300 leading-relaxed">
                Follow step-by-step document specifications and receive smart countdown reminders before deadlines close.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* 6. AI GUIDANCE FEATURE PROMOTION */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-gradient-to-r from-blue-50 via-indigo-50 to-sky-50 rounded-3xl p-6 sm:p-10 border border-blue-200/80 shadow-md">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            <div className="lg:col-span-7 space-y-4">
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-md bg-blue-600 text-white text-xs font-bold shadow-xs">
                <Sparkles className="w-3.5 h-3.5" />
                <span>AI Career & Exam Guidance Assistant</span>
              </div>
              <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 font-['Outfit',sans-serif]">
                Unsure which competitive exam suits your qualifications?
              </h2>
              <p className="text-sm text-slate-600 leading-relaxed">
                Tell our AI mentor your current education level, branch, interests, and aspirations. Receive personalized recommendations, eligibility validation, preparation runways, and multi-year career pathways.
              </p>

              {/* Sample Interactive Prompts */}
              <div className="space-y-2 pt-2">
                <p className="text-xs font-bold text-slate-700">Try common career consultation scenarios:</p>
                <div className="flex flex-wrap gap-2">
                  {[
                    { label: "B.Tech CS Graduate → PSU / Tech Govt / M.Tech", data: { educationLevel: "Undergraduate (B.Tech)", degreeOrBranch: "Computer Science & Engineering", interests: "Algorithms, Cloud, Systems, Research", careerGoals: "PSU Group-A Scientist or Masters in IIT" } },
                    { label: "12th PCM Student → Engineering vs Armed Forces (NDA)", data: { educationLevel: "12th Pass (Science)", degreeOrBranch: "PCM (Physics, Chemistry, Maths)", interests: "Defence leadership, Aerospace, Technical service", careerGoals: "Commissioned Military Officer or IITian" } },
                    { label: "Graduate → Civil Services vs Banking PO", data: { educationLevel: "Graduate (Any Discipline)", degreeOrBranch: "Bachelor of Arts / Science", interests: "Public policy, governance, economy, analytical thinking", careerGoals: "Prestigious Government Officer with high impact" } },
                  ].map((scenario, idx) => (
                    <button
                      key={idx}
                      onClick={() => {
                        if (onStartAIGuidanceWithPrompt) {
                          onStartAIGuidanceWithPrompt(scenario.data);
                        }
                        onNavigateToTab("ai-assistant");
                      }}
                      className="px-3 py-1.5 bg-white hover:bg-blue-600 hover:text-white text-slate-700 text-xs font-medium rounded-lg border border-slate-200 shadow-xs transition-colors text-left"
                    >
                      ✨ {scenario.label}
                    </button>
                  ))}
                </div>
              </div>

              <div className="pt-2">
                <button
                  id="launch-ai-assistant-cta"
                  onClick={() => onNavigateToTab("ai-assistant")}
                  className="px-6 py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-bold text-sm shadow-md shadow-blue-500/20 transition-all flex items-center gap-2"
                >
                  <Sparkles className="w-4 h-4" />
                  <span>Launch AI Career Counselor</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Visual preview card */}
            <div className="lg:col-span-5">
              <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-xl space-y-4">
                <div className="flex items-center justify-between pb-3 border-b border-slate-100">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-lg bg-indigo-600 text-white flex items-center justify-center font-bold text-xs">
                      AI
                    </div>
                    <div>
                      <h4 className="text-xs font-bold text-slate-900">EduGuide AI Synthesis</h4>
                      <p className="text-[10px] text-slate-400">Analysis: B.Tech CS Student</p>
                    </div>
                  </div>
                  <span className="text-xs font-bold text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded-full">
                    96% Best Match
                  </span>
                </div>

                <div className="space-y-2 text-xs">
                  <div className="p-2.5 bg-blue-50/70 rounded-lg">
                    <span className="font-bold text-blue-900 block">1. GATE CSE / IT</span>
                    <span className="text-blue-700 text-[11px]">Direct PSU entry (IOCL/ONGC/ISRO) + M.Tech at IISc/IITs.</span>
                  </div>
                  <div className="p-2.5 bg-slate-50 rounded-lg">
                    <span className="font-bold text-slate-900 block">2. ISRO / DRDO Scientist 'SC'</span>
                    <span className="text-slate-600 text-[11px]">Group-A Central Govt research and space missions.</span>
                  </div>
                  <div className="p-2.5 bg-slate-50 rounded-lg">
                    <span className="font-bold text-slate-900 block">3. AWS Solutions Architect</span>
                    <span className="text-slate-600 text-[11px]">Global high-tier cloud architecture credentials.</span>
                  </div>
                </div>

                <div className="text-[11px] text-slate-500 pt-1 border-t border-slate-100 flex items-center gap-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500" />
                  <span>Includes study hours breakdown and eligibility analysis</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 7. CALL TO ACTION & OFFICIAL INTEGRATION BADGE */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-slate-900 text-white rounded-3xl p-8 sm:p-12 text-center space-y-6 shadow-xl">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-300 text-xs font-medium border border-emerald-400/30">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <span>Official Portal Verification Standard</span>
          </div>

          <h2 className="text-2xl sm:text-4xl font-extrabold font-['Outfit',sans-serif] max-w-2xl mx-auto">
            Start Your Competitive Exam Journey with 100% Clarity
          </h2>

          <p className="text-slate-300 text-sm max-w-xl mx-auto leading-relaxed">
            Join thousands of students organizing their exam calendars, syllabus checklists, and AI study schedules with EduGuide AI.
          </p>

          <div className="flex flex-wrap items-center justify-center gap-4 pt-2">
            <button
              onClick={() => onNavigateToTab("explore")}
              className="px-6 py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-bold text-sm shadow-md transition-all flex items-center gap-2"
            >
              <Compass className="w-4 h-4" />
              <span>Explore All Exams</span>
            </button>
            <button
              onClick={() => onNavigateToTab("planner")}
              className="px-6 py-3 bg-white/10 hover:bg-white/20 text-white rounded-xl font-bold text-sm border border-white/20 transition-all flex items-center gap-2"
            >
              <BookOpen className="w-4 h-4" />
              <span>Generate Study Plan</span>
            </button>
          </div>

          <div className="pt-6 border-t border-slate-800 text-xs text-slate-400 flex flex-wrap items-center justify-center gap-6">
            <span className="flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-emerald-400" /> Official Notification Cross-Checks
            </span>
            <span className="flex items-center gap-1.5">
              <Sparkles className="w-4 h-4 text-blue-400" /> AI-Driven Preparation Strategy
            </span>
            <span className="flex items-center gap-1.5">
              <Calendar className="w-4 h-4 text-amber-400" /> Zero Missed Deadlines
            </span>
          </div>
        </div>
      </section>
    </div>
  );
};
