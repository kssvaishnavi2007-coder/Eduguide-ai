import React, { useState, useMemo } from "react";
import {
  Video,
  Play,
  Search,
  Filter,
  Bookmark,
  CheckCircle2,
  Clock,
  Sparkles,
  Award,
  Layers,
  BookOpen,
  ArrowRight,
  ShieldCheck,
  Compass,
} from "lucide-react";
import { Exam, ExamCategory, LearningResource } from "../types";
import { EXAM_CATEGORIES } from "../data/examsData";

interface LearningHubViewProps {
  exams: Exam[];
  onOpenVideoModal: (resource: LearningResource) => void;
  onSelectExam: (exam: Exam) => void;
}

export const LearningHubView: React.FC<LearningHubViewProps> = ({
  exams,
  onOpenVideoModal,
  onSelectExam,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<ExamCategory | "All">("All");
  const [selectedType, setSelectedType] = useState<string>("All");
  const [searchQuery, setSearchQuery] = useState("");
  const [savedVideoIds, setSavedVideoIds] = useState<string[]>([]);

  // Collect all learning resources from all exams
  const allResources = useMemo(() => {
    const list: (LearningResource & { examName: string; examCategory: ExamCategory; examObj: Exam })[] = [];
    exams.forEach((exam) => {
      exam.learningResources.forEach((res) => {
        list.push({
          ...res,
          examName: exam.name,
          examCategory: exam.category,
          examObj: exam,
        });
      });
    });
    return list;
  }, [exams]);

  const toggleSaveVideo = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setSavedVideoIds((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  };

  const filteredResources = useMemo(() => {
    return allResources.filter((res) => {
      const matchCat = selectedCategory === "All" || res.examCategory === selectedCategory;
      const matchType = selectedType === "All" || res.type === selectedType;
      const matchSearch =
        !searchQuery.trim() ||
        res.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        res.examName.toLowerCase().includes(searchQuery.toLowerCase()) ||
        res.instructorOrChannel.toLowerCase().includes(searchQuery.toLowerCase()) ||
        res.keyTakeaways.some((t) => t.toLowerCase().includes(searchQuery.toLowerCase()));

      return matchCat && matchType && matchSearch;
    });
  }, [allResources, selectedCategory, selectedType, searchQuery]);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8 pb-24">
      {/* Header */}
      <div className="space-y-3">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-50 border border-blue-200 text-blue-700 text-xs font-semibold">
          <Video className="w-3.5 h-3.5" />
          <span>Curated Video Learning & Masterclasses</span>
        </div>
        <h1 className="text-3xl sm:text-4xl font-extrabold text-slate-900 font-['Outfit',sans-serif] tracking-tight">
          Learning Video Hub
        </h1>
        <p className="text-sm text-slate-600 max-w-3xl leading-relaxed">
          High-yield strategy masterclasses, comprehensive subject revisions, previous year question (PYQ) pattern dissections, and step-by-step application walkthroughs curated for each competitive exam.
        </p>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs space-y-4">
        <div className="flex flex-col md:flex-row gap-3 items-center justify-between">
          <div className="relative w-full md:max-w-md">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search video title, instructor, or topic..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm text-slate-800 placeholder-slate-400 focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-blue-500/20"
            />
          </div>

          {/* Resource Type Pills */}
          <div className="flex flex-wrap items-center gap-1.5 text-xs w-full md:w-auto">
            <span className="text-slate-400 font-medium mr-1">Resource Type:</span>
            {[
              { id: "All", label: "All Formats" },
              { id: "strategy", label: "Strategy & Roadmap" },
              { id: "syllabus", label: "Syllabus Breakdown" },
              { id: "subject", label: "Subject Masterclass" },
              { id: "pyq", label: "PYQs & Solutions" },
              { id: "application_walkthrough", label: "Form Filling Guide" },
            ].map((type) => (
              <button
                key={type.id}
                onClick={() => setSelectedType(type.id)}
                className={`px-2.5 py-1.5 rounded-lg transition-colors ${
                  selectedType === type.id
                    ? "bg-blue-600 text-white font-semibold"
                    : "bg-slate-100 hover:bg-slate-200 text-slate-700"
                }`}
              >
                {type.label}
              </button>
            ))}
          </div>
        </div>

        {/* Category Pills */}
        <div className="flex items-center gap-1.5 overflow-x-auto text-xs pt-2 border-t border-slate-100">
          <span className="text-slate-400 font-medium shrink-0">Category:</span>
          <button
            onClick={() => setSelectedCategory("All")}
            className={`shrink-0 px-2.5 py-1 rounded-md transition-colors ${
              selectedCategory === "All"
                ? "bg-indigo-100 text-indigo-800 font-bold border border-indigo-200"
                : "bg-slate-50 text-slate-600 hover:bg-slate-100 border border-slate-200"
            }`}
          >
            All Categories ({allResources.length})
          </button>
          {EXAM_CATEGORIES.map((c) => (
            <button
              key={c.id}
              onClick={() => setSelectedCategory(c.id)}
              className={`shrink-0 px-2.5 py-1 rounded-md transition-colors ${
                selectedCategory === c.id
                  ? "bg-indigo-100 text-indigo-800 font-bold border border-indigo-200"
                  : "bg-slate-50 text-slate-600 hover:bg-slate-100 border border-slate-200"
              }`}
            >
              {c.label}
            </button>
          ))}
        </div>
      </div>

      {/* Videos Grid */}
      <div className="space-y-4">
        <div className="flex items-center justify-between text-xs text-slate-500">
          <span>Showing <strong>{filteredResources.length}</strong> learning masterclasses</span>
          <span className="text-blue-600 font-medium">Verified Free & Open Educational Resources</span>
        </div>

        {filteredResources.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredResources.map((res) => {
              const isSaved = savedVideoIds.includes(res.id);

              return (
                <div
                  key={res.id}
                  id={`video-card-${res.id}`}
                  onClick={() => onOpenVideoModal(res)}
                  className="group bg-white rounded-2xl border border-slate-200 shadow-xs hover:shadow-xl hover:border-blue-300 transition-all duration-200 cursor-pointer overflow-hidden flex flex-col justify-between"
                >
                  {/* Thumbnail area */}
                  <div className={`h-44 bg-gradient-to-tr ${res.thumbnailGradient} p-4 flex flex-col justify-between text-white relative`}>
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] px-2.5 py-0.5 bg-black/40 rounded-full font-bold uppercase backdrop-blur-xs">
                        {res.type.replace("_", " ")}
                      </span>
                      <button
                        onClick={(e) => toggleSaveVideo(res.id, e)}
                        className={`p-1.5 rounded-lg backdrop-blur-md transition-colors ${
                          isSaved
                            ? "bg-blue-600 text-white"
                            : "bg-black/30 hover:bg-black/50 text-white"
                        }`}
                        title={isSaved ? "Saved to favorites" : "Save video"}
                      >
                        <Bookmark className="w-3.5 h-3.5 fill-current" />
                      </button>
                    </div>

                    {/* Big Play Button */}
                    <div className="w-14 h-14 rounded-full bg-white/20 hover:bg-white/30 backdrop-blur-md flex items-center justify-center mx-auto group-hover:scale-110 transition-transform shadow-lg">
                      <Play className="w-6 h-6 text-white fill-current ml-1" />
                    </div>

                    <div className="flex items-center justify-between text-[11px] text-slate-200">
                      <span className="font-semibold">{res.examName}</span>
                      <span className="font-mono bg-black/50 px-2 py-0.5 rounded">{res.duration}</span>
                    </div>
                  </div>

                  {/* Body Info */}
                  <div className="p-5 space-y-3">
                    <h3 className="text-sm font-bold text-slate-900 group-hover:text-blue-600 transition-colors line-clamp-2 leading-snug">
                      {res.title}
                    </h3>
                    <p className="text-xs text-slate-500 font-medium">
                      By {res.instructorOrChannel} • {res.viewsCount}
                    </p>

                    {/* Key Takeaways */}
                    <div className="p-3 bg-slate-50 rounded-xl space-y-1.5 text-xs text-slate-600 border border-slate-100">
                      <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">
                        What you'll master:
                      </span>
                      {res.keyTakeaways.slice(0, 2).map((item, idx) => (
                        <p key={idx} className="flex items-start gap-1.5 text-[11px] leading-tight">
                          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0 mt-0.5" />
                          <span className="line-clamp-1">{item}</span>
                        </p>
                      ))}
                    </div>
                  </div>

                  {/* Footer */}
                  <div className="px-5 py-3 bg-slate-50 border-t border-slate-100 flex items-center justify-between text-xs">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onSelectExam(res.examObj);
                      }}
                      className="text-slate-500 hover:text-blue-700 font-medium"
                    >
                      View {res.examName} Exam Profile →
                    </button>
                    <span className="font-bold text-blue-600 flex items-center gap-1">
                      <span>Watch</span>
                      <Play className="w-3 h-3 fill-current" />
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          <div className="bg-white rounded-2xl border border-slate-200 p-12 text-center space-y-3">
            <Video className="w-10 h-10 text-slate-300 mx-auto" />
            <h3 className="text-base font-bold text-slate-800">No videos match your criteria</h3>
            <p className="text-xs text-slate-500">
              Try selecting "All Categories" or searching for general syllabus topics.
            </p>
          </div>
        )}
      </div>
    </div>
  );
};
