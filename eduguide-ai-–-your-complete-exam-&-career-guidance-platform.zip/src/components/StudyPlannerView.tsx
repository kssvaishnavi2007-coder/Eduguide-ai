import React, { useState, useEffect } from "react";
import {
  BookOpen,
  Calendar,
  Clock,
  Sparkles,
  CheckCircle2,
  ListTodo,
  TrendingUp,
  Download,
  Printer,
  RefreshCw,
  Sliders,
  CheckSquare,
  Award,
  Layers,
  ChevronRight,
  Flame,
} from "lucide-react";
import { Exam, StudyPlan } from "../types";

interface StudyPlannerViewProps {
  exams: Exam[];
  activeStudyPlan: StudyPlan | null;
  onSaveStudyPlan: (plan: StudyPlan) => void;
  targetExamPreselected?: Exam | null;
}

export const StudyPlannerView: React.FC<StudyPlannerViewProps> = ({
  exams,
  activeStudyPlan,
  onSaveStudyPlan,
  targetExamPreselected,
}) => {
  const [selectedExamId, setSelectedExamId] = useState(
    targetExamPreselected?.id || activeStudyPlan?.examId || exams[0]?.id || ""
  );
  const [monthsAvailable, setMonthsAvailable] = useState<number>(3);
  const [dailyHours, setDailyHours] = useState<number>(5);
  const [weakSubjects, setWeakSubjects] = useState<string>("Speed, Complex Numericals, Time Management");
  const [targetScore, setTargetScore] = useState<string>("Top 1% Percentile / Rank < 500");

  const [loading, setLoading] = useState(false);
  const [currentPlan, setCurrentPlan] = useState<StudyPlan | null>(activeStudyPlan);
  const [completedTaskIds, setCompletedTaskIds] = useState<string[]>(() => {
    const saved = localStorage.getItem("eduguide_completed_tasks");
    return saved ? JSON.parse(saved) : [];
  });

  useEffect(() => {
    if (targetExamPreselected) {
      setSelectedExamId(targetExamPreselected.id);
    }
  }, [targetExamPreselected]);

  useEffect(() => {
    localStorage.setItem("eduguide_completed_tasks", JSON.stringify(completedTaskIds));
  }, [completedTaskIds]);

  const toggleTaskCompletion = (taskId: string) => {
    setCompletedTaskIds((prev) =>
      prev.includes(taskId) ? prev.filter((id) => id !== taskId) : [...prev, taskId]
    );
  };

  const handleGeneratePlan = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    const examObj = exams.find((e) => e.id === selectedExamId) || exams[0];

    try {
      const res = await fetch("/api/ai/study-plan", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          examName: examObj.name,
          examCategory: examObj.category,
          monthsAvailable,
          dailyHours,
          weakSubjects,
          targetScore,
        }),
      });

      if (!res.ok) throw new Error("Failed to generate plan");

      const planData: StudyPlan = await res.json();
      planData.id = `plan-${Date.now()}`;
      planData.examId = examObj.id;
      planData.examName = examObj.name;
      planData.createdAt = new Date().toISOString();

      setCurrentPlan(planData);
      onSaveStudyPlan(planData);
    } catch (err) {
      console.error("Study plan generation error:", err);
    } finally {
      setLoading(false);
    }
  };

  const handlePrint = () => {
    window.print();
  };

  // Progress metrics calculation
  const totalTasks = currentPlan?.dailySchedule.length || 0;
  const doneTasks = currentPlan?.dailySchedule.filter((_, idx) =>
    completedTaskIds.includes(`task-${idx}`)
  ).length || 0;
  const progressPercent = totalTasks > 0 ? Math.round((doneTasks / totalTasks) * 100) : 0;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8 pb-24">
      {/* Header */}
      <div className="space-y-3">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-50 border border-blue-200 text-blue-700 text-xs font-semibold">
          <BookOpen className="w-3.5 h-3.5" />
          <span>Personalized Study Roadmap Engine</span>
        </div>
        <h1 className="text-3xl sm:text-4xl font-extrabold text-slate-900 font-['Outfit',sans-serif] tracking-tight">
          AI Personalized Study Planner
        </h1>
        <p className="text-sm text-slate-600 max-w-3xl leading-relaxed">
          Transform vast exam syllabi into structured daily revision time blocks, phase-wise mastery milestones, and practice test checkpoints aligned with your available timeline.
        </p>
      </div>

      {/* Plan Configurator + Active Roadmap Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Left Form: Plan Parameters (4 cols) */}
        <div className="lg:col-span-4 bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-5 print:hidden">
          <div className="pb-3 border-b border-slate-100">
            <h3 className="text-base font-bold text-slate-900 font-['Outfit',sans-serif] flex items-center gap-2">
              <Sliders className="w-4 h-4 text-blue-600" />
              Configure Study Blueprint
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Specify your exam and daily capacity.
            </p>
          </div>

          <form onSubmit={handleGeneratePlan} className="space-y-4 text-xs">
            <div>
              <label className="font-bold text-slate-700 block mb-1">Target Competitive Exam:</label>
              <select
                value={selectedExamId}
                onChange={(e) => setSelectedExamId(e.target.value)}
                className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-800 font-semibold"
              >
                {exams.map((exam) => (
                  <option key={exam.id} value={exam.id}>
                    {exam.name} ({exam.category.replace(" Exams", "")})
                  </option>
                ))}
              </select>
            </div>

            <div>
              <div className="flex justify-between font-bold text-slate-700 mb-1">
                <span>Preparation Runway:</span>
                <span className="text-blue-600 font-mono">{monthsAvailable} Months</span>
              </div>
              <div className="grid grid-cols-4 gap-1.5 pt-1">
                {[1, 3, 6, 12].map((m) => (
                  <button
                    key={m}
                    type="button"
                    onClick={() => setMonthsAvailable(m)}
                    className={`py-1.5 rounded-lg font-bold border transition-colors ${
                      monthsAvailable === m
                        ? "bg-blue-600 text-white border-blue-600"
                        : "bg-slate-50 hover:bg-slate-100 text-slate-700 border-slate-200"
                    }`}
                  >
                    {m} {m === 1 ? "Mo" : "Mos"}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <div className="flex justify-between font-bold text-slate-700 mb-1">
                <span>Daily Study Capacity:</span>
                <span className="text-blue-600 font-mono">{dailyHours} Hours / Day</span>
              </div>
              <input
                type="range"
                min={2}
                max={12}
                value={dailyHours}
                onChange={(e) => setDailyHours(Number(e.target.value))}
                className="w-full accent-blue-600 cursor-pointer"
              />
              <div className="flex justify-between text-[10px] text-slate-400 mt-0.5">
                <span>2h (Working/College)</span>
                <span>6h (Full-time)</span>
                <span>12h (Bootcamp)</span>
              </div>
            </div>

            <div>
              <label className="font-bold text-slate-700 block mb-1">Identified Weak Areas / Focus Topics:</label>
              <input
                type="text"
                value={weakSubjects}
                onChange={(e) => setWeakSubjects(e.target.value)}
                placeholder="e.g. Organic Chemistry, Data Structures, English Comprehension"
                className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-800"
              />
            </div>

            <div>
              <label className="font-bold text-slate-700 block mb-1">Target Score / Rank Aspiration:</label>
              <input
                type="text"
                value={targetScore}
                onChange={(e) => setTargetScore(e.target.value)}
                placeholder="e.g. 99+ Percentile, Rank < 100"
                className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-800"
              />
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full py-3 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white rounded-xl font-bold shadow-md shadow-blue-500/20 transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
            >
              {loading ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>Building Custom Schedule...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4" />
                  <span>Generate AI Study Plan</span>
                </>
              )}
            </button>
          </form>

          {/* Quick study habit tip */}
          <div className="p-3.5 bg-indigo-50/60 rounded-xl border border-indigo-100 text-xs text-indigo-900 space-y-1">
            <span className="font-bold flex items-center gap-1">
              <Flame className="w-3.5 h-3.5 text-amber-500" /> Pomodoro + Spaced Repetition:
            </span>
            <p className="text-[11px] text-indigo-800 leading-relaxed">
              Study in 50-minute focused blocks with 10-minute breaks. Review previous day notes before starting new chapters.
            </p>
          </div>
        </div>

        {/* Right Area: Interactive Plan Output (8 cols) */}
        <div className="lg:col-span-8 space-y-6">
          {loading ? (
            <div className="bg-white rounded-2xl border border-slate-200 p-12 text-center space-y-4 shadow-xs">
              <div className="w-12 h-12 rounded-2xl bg-blue-100 text-blue-600 flex items-center justify-center mx-auto animate-spin">
                <RefreshCw className="w-6 h-6" />
              </div>
              <h3 className="text-lg font-bold text-slate-900 font-['Outfit',sans-serif]">
                Designing Your Precision Preparation Roadmap
              </h3>
              <p className="text-xs text-slate-500 max-w-md mx-auto">
                Allocating hours across foundation modules, problem sets, high-yield topics, and simulated mock test series...
              </p>
            </div>
          ) : currentPlan ? (
            <div className="space-y-6 animate-in fade-in duration-200">
              {/* Plan Header Card */}
              <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-4">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-100">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-bold px-2.5 py-0.5 rounded-full bg-blue-50 text-blue-700">
                        Active Study Plan
                      </span>
                      <span className="text-xs text-slate-400">
                        {currentPlan.timeframe} • {currentPlan.dailyStudyHours}
                      </span>
                    </div>
                    <h2 className="text-2xl font-extrabold text-slate-900 font-['Outfit',sans-serif] mt-1">
                      {currentPlan.examName} Mastery Schedule
                    </h2>
                  </div>

                  <div className="flex items-center gap-2 print:hidden">
                    <button
                      onClick={handlePrint}
                      className="p-2 text-slate-600 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors"
                      title="Print or Save as PDF"
                    >
                      <Printer className="w-4 h-4" />
                      <span>Print Plan</span>
                    </button>
                  </div>
                </div>

                {/* Progress Bar Widget */}
                <div className="space-y-2">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-bold text-slate-700 flex items-center gap-1.5">
                      <CheckSquare className="w-4 h-4 text-emerald-600" />
                      Today's Task Completion Progress:
                    </span>
                    <span className="font-mono font-bold text-blue-600">{progressPercent}% Completed</span>
                  </div>
                  <div className="w-full h-2.5 bg-slate-100 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-gradient-to-r from-blue-600 to-indigo-600 transition-all duration-300 rounded-full"
                      style={{ width: `${progressPercent}%` }}
                    />
                  </div>
                </div>
              </div>

              {/* 1. Daily Study Routine (Interactive Checkable Slots) */}
              <div className="bg-white rounded-2xl border border-slate-200 p-6 space-y-4 shadow-xs">
                <div className="flex items-center justify-between pb-2 border-b border-slate-100">
                  <h3 className="text-base font-bold text-slate-900 font-['Outfit',sans-serif] flex items-center gap-2">
                    <Clock className="w-5 h-5 text-blue-600" />
                    Recommended Daily Study Routine
                  </h3>
                  <span className="text-xs text-slate-500 font-medium">Click slots to mark complete</span>
                </div>

                <div className="space-y-3">
                  {currentPlan.dailySchedule.map((slot, idx) => {
                    const taskId = `task-${idx}`;
                    const isDone = completedTaskIds.includes(taskId);

                    return (
                      <div
                        key={idx}
                        onClick={() => toggleTaskCompletion(taskId)}
                        className={`p-4 rounded-xl border cursor-pointer transition-all flex items-start justify-between gap-3 ${
                          isDone
                            ? "bg-emerald-50/50 border-emerald-200"
                            : "bg-slate-50/50 hover:bg-blue-50/50 border-slate-200"
                        }`}
                      >
                        <div className="flex items-start gap-3">
                          <input
                            type="checkbox"
                            checked={isDone}
                            onChange={() => {}}
                            className="w-4 h-4 text-blue-600 rounded border-slate-300 focus:ring-blue-500 mt-1"
                          />
                          <div>
                            <div className="flex items-center gap-2">
                              <span className={`text-xs font-mono font-bold px-2 py-0.5 rounded ${
                                isDone ? "bg-emerald-100 text-emerald-800" : "bg-blue-100 text-blue-700"
                              }`}>
                                {slot.slot}
                              </span>
                              <h4 className={`text-sm font-bold ${isDone ? "line-through text-slate-400" : "text-slate-900"}`}>
                                {slot.activity}
                              </h4>
                            </div>
                            <p className="text-xs text-slate-500 mt-1 leading-relaxed">{slot.focus}</p>
                          </div>
                        </div>

                        <span className="text-xs font-mono text-slate-400 shrink-0 font-medium">{slot.duration}</span>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* 2. Three Phased Preparation Roadmap */}
              <div className="bg-white rounded-2xl border border-slate-200 p-6 space-y-4 shadow-xs">
                <h3 className="text-base font-bold text-slate-900 font-['Outfit',sans-serif] flex items-center gap-2">
                  <Layers className="w-5 h-5 text-indigo-600" />
                  Phased Preparation Strategy Roadmap
                </h3>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {currentPlan.phases.map((phase, pIdx) => (
                    <div
                      key={pIdx}
                      className="p-4 rounded-xl bg-slate-50 border border-slate-200 flex flex-col justify-between space-y-3"
                    >
                      <div>
                        <span className="text-[10px] font-bold uppercase tracking-wider text-blue-700 block">
                          {phase.phase} • {phase.duration}
                        </span>
                        <h4 className="text-sm font-bold text-slate-900 mt-1">{phase.title}</h4>
                        <div className="space-y-1.5 mt-2.5">
                          {phase.keyObjectives.map((obj, oIdx) => (
                            <p key={oIdx} className="text-xs text-slate-600 flex items-start gap-1.5">
                              <CheckCircle2 className="w-3.5 h-3.5 text-blue-500 shrink-0 mt-0.5" />
                              <span>{obj}</span>
                            </p>
                          ))}
                        </div>
                      </div>

                      <div className="pt-2 border-t border-slate-200/80 text-[11px] text-slate-500 flex items-center gap-1 font-medium">
                        <Award className="w-3.5 h-3.5 text-amber-500" />
                        <span>Milestone: {phase.milestone}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* 3. High-Yield Topics Focus & Weekly Checkpoints */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {/* High-Yield Topics */}
                <div className="bg-white rounded-2xl border border-slate-200 p-6 space-y-3 shadow-xs">
                  <h3 className="text-sm font-bold text-slate-900 font-['Outfit',sans-serif] flex items-center gap-2">
                    <Sparkles className="w-4 h-4 text-amber-500" />
                    High-Yield Priority Checklist
                  </h3>
                  <div className="space-y-2 text-xs">
                    {currentPlan.highYieldTopics.map((item, hIdx) => (
                      <div key={hIdx} className="p-2.5 bg-amber-50/50 border border-amber-200 rounded-lg text-slate-800 font-medium flex items-center gap-2">
                        <span className="w-1.5 h-1.5 rounded-full bg-amber-500"></span>
                        <span>{item}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Weekly Mock Test Schedule */}
                <div className="bg-white rounded-2xl border border-slate-200 p-6 space-y-3 shadow-xs">
                  <h3 className="text-sm font-bold text-slate-900 font-['Outfit',sans-serif] flex items-center gap-2">
                    <Calendar className="w-4 h-4 text-emerald-600" />
                    Mock Test & Revision Milestones
                  </h3>
                  <div className="space-y-2 text-xs">
                    {currentPlan.weeklyMilestones.map((m, mIdx) => (
                      <div key={mIdx} className="p-2.5 bg-emerald-50/40 border border-emerald-200 rounded-lg text-slate-800 flex items-start justify-between gap-2">
                        <div>
                          <span className="font-bold text-emerald-900 block">{m.week}</span>
                          <span className="text-slate-600 text-[11px]">{m.deliverable}</span>
                        </div>
                        <span className="text-[10px] font-bold px-2 py-0.5 bg-emerald-100 text-emerald-800 rounded">
                          {m.targetMockScore}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <div className="bg-white rounded-2xl border border-slate-200 p-12 text-center space-y-4 shadow-xs">
              <div className="w-14 h-14 rounded-2xl bg-blue-100 text-blue-600 flex items-center justify-center mx-auto">
                <BookOpen className="w-7 h-7" />
              </div>
              <h3 className="text-lg font-bold text-slate-900 font-['Outfit',sans-serif]">
                No Study Plan Generated Yet
              </h3>
              <p className="text-xs sm:text-sm text-slate-500 max-w-md mx-auto">
                Select your target exam and prep timeframe in the left configurator, then click <strong>“Generate AI Study Plan”</strong> to produce your custom roadmap.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
