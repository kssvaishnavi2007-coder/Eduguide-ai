import React, { useState } from "react";
import {
  ArrowLeft,
  Calendar,
  Clock,
  CheckCircle2,
  AlertTriangle,
  ShieldCheck,
  ExternalLink,
  BookOpen,
  Bookmark,
  FileText,
  CreditCard,
  UploadCloud,
  CheckSquare,
  Sparkles,
  HelpCircle,
  Share2,
  Award,
  Video,
  ListOrdered,
  Bell,
  Layers,
  Info,
} from "lucide-react";
import { Exam, ExamReminder, LearningResource } from "../types";

interface ExamDetailViewProps {
  exam: Exam;
  onBack: () => void;
  isSaved: boolean;
  onToggleSave: (examId: string) => void;
  onAddReminder: (reminder: Omit<ExamReminder, "id">) => void;
  onLaunchStudyPlannerForExam: (exam: Exam) => void;
  onOpenVideoModal: (resource: LearningResource) => void;
}

export const ExamDetailView: React.FC<ExamDetailViewProps> = ({
  exam,
  onBack,
  isSaved,
  onToggleSave,
  onAddReminder,
  onLaunchStudyPlannerForExam,
  onOpenVideoModal,
}) => {
  const [activeTab, setActiveTab] = useState<"overview" | "pattern-syllabus" | "application-guide" | "dates-timeline" | "learning-videos">("overview");
  const [checkedSyllabusTopics, setCheckedSyllabusTopics] = useState<string[]>([]);
  const [copiedUrl, setCopiedUrl] = useState(false);
  const [reminderAddedMsg, setReminderAddedMsg] = useState<string | null>(null);

  const toggleTopicCheck = (topic: string) => {
    setCheckedSyllabusTopics((prev) =>
      prev.includes(topic) ? prev.filter((t) => t !== topic) : [...prev, topic]
    );
  };

  const handleShare = () => {
    navigator.clipboard.writeText(window.location.href);
    setCopiedUrl(true);
    setTimeout(() => setCopiedUrl(false), 2500);
  };

  const handleQuickAddReminder = (eventTitle: string, eventDate: string, eventType: ExamReminder["eventType"]) => {
    onAddReminder({
      examId: exam.id,
      examName: exam.name,
      eventTitle: `${exam.name} - ${eventTitle}`,
      eventDate: eventDate,
      eventType: eventType,
      remindBeforeDays: 3,
    });
    setReminderAddedMsg(`Reminder scheduled for ${eventTitle}!`);
    setTimeout(() => setReminderAddedMsg(null), 3000);
  };

  const totalSyllabusTopicsCount = exam.syllabus.reduce((acc, curr) => acc + curr.topics.length, 0);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6 pb-24">
      {/* Top Breadcrumb & Quick Actions Bar */}
      <div className="flex flex-wrap items-center justify-between gap-4">
        <button
          onClick={onBack}
          id="back-to-explore-btn"
          className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-700 bg-white hover:bg-slate-100 rounded-lg border border-slate-200 shadow-xs transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Exam Directory</span>
        </button>

        <div className="flex items-center gap-2">
          {copiedUrl && (
            <span className="text-xs text-emerald-600 font-medium">Link copied!</span>
          )}
          <button
            onClick={handleShare}
            className="p-2 bg-white text-slate-600 hover:text-slate-900 rounded-lg border border-slate-200 shadow-xs hover:bg-slate-50 transition-colors"
            title="Share this exam profile"
          >
            <Share2 className="w-4 h-4" />
          </button>
          <button
            onClick={() => onToggleSave(exam.id)}
            className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg text-xs font-semibold border transition-all ${
              isSaved
                ? "bg-blue-600 text-white border-blue-600 shadow-xs"
                : "bg-white text-slate-700 hover:bg-slate-50 border-slate-200"
            }`}
          >
            <Bookmark className="w-4 h-4 fill-current" />
            <span>{isSaved ? "Saved to Dashboard" : "Save Exam"}</span>
          </button>
          <button
            onClick={() => onLaunchStudyPlannerForExam(exam)}
            className="flex items-center gap-1.5 px-4 py-1.5 rounded-lg text-xs font-bold bg-gradient-to-r from-indigo-600 to-blue-600 hover:from-indigo-500 hover:to-blue-500 text-white shadow-md shadow-indigo-500/20 transition-all"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>Generate AI Study Plan</span>
          </button>
        </div>
      </div>

      {reminderAddedMsg && (
        <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-xl text-xs font-semibold flex items-center justify-between animate-in fade-in">
          <span className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
            {reminderAddedMsg}
          </span>
          <span className="text-emerald-600">Saved in Timeline & Dashboard</span>
        </div>
      )}

      {/* Official Conducting Body Banner with Verified Stamp */}
      <div className="bg-gradient-to-r from-blue-950 via-slate-900 to-indigo-950 text-white rounded-3xl p-6 sm:p-8 shadow-xl border border-slate-800 relative overflow-hidden">
        <div className="relative z-10 space-y-4">
          <div className="flex flex-wrap items-center gap-2">
            <span className="px-3 py-1 rounded-md bg-blue-500/20 text-blue-300 font-bold text-xs border border-blue-400/30">
              {exam.category}
            </span>
            {exam.isOfficialVerified && (
              <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-md bg-emerald-500/20 text-emerald-300 font-semibold text-xs border border-emerald-400/30">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" /> Verified Official Source
              </span>
            )}
            <span className="text-xs text-slate-300">
              Cycle: {exam.importantDates.cycleYear}
            </span>
          </div>

          <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
            <div className="space-y-2 max-w-3xl">
              <h1 className="text-3xl sm:text-4xl font-extrabold font-['Outfit',sans-serif] tracking-tight text-white">
                {exam.fullName}
              </h1>
              <div className="flex flex-wrap items-center gap-3 text-sm text-slate-300">
                <span className="font-semibold text-white">{exam.name}</span>
                <span>•</span>
                <span>Conducting Body: <strong className="text-slate-100">{exam.officialConductingBody}</strong></span>
              </div>
              <p className="text-xs sm:text-sm text-slate-300 leading-relaxed pt-1">
                {exam.shortDescription}
              </p>
            </div>

            {/* Official Website Button */}
            <div className="flex flex-col sm:flex-row lg:flex-col gap-3 shrink-0">
              <a
                href={exam.officialWebsite}
                target="_blank"
                rel="noreferrer"
                id="official-portal-link"
                className="inline-flex items-center justify-center gap-2 px-4 py-2.5 bg-white hover:bg-slate-100 text-slate-900 rounded-xl text-xs font-bold shadow-md transition-colors"
              >
                <span>Visit Official Portal</span>
                <ExternalLink className="w-3.5 h-3.5 text-blue-600" />
              </a>
              <div className="text-[11px] text-slate-400 flex items-center gap-1 justify-center lg:justify-start">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                <span>Verify circulars directly at source</span>
              </div>
            </div>
          </div>

          {/* Micro Stats Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-4 border-t border-slate-800/80 text-xs">
            <div className="p-3 bg-white/5 rounded-xl border border-white/10">
              <span className="text-slate-400 block">Eligibility Level</span>
              <span className="font-bold text-slate-100 truncate block mt-0.5">{exam.eligibilityLevel}</span>
            </div>
            <div className="p-3 bg-white/5 rounded-xl border border-white/10">
              <span className="text-slate-400 block">Exam Mode</span>
              <span className="font-bold text-slate-100 truncate block mt-0.5">{exam.examPattern.mode}</span>
            </div>
            <div className="p-3 bg-white/5 rounded-xl border border-white/10">
              <span className="text-slate-400 block">Application Fee (Gen)</span>
              <span className="font-bold text-slate-100 truncate block mt-0.5">{exam.applicationFee.general}</span>
            </div>
            <div className="p-3 bg-white/5 rounded-xl border border-white/10">
              <span className="text-slate-400 block">Next Milestone</span>
              <span className="font-bold text-amber-300 truncate block mt-0.5">{exam.upcomingImportantDate.date}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Segmented Tab Navigation */}
      <div className="bg-white rounded-2xl border border-slate-200 p-1.5 shadow-xs overflow-x-auto">
        <div className="flex items-center gap-1 min-w-max">
          {[
            { id: "overview", label: "1. Exam Overview & Eligibility", icon: Info },
            { id: "pattern-syllabus", label: "2. Exam Pattern & Syllabus", icon: BookOpen },
            { id: "application-guide", label: "3. Step-by-Step Application Guide", icon: FileText },
            { id: "dates-timeline", label: "4. Important Dates & Countdown", icon: Calendar },
            { id: "learning-videos", label: "5. Curated Learning Videos", icon: Video },
          ].map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                id={`tab-btn-${tab.id}`}
                onClick={() => setActiveTab(tab.id as any)}
                className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs sm:text-sm font-semibold transition-all ${
                  isActive
                    ? "bg-blue-600 text-white shadow-xs"
                    : "text-slate-600 hover:text-slate-900 hover:bg-slate-100"
                }`}
              >
                <Icon className="w-4 h-4" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* TAB CONTENT AREAS */}

      {/* 1. OVERVIEW & ELIGIBILITY TAB */}
      {activeTab === "overview" && (
        <div className="space-y-6 animate-in fade-in duration-150">
          {/* Detailed Overview */}
          <div className="bg-white rounded-2xl border border-slate-200 p-6 space-y-4">
            <h3 className="text-lg font-bold text-slate-900 font-['Outfit',sans-serif] flex items-center gap-2">
              <Info className="w-5 h-5 text-blue-600" />
              Exam Overview & Purpose
            </h3>
            <p className="text-sm text-slate-700 leading-relaxed">
              {exam.overview}
            </p>
            {exam.salaryOrPerks && (
              <div className="p-4 bg-emerald-50/70 border border-emerald-200 rounded-xl">
                <span className="text-xs font-bold text-emerald-900 block mb-1">Career Compensation & Growth Benchmark:</span>
                <p className="text-xs text-emerald-800 leading-relaxed">{exam.salaryOrPerks}</p>
              </div>
            )}
          </div>

          {/* Detailed Eligibility Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Age Limits & Relaxation */}
            <div className="bg-white rounded-2xl border border-slate-200 p-6 space-y-3">
              <h3 className="text-base font-bold text-slate-900 font-['Outfit',sans-serif] flex items-center gap-2">
                <Clock className="w-5 h-5 text-indigo-600" />
                Age Limit Criteria
              </h3>
              <div className="space-y-2 text-xs text-slate-700">
                <div className="flex justify-between py-1.5 border-b border-slate-100">
                  <span className="text-slate-500 font-medium">Minimum Age:</span>
                  <span className="font-bold text-slate-900">{exam.ageLimit.minAge} Years</span>
                </div>
                <div className="flex justify-between py-1.5 border-b border-slate-100">
                  <span className="text-slate-500 font-medium">Maximum Age:</span>
                  <span className="font-bold text-slate-900">
                    {exam.ageLimit.maxAge >= 90 ? "No Upper Age Limit" : `${exam.ageLimit.maxAge} Years`}
                  </span>
                </div>
                <div className="py-2">
                  <span className="text-slate-500 font-medium block mb-1">Category Age Relaxation:</span>
                  <p className="p-2.5 bg-slate-50 rounded-lg text-slate-700 leading-relaxed border border-slate-100">
                    {exam.ageLimit.relaxation}
                  </p>
                </div>
                <div className="flex justify-between py-1.5 border-t border-slate-100">
                  <span className="text-slate-500 font-medium">Attempts Allowed:</span>
                  <span className="font-bold text-blue-700">{exam.attemptsAllowed}</span>
                </div>
              </div>
            </div>

            {/* Educational Qualification */}
            <div className="bg-white rounded-2xl border border-slate-200 p-6 space-y-3">
              <h3 className="text-base font-bold text-slate-900 font-['Outfit',sans-serif] flex items-center gap-2">
                <Award className="w-5 h-5 text-emerald-600" />
                Educational Qualification Requirements
              </h3>
              <div className="space-y-2 text-xs">
                {exam.educationalQualification.map((qual, idx) => (
                  <div key={idx} className="flex items-start gap-2 p-2.5 bg-slate-50 rounded-lg border border-slate-100">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                    <span className="text-slate-700 leading-relaxed">{qual}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Career Prospects & Pathways */}
          <div className="bg-white rounded-2xl border border-slate-200 p-6 space-y-3">
            <h3 className="text-base font-bold text-slate-900 font-['Outfit',sans-serif]">
              Career Prospects & Pathways Unlocked
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 pt-1">
              {exam.careerProspects.map((prospect, idx) => (
                <div key={idx} className="p-3 bg-blue-50/50 border border-blue-100 rounded-xl text-xs font-medium text-slate-800 flex items-start gap-2">
                  <div className="w-5 h-5 rounded bg-blue-600 text-white flex items-center justify-center text-[10px] font-bold shrink-0 mt-0.5">
                    {idx + 1}
                  </div>
                  <span className="leading-snug">{prospect}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* 2. EXAM PATTERN & SYLLABUS TAB */}
      {activeTab === "pattern-syllabus" && (
        <div className="space-y-6 animate-in fade-in duration-150">
          {/* Exam Pattern Summary */}
          <div className="bg-white rounded-2xl border border-slate-200 p-6 space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-slate-100">
              <h3 className="text-lg font-bold text-slate-900 font-['Outfit',sans-serif] flex items-center gap-2">
                <Layers className="w-5 h-5 text-indigo-600" />
                Examination Pattern & Marking Scheme
              </h3>
              <span className="text-xs px-2.5 py-1 bg-indigo-50 text-indigo-700 font-bold rounded-lg self-start">
                Mode: {exam.examPattern.mode}
              </span>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
              <div className="p-3 bg-slate-50 rounded-xl">
                <span className="text-slate-400 block">Total Duration</span>
                <span className="font-bold text-slate-900 text-sm mt-0.5 block">{exam.examPattern.duration}</span>
              </div>
              <div className="p-3 bg-slate-50 rounded-xl">
                <span className="text-slate-400 block">Total Questions</span>
                <span className="font-bold text-slate-900 text-sm mt-0.5 block">{exam.examPattern.totalQuestions} Questions</span>
              </div>
              <div className="p-3 bg-slate-50 rounded-xl">
                <span className="text-slate-400 block">Total Marks</span>
                <span className="font-bold text-slate-900 text-sm mt-0.5 block">{exam.examPattern.totalMarks} Marks</span>
              </div>
              <div className="p-3 bg-slate-50 rounded-xl">
                <span className="text-slate-400 block">Negative Marking</span>
                <span className="font-bold text-rose-700 text-xs mt-0.5 block">{exam.examPattern.negativeMarking}</span>
              </div>
            </div>

            {/* Sections breakdown table */}
            <div className="pt-2">
              <h4 className="text-xs font-bold text-slate-700 mb-2">Sectional Breakdown:</h4>
              <div className="border border-slate-200 rounded-xl overflow-hidden text-xs">
                <div className="grid grid-cols-12 bg-slate-100 font-bold text-slate-700 p-2.5">
                  <div className="col-span-8">Section Name</div>
                  <div className="col-span-2 text-center">Questions</div>
                  <div className="col-span-2 text-right">Marks</div>
                </div>
                {exam.examPattern.sections.map((sec, idx) => (
                  <div key={idx} className="grid grid-cols-12 p-2.5 border-t border-slate-100 hover:bg-slate-50/70 text-slate-800">
                    <div className="col-span-8 font-medium">{sec.name}</div>
                    <div className="col-span-2 text-center font-mono">{sec.questions}</div>
                    <div className="col-span-2 text-right font-mono font-bold text-blue-700">{sec.marks}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* High Yield Important Topics */}
          <div className="bg-gradient-to-r from-amber-50 to-orange-50 rounded-2xl border border-amber-200 p-6 space-y-3">
            <h3 className="text-base font-bold text-amber-950 font-['Outfit',sans-serif] flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-amber-600" />
              High-Yield Important Topics (Highest Weightage Trends)
            </h3>
            <p className="text-xs text-amber-800">
              Historical analysis shows these topics account for maximum scoring opportunities in {exam.name}:
            </p>
            <div className="flex flex-wrap gap-2 pt-1">
              {exam.importantTopics.map((topic, idx) => (
                <span key={idx} className="px-3 py-1.5 bg-white text-slate-800 text-xs font-semibold rounded-lg border border-amber-300 shadow-2xs">
                  🔥 {topic}
                </span>
              ))}
            </div>
          </div>

          {/* Complete Subject-wise Syllabus with Interactive Topic Checklist */}
          <div className="bg-white rounded-2xl border border-slate-200 p-6 space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-slate-100">
              <div>
                <h3 className="text-lg font-bold text-slate-900 font-['Outfit',sans-serif]">
                  Complete Syllabus & Interactive Mastery Checklist
                </h3>
                <p className="text-xs text-slate-500">
                  Track your preparation progress by checking off topics you have revised.
                </p>
              </div>
              <div className="text-xs font-semibold text-slate-700 bg-slate-100 px-3 py-1.5 rounded-lg self-start sm:self-center">
                Checked: {checkedSyllabusTopics.length} / {totalSyllabusTopicsCount} Topics
              </div>
            </div>

            <div className="space-y-6">
              {exam.syllabus.map((subj, idx) => (
                <div key={idx} className="border border-slate-200 rounded-xl p-5 space-y-3">
                  <div className="flex items-center justify-between pb-2 border-b border-slate-100">
                    <h4 className="text-sm font-bold text-slate-900 text-blue-700">
                      {subj.subject}
                    </h4>
                    {subj.weightage && (
                      <span className="text-xs font-semibold px-2 py-0.5 bg-blue-50 text-blue-700 rounded-md">
                        Weightage: {subj.weightage}
                      </span>
                    )}
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    {subj.topics.map((topic, tIdx) => {
                      const isChecked = checkedSyllabusTopics.includes(topic);
                      return (
                        <label
                          key={tIdx}
                          onClick={() => toggleTopicCheck(topic)}
                          className={`flex items-start gap-2.5 p-2.5 rounded-lg border cursor-pointer transition-colors text-xs ${
                            isChecked
                              ? "bg-emerald-50/70 border-emerald-200 text-slate-800"
                              : "bg-slate-50/50 hover:bg-slate-100 border-slate-200 text-slate-700"
                          }`}
                        >
                          <input
                            type="checkbox"
                            checked={isChecked}
                            onChange={() => {}}
                            className="w-4 h-4 text-emerald-600 rounded border-slate-300 focus:ring-emerald-500 mt-0.5 shrink-0"
                          />
                          <span className={`${isChecked ? "line-through text-slate-400" : ""}`}>
                            {topic}
                          </span>
                        </label>
                      );
                    })}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* 3. STEP-BY-STEP APPLICATION GUIDANCE TAB */}
      {activeTab === "application-guide" && (
        <div className="space-y-6 animate-in fade-in duration-150">
          {/* Important Official Verification Notice */}
          <div className="p-4 bg-amber-50 border border-amber-200 rounded-2xl flex items-start gap-3 text-xs text-amber-900">
            <AlertTriangle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
            <div>
              <span className="font-bold block text-sm mb-0.5">Official Verification & Compliance Notice:</span>
              <p className="leading-relaxed">
                {exam.stepByStepGuidance.officialVerificationNotice} Ensure you cross-check official brochures and notifications at <a href={exam.officialWebsite} target="_blank" rel="noreferrer" className="underline font-bold">{exam.officialWebsite}</a> prior to submitting applications.
              </p>
            </div>
          </div>

          {/* Required Documents Specifications Table */}
          <div className="bg-white rounded-2xl border border-slate-200 p-6 space-y-4">
            <h3 className="text-lg font-bold text-slate-900 font-['Outfit',sans-serif] flex items-center gap-2">
              <UploadCloud className="w-5 h-5 text-blue-600" />
              Required Documents & Exact Upload Specifications
            </h3>
            <div className="overflow-x-auto">
              <table className="w-full text-xs text-left">
                <thead className="bg-slate-100 text-slate-700 font-bold uppercase">
                  <tr>
                    <th className="p-3 rounded-l-lg">Document Name</th>
                    <th className="p-3">Dimensions & Specifications</th>
                    <th className="p-3">Format</th>
                    <th className="p-3">Max Size</th>
                    <th className="p-3 rounded-r-lg">Mandatory</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {exam.stepByStepGuidance.requiredDocuments.map((doc, idx) => (
                    <tr key={idx} className="hover:bg-slate-50">
                      <td className="p-3 font-semibold text-slate-900">{doc.name}</td>
                      <td className="p-3 text-slate-600">{doc.specifications}</td>
                      <td className="p-3 font-mono font-bold text-slate-700">{doc.fileFormat}</td>
                      <td className="p-3 font-mono text-slate-700">{doc.maxSize}</td>
                      <td className="p-3">
                        {doc.isMandatory ? (
                          <span className="px-2 py-0.5 bg-rose-100 text-rose-700 font-bold rounded">Yes</span>
                        ) : (
                          <span className="px-2 py-0.5 bg-slate-100 text-slate-600 rounded">Optional</span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Step by Step Walkthrough */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* 1. Registration Process */}
            <div className="bg-white rounded-2xl border border-slate-200 p-6 space-y-3">
              <h3 className="text-base font-bold text-slate-900 font-['Outfit',sans-serif] flex items-center gap-2">
                <ListOrdered className="w-5 h-5 text-blue-600" />
                Step 1: Registration Process
              </h3>
              <div className="space-y-2 text-xs">
                {exam.stepByStepGuidance.registrationProcess.map((step, idx) => (
                  <div key={idx} className="flex items-start gap-2.5 p-2.5 bg-slate-50 rounded-lg">
                    <span className="w-5 h-5 rounded-full bg-blue-600 text-white font-bold flex items-center justify-center text-[10px] shrink-0 mt-0.5">
                      {idx + 1}
                    </span>
                    <span className="text-slate-700 leading-relaxed">{step}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* 2. Form Filling Steps */}
            <div className="bg-white rounded-2xl border border-slate-200 p-6 space-y-3">
              <h3 className="text-base font-bold text-slate-900 font-['Outfit',sans-serif] flex items-center gap-2">
                <FileText className="w-5 h-5 text-indigo-600" />
                Step 2: Form Filling Guidance
              </h3>
              <div className="space-y-2 text-xs">
                {exam.stepByStepGuidance.formFillingSteps.map((step, idx) => (
                  <div key={idx} className="flex items-start gap-2.5 p-2.5 bg-slate-50 rounded-lg">
                    <span className="w-5 h-5 rounded-full bg-indigo-600 text-white font-bold flex items-center justify-center text-[10px] shrink-0 mt-0.5">
                      {idx + 1}
                    </span>
                    <span className="text-slate-700 leading-relaxed">{step}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* 3. Upload Instructions */}
            <div className="bg-white rounded-2xl border border-slate-200 p-6 space-y-3">
              <h3 className="text-base font-bold text-slate-900 font-['Outfit',sans-serif] flex items-center gap-2">
                <UploadCloud className="w-5 h-5 text-violet-600" />
                Step 3: Upload Instructions
              </h3>
              <div className="space-y-2 text-xs">
                {exam.stepByStepGuidance.uploadInstructions.map((step, idx) => (
                  <div key={idx} className="flex items-start gap-2.5 p-2.5 bg-slate-50 rounded-lg">
                    <CheckCircle2 className="w-4 h-4 text-violet-600 shrink-0 mt-0.5" />
                    <span className="text-slate-700 leading-relaxed">{step}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* 4. Payment Process */}
            <div className="bg-white rounded-2xl border border-slate-200 p-6 space-y-3">
              <h3 className="text-base font-bold text-slate-900 font-['Outfit',sans-serif] flex items-center gap-2">
                <CreditCard className="w-5 h-5 text-emerald-600" />
                Step 4: Application Fee & Payment Modes
              </h3>
              <div className="space-y-2 text-xs">
                <div className="p-3 bg-slate-50 rounded-xl space-y-1">
                  <div className="flex justify-between">
                    <span className="text-slate-500 font-medium">General / OBC:</span>
                    <span className="font-bold text-slate-900">{exam.applicationFee.general}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500 font-medium">SC / ST / PwD:</span>
                    <span className="font-bold text-slate-900">{exam.applicationFee.reserved}</span>
                  </div>
                  <div className="pt-1 flex flex-wrap gap-1 text-[11px] text-slate-500">
                    <span>Payment via:</span>
                    {exam.applicationFee.paymentModes.map((m, i) => (
                      <span key={i} className="px-1.5 py-0.5 bg-white rounded border border-slate-200">{m}</span>
                    ))}
                  </div>
                </div>
                {exam.stepByStepGuidance.paymentProcess.map((step, idx) => (
                  <div key={idx} className="flex items-start gap-2.5 p-2.5 bg-slate-50 rounded-lg">
                    <span className="w-5 h-5 rounded-full bg-emerald-600 text-white font-bold flex items-center justify-center text-[10px] shrink-0 mt-0.5">
                      ✓
                    </span>
                    <span className="text-slate-700 leading-relaxed">{step}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Final Submission Checklist */}
          <div className="bg-white rounded-2xl border border-slate-200 p-6 space-y-3">
            <h3 className="text-base font-bold text-slate-900 font-['Outfit',sans-serif] flex items-center gap-2">
              <CheckSquare className="w-5 h-5 text-emerald-600" />
              Final Submission Pre-Flight Checklist
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-1">
              {exam.stepByStepGuidance.finalSubmissionChecklist.map((item, idx) => (
                <div key={idx} className="p-3 bg-emerald-50/50 border border-emerald-200 rounded-xl text-xs text-emerald-950 font-medium flex items-start gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                  <span className="leading-snug">{item}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* 4. IMPORTANT DATES & TIMELINE TAB */}
      {activeTab === "dates-timeline" && (
        <div className="space-y-6 animate-in fade-in duration-150">
          <div className="bg-white rounded-2xl border border-slate-200 p-6 space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-100">
              <div>
                <h3 className="text-lg font-bold text-slate-900 font-['Outfit',sans-serif]">
                  Exam Schedule Roadmap ({exam.importantDates.cycleYear})
                </h3>
                <p className="text-xs text-slate-500">
                  Set instant alerts for registration deadlines, admit cards, and examination dates.
                </p>
              </div>
            </div>

            {/* Timeline Milestones Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
              {[
                { title: "Application Start", date: exam.importantDates.applicationStart, type: "registration" as const, desc: "Online portal opens for registration" },
                { title: "Application Deadline", date: exam.importantDates.applicationEnd, type: "registration" as const, desc: "Last date for submission & fee payment", urgent: true },
                { title: "Admit Card Release", date: exam.importantDates.admitCardDate, type: "admitCard" as const, desc: "Hall ticket download goes live" },
                { title: "Examination Date", date: exam.importantDates.examDate, type: "exam" as const, desc: "Test center examination day", highlight: true },
                { title: "Result Announcement", date: exam.importantDates.resultDate, type: "result" as const, desc: "Official scorecard & cutoffs published" },
              ].map((milestone, idx) => (
                <div
                  key={idx}
                  className={`p-4 rounded-2xl border flex flex-col justify-between space-y-3 ${
                    milestone.highlight
                      ? "bg-blue-50/80 border-blue-300 ring-2 ring-blue-500/20"
                      : milestone.urgent
                      ? "bg-rose-50/70 border-rose-200"
                      : "bg-slate-50/60 border-slate-200"
                  }`}
                >
                  <div>
                    <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500 block">
                      Milestone {idx + 1}
                    </span>
                    <h4 className="text-sm font-bold text-slate-900 mt-1">{milestone.title}</h4>
                    <p className="text-xs font-mono font-bold text-blue-700 mt-1">{milestone.date}</p>
                    <p className="text-[11px] text-slate-500 mt-2 leading-relaxed">{milestone.desc}</p>
                  </div>

                  <button
                    onClick={() => handleQuickAddReminder(milestone.title, milestone.date, milestone.type)}
                    className="w-full py-2 bg-white hover:bg-blue-600 hover:text-white text-slate-700 border border-slate-200 rounded-xl text-xs font-semibold shadow-xs transition-colors flex items-center justify-center gap-1.5"
                  >
                    <Bell className="w-3.5 h-3.5" />
                    <span>Set Reminder</span>
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* 5. CURATED LEARNING VIDEOS TAB */}
      {activeTab === "learning-videos" && (
        <div className="space-y-6 animate-in fade-in duration-150">
          <div className="bg-white rounded-2xl border border-slate-200 p-6 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div>
                <h3 className="text-lg font-bold text-slate-900 font-['Outfit',sans-serif]">
                  Exam-Specific Video Learning Hub for {exam.name}
                </h3>
                <p className="text-xs text-slate-500">
                  Curated strategy masterclasses, syllabus breakdowns, and previous year question discussions.
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
              {exam.learningResources.map((res) => (
                <div
                  key={res.id}
                  onClick={() => onOpenVideoModal(res)}
                  className="group bg-white rounded-2xl border border-slate-200/90 shadow-xs hover:shadow-lg hover:border-blue-300 transition-all cursor-pointer overflow-hidden flex flex-col justify-between"
                >
                  <div className={`h-40 bg-gradient-to-tr ${res.thumbnailGradient} p-4 flex flex-col justify-between text-white relative`}>
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] px-2 py-0.5 bg-black/40 rounded-full font-bold uppercase backdrop-blur-xs">
                        {res.type}
                      </span>
                      <span className="text-[11px] font-mono bg-black/50 px-2 py-0.5 rounded">
                        {res.duration}
                      </span>
                    </div>

                    <div className="w-12 h-12 rounded-full bg-white/20 hover:bg-white/30 backdrop-blur-md flex items-center justify-center mx-auto group-hover:scale-110 transition-transform">
                      <Video className="w-6 h-6 text-white" />
                    </div>

                    <div className="text-[11px] text-slate-200 truncate">
                      {res.instructorOrChannel} • {res.viewsCount}
                    </div>
                  </div>

                  <div className="p-4 space-y-2">
                    <h4 className="text-sm font-bold text-slate-900 group-hover:text-blue-600 transition-colors line-clamp-2">
                      {res.title}
                    </h4>
                    <div className="space-y-1 pt-1">
                      {res.keyTakeaways.slice(0, 2).map((takeaway, tIdx) => (
                        <p key={tIdx} className="text-[11px] text-slate-500 flex items-start gap-1.5">
                          <CheckCircle2 className="w-3 h-3 text-blue-500 shrink-0 mt-0.5" />
                          <span className="truncate">{takeaway}</span>
                        </p>
                      ))}
                    </div>
                  </div>

                  <div className="p-3 bg-slate-50 border-t border-slate-100 flex items-center justify-between text-xs font-semibold text-blue-600">
                    <span>Watch Interactive Video</span>
                    <span>▶</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
