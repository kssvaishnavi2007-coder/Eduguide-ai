import React, { useState, useEffect, useRef } from "react";
import {
  Sparkles,
  Send,
  Bot,
  User,
  CheckCircle2,
  AlertCircle,
  Clock,
  Award,
  ArrowRight,
  RefreshCw,
  BookOpen,
  MessageSquare,
  Sliders,
  HelpCircle,
  ExternalLink,
} from "lucide-react";
import { AIGuidanceResponse, Exam } from "../types";

interface AIAssistantViewProps {
  exams: Exam[];
  onSelectExam: (exam: Exam) => void;
  onLaunchStudyPlannerForExam: (exam: Exam) => void;
  initialPromptData?: {
    educationLevel: string;
    degreeOrBranch: string;
    interests: string;
    careerGoals: string;
  } | null;
}

interface ChatMessage {
  id: string;
  sender: "user" | "ai";
  text: string;
  timestamp: string;
}

export const AIAssistantView: React.FC<AIAssistantViewProps> = ({
  exams,
  onSelectExam,
  onLaunchStudyPlannerForExam,
  initialPromptData,
}) => {
  const [activeMode, setActiveMode] = useState<"assessment" | "chat">("assessment");

  // Assessment Form State
  const [educationLevel, setEducationLevel] = useState(
    initialPromptData?.educationLevel || "Undergraduate (B.Tech / B.E)"
  );
  const [degreeOrBranch, setDegreeOrBranch] = useState(
    initialPromptData?.degreeOrBranch || "Computer Science & Engineering"
  );
  const [interests, setInterests] = useState(
    initialPromptData?.interests || "Software development, cloud infrastructure, AI research, problem solving"
  );
  const [careerGoals, setCareerGoals] = useState(
    initialPromptData?.careerGoals || "Secure a prestigious PSU engineering role (IOCL/ISRO) or join top IIT for M.Tech"
  );
  const [availableDailyHours, setAvailableDailyHours] = useState(4);

  const [loadingAssessment, setLoadingAssessment] = useState(false);
  const [assessmentResult, setAssessmentResult] = useState<AIGuidanceResponse | null>(null);
  const [assessmentError, setAssessmentError] = useState<string | null>(null);

  // Chat State
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([
    {
      id: "welcome-msg",
      sender: "ai",
      text: "Hello! I am your **EduGuide AI Counselor**. Ask me anything about competitive exam eligibilities, syllabus deep-dives, high-scoring strategies, best reference books, cutoffs, or career pathways!",
      timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
    },
  ]);
  const [chatInput, setChatInput] = useState("");
  const [chatLoading, setChatLoading] = useState(false);
  const chatBottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (initialPromptData) {
      setEducationLevel(initialPromptData.educationLevel);
      setDegreeOrBranch(initialPromptData.degreeOrBranch);
      setInterests(initialPromptData.interests);
      setCareerGoals(initialPromptData.careerGoals);
      // Auto-run guidance if provided
      handleGenerateGuidance();
    }
  }, [initialPromptData]);

  useEffect(() => {
    chatBottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [chatMessages, chatLoading]);

  const handleGenerateGuidance = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setLoadingAssessment(true);
    setAssessmentError(null);

    try {
      const res = await fetch("/api/ai/guidance", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          educationLevel,
          degreeOrBranch,
          interests,
          careerGoals,
          availableDailyHours,
        }),
      });

      if (!res.ok) {
        throw new Error(`Server responded with status ${res.status}`);
      }

      const data: AIGuidanceResponse = await res.json();
      setAssessmentResult(data);
    } catch (err: any) {
      console.error("AI Guidance fetch error:", err);
      setAssessmentError("Failed to connect to AI server. Please check your network and try again.");
    } finally {
      setLoadingAssessment(false);
    }
  };

  const handleSendChat = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!chatInput.trim() || chatLoading) return;

    const userText = chatInput.trim();
    const newMsg: ChatMessage = {
      id: `user-${Date.now()}`,
      sender: "user",
      text: userText,
      timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
    };

    setChatMessages((prev) => [...prev, newMsg]);
    setChatInput("");
    setChatLoading(true);

    try {
      const res = await fetch("/api/ai/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          message: userText,
          context: `User Education: ${educationLevel}, Branch: ${degreeOrBranch}, Goals: ${careerGoals}`,
        }),
      });

      const data = await res.json();
      const aiReply: ChatMessage = {
        id: `ai-${Date.now()}`,
        sender: "ai",
        text: data.reply || "I am analyzing that question. Let me know if you need specific syllabus details.",
        timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
      };
      setChatMessages((prev) => [...prev, aiReply]);
    } catch (err) {
      const errorReply: ChatMessage = {
        id: `err-${Date.now()}`,
        sender: "ai",
        text: "I experienced a temporary connection glitch. However, you can review exam eligibility, patterns, and syllabus directly in our Explore Exams directory.",
        timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
      };
      setChatMessages((prev) => [...prev, errorReply]);
    } finally {
      setChatLoading(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8 pb-24">
      {/* Header */}
      <div className="space-y-3">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-gradient-to-r from-indigo-100 to-blue-100 border border-indigo-200 text-indigo-800 text-xs font-bold shadow-2xs">
          <Sparkles className="w-3.5 h-3.5 text-indigo-600" />
          <span>EduGuide AI Career & Exam Advisor</span>
        </div>
        <h1 className="text-3xl sm:text-4xl font-extrabold text-slate-900 font-['Outfit',sans-serif] tracking-tight">
          AI Career & Exam Guidance Assistant
        </h1>
        <p className="text-sm text-slate-600 max-w-3xl leading-relaxed">
          Unsure which national or international examinations match your current degree? Let our AI intelligence map your educational profile against 100+ entrance tests, eligibility requirements, and career roadmaps.
        </p>
      </div>

      {/* Mode Switcher Tabs */}
      <div className="flex items-center bg-white p-1.5 rounded-2xl border border-slate-200 shadow-xs max-w-md">
        <button
          id="mode-btn-assessment"
          onClick={() => setActiveMode("assessment")}
          className={`flex-1 py-2.5 px-4 rounded-xl text-xs font-bold flex items-center justify-center gap-2 transition-all ${
            activeMode === "assessment"
              ? "bg-blue-600 text-white shadow-xs"
              : "text-slate-600 hover:text-slate-900 hover:bg-slate-50"
          }`}
        >
          <Sliders className="w-4 h-4" />
          <span>Profile Assessment & Match</span>
        </button>
        <button
          id="mode-btn-chat"
          onClick={() => setActiveMode("chat")}
          className={`flex-1 py-2.5 px-4 rounded-xl text-xs font-bold flex items-center justify-center gap-2 transition-all ${
            activeMode === "chat"
              ? "bg-blue-600 text-white shadow-xs"
              : "text-slate-600 hover:text-slate-900 hover:bg-slate-50"
          }`}
        >
          <MessageSquare className="w-4 h-4" />
          <span>Interactive AI Chat Counselor</span>
        </button>
      </div>

      {/* MODE 1: ASSESSMENT & EXAM MATCHING WIZARD */}
      {activeMode === "assessment" && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Assessment Input Form (5 cols) */}
          <div className="lg:col-span-5 bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-5">
            <div className="pb-3 border-b border-slate-100">
              <h3 className="text-base font-bold text-slate-900 font-['Outfit',sans-serif] flex items-center gap-2">
                <Sliders className="w-4 h-4 text-blue-600" />
                Your Education & Aspirations Profile
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Fill in your current status to generate custom match scores.
              </p>
            </div>

            <form onSubmit={handleGenerateGuidance} className="space-y-4 text-xs">
              <div>
                <label className="font-bold text-slate-700 block mb-1">Education Level:</label>
                <select
                  value={educationLevel}
                  onChange={(e) => setEducationLevel(e.target.value)}
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-800 font-medium focus:outline-hidden focus:ring-2 focus:ring-blue-500/20"
                >
                  <option value="10th Standard / Matriculation">10th Standard / Matriculation</option>
                  <option value="12th Pass (Science - PCM/PCB)">12th Pass (Science - PCM/PCB)</option>
                  <option value="12th Pass (Commerce / Arts / Humanities)">12th Pass (Commerce / Arts / Humanities)</option>
                  <option value="Undergraduate (B.Tech / B.E)">Undergraduate (B.Tech / B.E)</option>
                  <option value="Undergraduate (B.Sc / BCA / B.Com / B.A)">Undergraduate (B.Sc / BCA / B.Com / B.A)</option>
                  <option value="Medical Graduate (MBBS / BDS / Allied)">Medical Graduate (MBBS / BDS / Allied)</option>
                  <option value="Postgraduate (M.Tech / M.Sc / MBA / M.A)">Postgraduate (M.Tech / M.Sc / MBA / M.A)</option>
                  <option value="Working Professional (1-5 Years Experience)">Working Professional (1-5 Years Experience)</option>
                </select>
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">Degree, Specialization or Stream:</label>
                <input
                  type="text"
                  required
                  value={degreeOrBranch}
                  onChange={(e) => setDegreeOrBranch(e.target.value)}
                  placeholder="e.g. Computer Science, Mechanical, Life Sciences, Economics"
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-blue-500/20"
                />
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">Core Interests & Strengths:</label>
                <textarea
                  rows={2}
                  value={interests}
                  onChange={(e) => setInterests(e.target.value)}
                  placeholder="e.g. Mathematics, analytical puzzles, coding, public administration, healthcare"
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-blue-500/20 resize-none"
                />
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">Career Goal / Dream Outcome:</label>
                <textarea
                  rows={2}
                  value={careerGoals}
                  onChange={(e) => setCareerGoals(e.target.value)}
                  placeholder="e.g. Central Govt Group-A officer, Top IIT M.Tech, Cloud Architect, Doctor"
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-blue-500/20 resize-none"
                />
              </div>

              <div>
                <div className="flex justify-between font-bold text-slate-700 mb-1">
                  <span>Available Daily Study Time:</span>
                  <span className="text-blue-600 font-mono">{availableDailyHours} Hours / Day</span>
                </div>
                <input
                  type="range"
                  min={2}
                  max={12}
                  value={availableDailyHours}
                  onChange={(e) => setAvailableDailyHours(Number(e.target.value))}
                  className="w-full accent-blue-600 cursor-pointer"
                />
                <div className="flex justify-between text-[10px] text-slate-400 mt-1">
                  <span>2 hrs (Light)</span>
                  <span>6 hrs (Balanced)</span>
                  <span>12 hrs (Intense)</span>
                </div>
              </div>

              <button
                type="submit"
                id="generate-guidance-btn"
                disabled={loadingAssessment}
                className="w-full py-3 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white rounded-xl font-bold shadow-md shadow-blue-500/20 transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
              >
                {loadingAssessment ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    <span>Analyzing 100+ Exam Pathways...</span>
                  </>
                ) : (
                  <>
                    <Sparkles className="w-4 h-4" />
                    <span>Generate AI Career Recommendations</span>
                  </>
                )}
              </button>
            </form>
          </div>

          {/* Assessment Output Area (7 cols) */}
          <div className="lg:col-span-7 space-y-6">
            {loadingAssessment ? (
              <div className="bg-white rounded-2xl border border-slate-200 p-12 text-center space-y-4 shadow-xs">
                <div className="w-12 h-12 rounded-2xl bg-blue-100 text-blue-600 flex items-center justify-center mx-auto animate-bounce">
                  <Sparkles className="w-6 h-6" />
                </div>
                <h3 className="text-lg font-bold text-slate-900 font-['Outfit',sans-serif]">
                  Synthesizing Personalized Exam Recommendations
                </h3>
                <p className="text-xs text-slate-500 max-w-md mx-auto leading-relaxed">
                  Evaluating eligibility constraints, branch syllabus alignment, cutoff trends, and multi-year career progression models...
                </p>
              </div>
            ) : assessmentResult ? (
              <div className="space-y-6 animate-in fade-in duration-200">
                {/* Executive Summary Card */}
                <div className="bg-gradient-to-r from-blue-900 to-indigo-900 text-white rounded-2xl p-6 shadow-lg space-y-3">
                  <div className="flex items-center gap-2">
                    <span className="p-1 rounded bg-white/20 text-white">
                      <Sparkles className="w-4 h-4" />
                    </span>
                    <span className="text-xs font-bold uppercase tracking-wider text-blue-200">
                      Counselor Strategic Assessment
                    </span>
                  </div>
                  <h3 className="text-xl font-bold font-['Outfit',sans-serif]">
                    Personalized Career Blueprint
                  </h3>
                  <p className="text-xs sm:text-sm text-slate-200 leading-relaxed">
                    {assessmentResult.summary}
                  </p>
                </div>

                {/* Top Recommended Exams List */}
                <div className="space-y-4">
                  <h3 className="text-base font-bold text-slate-900 font-['Outfit',sans-serif] flex items-center justify-between">
                    <span>Ranked Exam Matches</span>
                    <span className="text-xs text-slate-400 font-normal">Based on your degree & goal</span>
                  </h3>

                  {assessmentResult.recommendedExams.map((rec, idx) => {
                    const matchedExam = exams.find(
                      (e) =>
                        e.name.toLowerCase().includes(rec.examName.toLowerCase()) ||
                        rec.examName.toLowerCase().includes(e.name.toLowerCase())
                    );

                    return (
                      <div
                        key={idx}
                        className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs space-y-4 hover:border-blue-300 transition-colors"
                      >
                        <div className="flex items-start justify-between gap-3">
                          <div>
                            <div className="flex items-center gap-2">
                              <span className="w-6 h-6 rounded-md bg-blue-600 text-white flex items-center justify-center text-xs font-bold">
                                #{idx + 1}
                              </span>
                              <h4 className="text-base font-bold text-slate-900">{rec.examName}</h4>
                              <span className="text-[11px] px-2 py-0.5 rounded-full bg-slate-100 text-slate-600 font-semibold">
                                {rec.category}
                              </span>
                            </div>
                          </div>
                          <span className="px-3 py-1 bg-emerald-50 text-emerald-700 font-bold text-xs rounded-full border border-emerald-200 shrink-0">
                            {rec.matchPercentage}% Match
                          </span>
                        </div>

                        {/* Rationale */}
                        <p className="text-xs text-slate-600 leading-relaxed bg-slate-50 p-3 rounded-xl border border-slate-100">
                          <strong className="text-slate-800 block mb-0.5">Why this fits your profile:</strong>
                          {rec.rationale}
                        </p>

                        {/* Metrics 3-box */}
                        <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 text-xs">
                          <div className="p-2.5 bg-blue-50/50 rounded-lg border border-blue-100">
                            <span className="text-[11px] font-bold text-blue-900 block">Eligibility Check</span>
                            <span className="text-slate-600 text-[11px] mt-0.5 block">{rec.eligibilityAnalysis}</span>
                          </div>
                          <div className="p-2.5 bg-indigo-50/50 rounded-lg border border-indigo-100">
                            <span className="text-[11px] font-bold text-indigo-900 block">Career Scope</span>
                            <span className="text-slate-600 text-[11px] mt-0.5 block">{rec.careerScope}</span>
                          </div>
                          <div className="p-2.5 bg-slate-50 rounded-lg border border-slate-100">
                            <span className="text-[11px] font-bold text-slate-800 block">Suggested Runway</span>
                            <span className="text-slate-600 text-[11px] mt-0.5 block">{rec.preparationRunway}</span>
                          </div>
                        </div>

                        {/* Actions */}
                        <div className="pt-2 border-t border-slate-100 flex flex-wrap items-center justify-between gap-2 text-xs">
                          {matchedExam ? (
                            <button
                              onClick={() => onSelectExam(matchedExam)}
                              className="text-blue-600 hover:text-blue-800 font-bold flex items-center gap-1"
                            >
                              <span>View Complete {matchedExam.name} Profile & Syllabus</span>
                              <ArrowRight className="w-3.5 h-3.5" />
                            </button>
                          ) : (
                            <span className="text-slate-400 text-[11px]">Exam covered in national syllabus directory</span>
                          )}

                          <button
                            onClick={() => {
                              if (matchedExam) onLaunchStudyPlannerForExam(matchedExam);
                            }}
                            className="px-3 py-1.5 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 font-semibold rounded-lg transition-colors flex items-center gap-1"
                          >
                            <BookOpen className="w-3.5 h-3.5" />
                            <span>Create Study Schedule</span>
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>

                {/* Immediate Next Steps & Action Items */}
                <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs space-y-3">
                  <h3 className="text-sm font-bold text-slate-900 font-['Outfit',sans-serif] flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                    Immediate Recommended Action Plan (Next 14 Days)
                  </h3>
                  <div className="space-y-2 text-xs">
                    {assessmentResult.nextSteps.map((step, sIdx) => (
                      <div key={sIdx} className="flex items-start gap-2 p-2.5 bg-emerald-50/40 rounded-lg border border-emerald-100">
                        <span className="w-5 h-5 rounded-full bg-emerald-600 text-white font-bold flex items-center justify-center text-[10px] shrink-0 mt-0.5">
                          {sIdx + 1}
                        </span>
                        <span className="text-slate-700 leading-relaxed">{step}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Expert Guidance Note */}
                <div className="p-4 bg-amber-50 rounded-2xl border border-amber-200 text-xs text-amber-900">
                  <span className="font-bold block mb-1">Mentor Guidance Note:</span>
                  <p className="leading-relaxed">{assessmentResult.expertAdvice}</p>
                </div>
              </div>
            ) : (
              /* Default state before running */
              <div className="bg-white rounded-2xl border border-slate-200 p-8 shadow-xs text-center space-y-4">
                <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-blue-600 to-indigo-600 text-white flex items-center justify-center mx-auto shadow-md">
                  <Sparkles className="w-7 h-7" />
                </div>
                <h3 className="text-xl font-bold text-slate-900 font-['Outfit',sans-serif]">
                  Ready to Discover Your Ideal Exam Pathway?
                </h3>
                <p className="text-xs sm:text-sm text-slate-600 max-w-md mx-auto leading-relaxed">
                  Review your education profile on the left and click <strong>“Generate AI Career Recommendations”</strong> to get real-time ranked options with match percentages and roadmaps.
                </p>
                <div className="pt-2 flex flex-wrap justify-center gap-2 text-xs text-slate-500">
                  <span className="px-2.5 py-1 bg-slate-50 rounded-md border border-slate-200">✓ 100+ Exam Cross-Mapping</span>
                  <span className="px-2.5 py-1 bg-slate-50 rounded-md border border-slate-200">✓ Strict Eligibility Verification</span>
                  <span className="px-2.5 py-1 bg-slate-50 rounded-md border border-slate-200">✓ Timeline Runway Estimator</span>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* MODE 2: INTERACTIVE AI CHAT COUNSELOR */}
      {activeMode === "chat" && (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-xs flex flex-col h-[600px] overflow-hidden">
          {/* Chat Header */}
          <div className="p-4 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-blue-600 text-white flex items-center justify-center shadow-xs">
                <Bot className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-slate-900">EduGuide AI Live Counselor</h3>
                <p className="text-[11px] text-emerald-600 font-semibold flex items-center gap-1">
                  <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
                  Online • Verified Exam Information Base
                </p>
              </div>
            </div>

            <div className="text-xs text-slate-500 hidden sm:block">
              Context: {degreeOrBranch}
            </div>
          </div>

          {/* Messages Stream */}
          <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-4">
            {chatMessages.map((msg) => (
              <div
                key={msg.id}
                className={`flex gap-3 ${msg.sender === "user" ? "justify-end" : "justify-start"}`}
              >
                {msg.sender === "ai" && (
                  <div className="w-8 h-8 rounded-lg bg-blue-100 text-blue-700 flex items-center justify-center text-xs font-bold shrink-0">
                    AI
                  </div>
                )}
                <div
                  className={`max-w-xl p-4 rounded-2xl text-xs sm:text-sm leading-relaxed ${
                    msg.sender === "user"
                      ? "bg-blue-600 text-white rounded-tr-none"
                      : "bg-slate-100 text-slate-800 rounded-tl-none border border-slate-200/80"
                  }`}
                >
                  <p className="whitespace-pre-wrap">{msg.text}</p>
                  <span
                    className={`block text-[10px] mt-2 ${
                      msg.sender === "user" ? "text-blue-200 text-right" : "text-slate-400"
                    }`}
                  >
                    {msg.timestamp}
                  </span>
                </div>
                {msg.sender === "user" && (
                  <div className="w-8 h-8 rounded-lg bg-slate-800 text-white flex items-center justify-center text-xs font-bold shrink-0">
                    <User className="w-4 h-4" />
                  </div>
                )}
              </div>
            ))}

            {chatLoading && (
              <div className="flex gap-3 justify-start">
                <div className="w-8 h-8 rounded-lg bg-blue-100 text-blue-700 flex items-center justify-center text-xs font-bold">
                  AI
                </div>
                <div className="p-4 rounded-2xl rounded-tl-none bg-slate-100 border border-slate-200 text-xs text-slate-500 flex items-center gap-2">
                  <RefreshCw className="w-3.5 h-3.5 animate-spin text-blue-600" />
                  <span>Analyzing official syllabi & guidance database...</span>
                </div>
              </div>
            )}
            <div ref={chatBottomRef} />
          </div>

          {/* Quick Starter Prompts */}
          <div className="px-4 py-2 bg-slate-50 border-t border-slate-200 flex items-center gap-1.5 overflow-x-auto text-xs">
            <span className="text-slate-400 font-medium shrink-0">Ask:</span>
            {[
              "What is the exact marking scheme and negative marking in JEE Main?",
              "How should I balance college semester exams with GATE preparation?",
              "What are the best standard reference books for UPSC Civil Services GS Paper 1?",
              "Is there any upper age limit for NEET UG 2026?",
            ].map((prompt, pIdx) => (
              <button
                key={pIdx}
                type="button"
                onClick={() => setChatInput(prompt)}
                className="shrink-0 px-2.5 py-1 bg-white hover:bg-blue-50 hover:text-blue-700 text-slate-600 rounded-md border border-slate-200 transition-colors text-[11px]"
              >
                {prompt}
              </button>
            ))}
          </div>

          {/* Chat Input Bar */}
          <form onSubmit={handleSendChat} className="p-3 bg-white border-t border-slate-200 flex items-center gap-2">
            <input
              id="ai-chat-input"
              type="text"
              value={chatInput}
              onChange={(e) => setChatInput(e.target.value)}
              placeholder="Ask anything about competitive exams, syllabus, books, cutoffs..."
              className="flex-1 px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm text-slate-800 focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-blue-500/20"
            />
            <button
              type="submit"
              disabled={!chatInput.trim() || chatLoading}
              className="p-3 bg-blue-600 hover:bg-blue-700 text-white rounded-xl transition-colors disabled:opacity-40"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>
        </div>
      )}
    </div>
  );
};
