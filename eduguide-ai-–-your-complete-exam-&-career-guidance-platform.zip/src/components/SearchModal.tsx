import React, { useState, useEffect, useRef } from "react";
import { Search, X, Compass, ArrowRight, ShieldCheck, Calendar, Sparkles } from "lucide-react";
import { Exam } from "../types";

interface SearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  exams: Exam[];
  onSelectExam: (exam: Exam) => void;
  onNavigateToCategory: (category: string) => void;
}

export const SearchModal: React.FC<SearchModalProps> = ({
  isOpen,
  onClose,
  exams,
  onSelectExam,
  onNavigateToCategory,
}) => {
  const [query, setQuery] = useState("");
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isOpen) {
      setTimeout(() => inputRef.current?.focus(), 50);
    } else {
      setQuery("");
    }
  }, [isOpen]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === "k") {
        e.preventDefault();
        if (isOpen) onClose();
      } else if (e.key === "Escape" && isOpen) {
        onClose();
      }
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const filteredExams = query.trim()
    ? exams.filter(
        (e) =>
          e.name.toLowerCase().includes(query.toLowerCase()) ||
          e.fullName.toLowerCase().includes(query.toLowerCase()) ||
          e.category.toLowerCase().includes(query.toLowerCase()) ||
          e.shortDescription.toLowerCase().includes(query.toLowerCase()) ||
          e.tags.some((t) => t.toLowerCase().includes(query.toLowerCase()))
      )
    : exams.slice(0, 6);

  const categories = Array.from(new Set(exams.map((e) => e.category)));

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-start justify-center p-4 sm:p-6 md:p-20">
      <div
        id="search-modal-container"
        className="w-full max-w-2xl bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden animate-in fade-in zoom-in-95 duration-150"
      >
        {/* Search input field */}
        <div className="relative flex items-center px-4 border-b border-slate-100 bg-slate-50/50">
          <Search className="w-5 h-5 text-slate-400 mr-3 shrink-0" />
          <input
            ref={inputRef}
            id="search-modal-input"
            type="text"
            placeholder="Search exam name (e.g. JEE, UPSC, GATE, NEET, AWS, GRE, Bank PO)..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            className="w-full py-4 bg-transparent text-slate-800 placeholder-slate-400 text-base focus:outline-hidden"
          />
          {query && (
            <button
              onClick={() => setQuery("")}
              className="p-1 hover:bg-slate-200 rounded-md text-slate-400 hover:text-slate-600 mr-2"
            >
              <X className="w-4 h-4" />
            </button>
          )}
          <button
            onClick={onClose}
            className="p-1.5 hover:bg-slate-200 text-slate-500 rounded-lg text-xs font-semibold px-2"
          >
            ESC
          </button>
        </div>

        {/* Quick Category filter chips */}
        <div className="px-4 py-2 bg-slate-50 border-b border-slate-100 flex items-center gap-1.5 overflow-x-auto text-xs">
          <span className="text-slate-400 font-medium shrink-0">Quick Filter:</span>
          {categories.slice(0, 5).map((cat) => (
            <button
              key={String(cat)}
              onClick={() => {
                onNavigateToCategory(String(cat));
                onClose();
              }}
              className="shrink-0 px-2 py-1 bg-white hover:bg-blue-50 hover:text-blue-700 text-slate-600 rounded-md border border-slate-200 transition-colors"
            >
              {String(cat).replace(" Exams", "")}
            </button>
          ))}
        </div>

        {/* Results List */}
        <div className="max-h-96 overflow-y-auto p-2 space-y-1">
          {filteredExams.length > 0 ? (
            filteredExams.map((exam) => (
              <div
                key={exam.id}
                id={`search-result-${exam.id}`}
                onClick={() => {
                  onSelectExam(exam);
                  onClose();
                }}
                className="group flex items-center justify-between p-3 rounded-xl hover:bg-blue-50/80 cursor-pointer transition-colors border border-transparent hover:border-blue-100"
              >
                <div className="flex items-center gap-3 min-w-0">
                  <div className="w-10 h-10 rounded-lg bg-blue-100 text-blue-700 flex items-center justify-center font-bold text-sm shrink-0">
                    {exam.name.slice(0, 3)}
                  </div>
                  <div className="min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="font-semibold text-slate-900 group-hover:text-blue-700 truncate">
                        {exam.name}
                      </span>
                      <span className="text-[11px] px-2 py-0.5 rounded-full bg-slate-100 text-slate-600 font-medium">
                        {exam.category}
                      </span>
                      {exam.isOfficialVerified && (
                        <span className="hidden sm:inline-flex items-center gap-0.5 text-[10px] text-emerald-700 bg-emerald-50 px-1.5 py-0.5 rounded font-medium">
                          <ShieldCheck className="w-3 h-3" /> Official
                        </span>
                      )}
                    </div>
                    <p className="text-xs text-slate-500 truncate mt-0.5">
                      {exam.fullName} • {exam.eligibilityLevel}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2 shrink-0 ml-2">
                  <span className="text-[11px] text-slate-500 hidden md:flex items-center gap-1">
                    <Calendar className="w-3 h-3 text-slate-400" />
                    {exam.upcomingImportantDate.label}: {exam.upcomingImportantDate.date}
                  </span>
                  <ArrowRight className="w-4 h-4 text-slate-400 group-hover:text-blue-600 group-hover:translate-x-0.5 transition-transform" />
                </div>
              </div>
            ))
          ) : (
            <div className="py-12 text-center text-slate-500">
              <Compass className="w-10 h-10 mx-auto text-slate-300 mb-2" />
              <p className="font-medium text-slate-700">No matching exams found</p>
              <p className="text-xs text-slate-400 mt-1">
                Try searching for engineering, medical, government, banking or study abroad tests.
              </p>
            </div>
          )}
        </div>

        {/* Footer shortcuts */}
        <div className="p-3 bg-slate-50 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
          <div className="flex items-center gap-2">
            <Sparkles className="w-3.5 h-3.5 text-indigo-500" />
            <span>EduGuide AI Intelligent Search</span>
          </div>
          <span className="text-[11px] text-slate-400">Click an exam to open complete syllabus, eligibility & guide</span>
        </div>
      </div>
    </div>
  );
};
