import React, { useState } from "react";
import {
  LayoutDashboard,
  Bookmark,
  Calendar,
  Clock,
  BookOpen,
  Sparkles,
  CheckCircle2,
  Bell,
  ArrowRight,
  TrendingUp,
  User,
  ShieldCheck,
  Award,
  ChevronRight,
  Sliders,
  CheckSquare,
  Trash2,
} from "lucide-react";
import { Exam, StudentProfile, StudyPlan, ExamReminder } from "../types";

interface DashboardViewProps {
  exams: Exam[];
  profile: StudentProfile;
  onUpdateProfile: (updated: StudentProfile) => void;
  savedExamIds: string[];
  onToggleSaveExam: (examId: string) => void;
  onSelectExam: (exam: Exam) => void;
  reminders: ExamReminder[];
  onDeleteReminder: (reminderId: string) => void;
  activeStudyPlan: StudyPlan | null;
  onNavigateToTab: (tab: string) => void;
  onLaunchStudyPlannerForExam: (exam: Exam) => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  exams,
  profile,
  onUpdateProfile,
  savedExamIds,
  onToggleSaveExam,
  onSelectExam,
  reminders,
  onDeleteReminder,
  activeStudyPlan,
  onNavigateToTab,
  onLaunchStudyPlannerForExam,
}) => {
  const [editingProfile, setEditingProfile] = useState(false);
  const [name, setName] = useState(profile.name);
  const [educationLevel, setEducationLevel] = useState(profile.educationLevel);
  const [degreeOrBranch, setDegreeOrBranch] = useState(profile.degreeOrBranch);
  const [targetExamsInput, setTargetExamsInput] = useState(profile.targetExams.join(", "));

  const savedExams = exams.filter((e) => savedExamIds.includes(e.id));

  // Matched AI recommendations based on education
  const recommendedForProfile = exams.filter((e) => {
    if (educationLevel.includes("Undergraduate") || educationLevel.includes("B.Tech")) {
      return e.category === "Engineering Exams" || e.category === "Technology Exams" || e.name.includes("GATE") || e.name.includes("UPSC");
    }
    if (educationLevel.includes("12th")) {
      return e.name.includes("JEE") || e.name.includes("NEET") || e.name.includes("NDA");
    }
    return e.trending;
  }).slice(0, 3);

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdateProfile({
      ...profile,
      name,
      educationLevel,
      degreeOrBranch,
      targetExams: targetExamsInput.split(",").map((s) => s.trim()).filter(Boolean),
    });
    setEditingProfile(false);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8 pb-24">
      {/* Header Profile Hero Card */}
      <div className="bg-gradient-to-r from-blue-950 via-slate-900 to-indigo-950 text-white rounded-3xl p-6 sm:p-8 shadow-xl border border-slate-800 flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div className="flex items-start gap-4">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-blue-600 to-indigo-600 flex items-center justify-center text-white text-2xl font-bold font-['Outfit',sans-serif] shadow-lg shrink-0">
            {profile.name.slice(0, 1)}
          </div>
          <div className="space-y-1">
            <div className="flex flex-wrap items-center gap-2">
              <h1 className="text-2xl sm:text-3xl font-extrabold font-['Outfit',sans-serif]">
                Welcome back, {profile.name}!
              </h1>
              <span className="px-2.5 py-0.5 rounded-full bg-blue-500/20 text-blue-300 text-xs font-bold border border-blue-400/30">
                Student Profile Active
              </span>
            </div>
            <p className="text-xs sm:text-sm text-slate-300">
              {profile.educationLevel} • {profile.degreeOrBranch}
            </p>
            <div className="flex flex-wrap items-center gap-2 pt-1">
              <span className="text-[11px] text-slate-400">Targeting:</span>
              {profile.targetExams.map((examName, idx) => (
                <span
                  key={idx}
                  className="px-2 py-0.5 bg-white/10 text-white text-[11px] font-medium rounded-md"
                >
                  {examName}
                </span>
              ))}
            </div>
          </div>
        </div>

        <div className="flex flex-col sm:flex-row items-stretch md:items-center gap-2.5 shrink-0">
          <button
            onClick={() => setEditingProfile(!editingProfile)}
            className="px-4 py-2 bg-white/10 hover:bg-white/20 text-white rounded-xl text-xs font-bold border border-white/20 transition-colors flex items-center justify-center gap-1.5"
          >
            <Sliders className="w-3.5 h-3.5" />
            <span>{editingProfile ? "Cancel Edit" : "Edit Profile"}</span>
          </button>
          <button
            onClick={() => onNavigateToTab("ai-assistant")}
            className="px-4 py-2 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white rounded-xl text-xs font-bold shadow-md transition-all flex items-center justify-center gap-1.5"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>AI Career Consultation</span>
          </button>
        </div>
      </div>

      {/* Edit Profile Drawer Modal if opened */}
      {editingProfile && (
        <form
          onSubmit={handleSaveProfile}
          className="bg-white rounded-2xl border border-slate-200 p-6 shadow-md space-y-4 text-xs animate-in fade-in"
        >
          <div className="flex items-center justify-between pb-2 border-b border-slate-100">
            <h3 className="text-sm font-bold text-slate-900">Update Your Educational Profile</h3>
            <span className="text-[11px] text-slate-400">Tailors AI recommendations and alert filters</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="font-bold text-slate-700 block mb-1">Your Full Name:</label>
              <input
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-800"
              />
            </div>
            <div>
              <label className="font-bold text-slate-700 block mb-1">Education Status:</label>
              <select
                value={educationLevel}
                onChange={(e) => setEducationLevel(e.target.value)}
                className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-800"
              >
                <option value="12th Pass (Science)">12th Pass (Science)</option>
                <option value="Undergraduate (B.Tech / B.E)">Undergraduate (B.Tech / B.E)</option>
                <option value="Graduate (Any Discipline)">Graduate (Any Discipline)</option>
                <option value="Medical Graduate (MBBS)">Medical Graduate (MBBS)</option>
                <option value="Postgraduate (Masters)">Postgraduate (Masters)</option>
              </select>
            </div>
            <div>
              <label className="font-bold text-slate-700 block mb-1">Degree / Specialization:</label>
              <input
                type="text"
                value={degreeOrBranch}
                onChange={(e) => setDegreeOrBranch(e.target.value)}
                className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-800"
              />
            </div>
            <div>
              <label className="font-bold text-slate-700 block mb-1">Target Exams (comma separated):</label>
              <input
                type="text"
                value={targetExamsInput}
                onChange={(e) => setTargetExamsInput(e.target.value)}
                placeholder="e.g. GATE CSE, UPSC IAS, AWS Solutions"
                className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-800"
              />
            </div>
          </div>

          <div className="flex justify-end gap-2 pt-2 border-t border-slate-100">
            <button
              type="button"
              onClick={() => setEditingProfile(false)}
              className="px-3 py-1.5 bg-slate-100 text-slate-700 rounded-lg font-medium"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-1.5 bg-blue-600 text-white rounded-lg font-bold hover:bg-blue-700"
            >
              Save Profile Changes
            </button>
          </div>
        </form>
      )}

      {/* 4 Stat Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-xs font-bold text-slate-600">Saved Exams</span>
            <Bookmark className="w-4 h-4 text-blue-600" />
          </div>
          <div className="text-2xl sm:text-3xl font-extrabold text-slate-900 font-['Outfit',sans-serif] mt-2">
            {savedExamIds.length}
          </div>
          <p className="text-[11px] text-slate-400 mt-1">In your watchlist</p>
        </div>

        <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-xs font-bold text-slate-600">Active Reminders</span>
            <Bell className="w-4 h-4 text-amber-500" />
          </div>
          <div className="text-2xl sm:text-3xl font-extrabold text-slate-900 font-['Outfit',sans-serif] mt-2">
            {reminders.length}
          </div>
          <p className="text-[11px] text-slate-400 mt-1">Scheduled milestone alerts</p>
        </div>

        <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-xs font-bold text-slate-600">Study Roadmap</span>
            <BookOpen className="w-4 h-4 text-indigo-600" />
          </div>
          <div className="text-2xl sm:text-3xl font-extrabold text-slate-900 font-['Outfit',sans-serif] mt-2">
            {activeStudyPlan ? "Active" : "None"}
          </div>
          <p className="text-[11px] text-slate-400 mt-1">
            {activeStudyPlan ? activeStudyPlan.examName : "Generate plan in planner"}
          </p>
        </div>

        <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-xs font-bold text-slate-600">Prep Readiness</span>
            <Award className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="text-2xl sm:text-3xl font-extrabold text-emerald-600 font-['Outfit',sans-serif] mt-2">
            85%
          </div>
          <p className="text-[11px] text-slate-400 mt-1">Tracking syllabus milestones</p>
        </div>
      </div>

      {/* Main Two Column Dashboard Body */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left Column (8 cols): Saved Exams Watchlist + Active Study Plan */}
        <div className="lg:col-span-8 space-y-8">
          {/* Saved Exams Watchlist */}
          <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <span className="p-1.5 rounded-lg bg-blue-50 text-blue-600">
                  <Bookmark className="w-4 h-4" />
                </span>
                <h3 className="text-base font-bold text-slate-900 font-['Outfit',sans-serif]">
                  My Saved Exams Watchlist ({savedExams.length})
                </h3>
              </div>
              <button
                onClick={() => onNavigateToTab("explore")}
                className="text-xs font-semibold text-blue-600 hover:text-blue-800 flex items-center gap-1"
              >
                Explore More <ChevronRight className="w-3.5 h-3.5" />
              </button>
            </div>

            {savedExams.length > 0 ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {savedExams.map((exam) => (
                  <div
                    key={exam.id}
                    className="p-4 rounded-xl border border-slate-200 bg-slate-50/50 hover:bg-blue-50/40 hover:border-blue-200 transition-all flex flex-col justify-between space-y-3"
                  >
                    <div>
                      <div className="flex items-start justify-between">
                        <span className="text-[10px] px-2 py-0.5 rounded font-bold bg-blue-100 text-blue-700">
                          {exam.category}
                        </span>
                        <button
                          onClick={() => onToggleSaveExam(exam.id)}
                          className="text-slate-400 hover:text-rose-600 p-1"
                          title="Remove from saved"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>

                      <h4
                        onClick={() => onSelectExam(exam)}
                        className="text-sm font-bold text-slate-900 hover:text-blue-600 cursor-pointer mt-2"
                      >
                        {exam.name}
                      </h4>
                      <p className="text-[11px] text-slate-500 line-clamp-1">{exam.fullName}</p>
                    </div>

                    <div className="p-2 bg-white rounded-lg border border-slate-100 text-[11px] space-y-1">
                      <div className="flex justify-between">
                        <span className="text-slate-400">Next Milestone:</span>
                        <span className="font-bold text-blue-700">{exam.upcomingImportantDate.date}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-slate-400">Event:</span>
                        <span className="text-slate-700 truncate">{exam.upcomingImportantDate.label}</span>
                      </div>
                    </div>

                    <div className="flex items-center justify-between pt-1 text-xs">
                      <button
                        onClick={() => onSelectExam(exam)}
                        className="text-blue-600 font-bold hover:underline flex items-center gap-0.5"
                      >
                        Complete Profile <ArrowRight className="w-3 h-3" />
                      </button>
                      <button
                        onClick={() => onLaunchStudyPlannerForExam(exam)}
                        className="p-1 text-slate-500 hover:text-blue-600 text-[11px] font-medium"
                      >
                        Study Plan →
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="py-8 text-center text-xs text-slate-500 space-y-2">
                <Bookmark className="w-8 h-8 text-slate-300 mx-auto" />
                <p className="font-medium text-slate-700">No exams bookmarked yet.</p>
                <p className="text-slate-400 max-w-xs mx-auto">
                  Browse the Explore Directory and click the bookmark icon on any exam to monitor its deadlines here.
                </p>
                <button
                  onClick={() => onNavigateToTab("explore")}
                  className="px-3.5 py-1.5 bg-blue-600 text-white rounded-lg font-bold text-xs shadow-xs"
                >
                  Browse Exam Directory
                </button>
              </div>
            )}
          </div>

          {/* Active Study Plan Snapshot */}
          <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <span className="p-1.5 rounded-lg bg-indigo-50 text-indigo-600">
                  <BookOpen className="w-4 h-4" />
                </span>
                <h3 className="text-base font-bold text-slate-900 font-['Outfit',sans-serif]">
                  Active Preparation Roadmap
                </h3>
              </div>
              <button
                onClick={() => onNavigateToTab("planner")}
                className="text-xs font-semibold text-blue-600 hover:text-blue-800 flex items-center gap-1"
              >
                {activeStudyPlan ? "Open Full Planner" : "Create Plan"} <ChevronRight className="w-3.5 h-3.5" />
              </button>
            </div>

            {activeStudyPlan ? (
              <div className="space-y-4">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 p-3.5 bg-blue-50/60 rounded-xl border border-blue-100">
                  <div>
                    <span className="text-xs font-bold text-blue-900 block">
                      {activeStudyPlan.examName} ({activeStudyPlan.timeframe})
                    </span>
                    <span className="text-[11px] text-blue-700">
                      Capacity: {activeStudyPlan.dailyStudyHours}
                    </span>
                  </div>
                  <button
                    onClick={() => onNavigateToTab("planner")}
                    className="px-3 py-1 bg-blue-600 text-white rounded-lg text-xs font-semibold self-start sm:self-auto"
                  >
                    View Daily Routine
                  </button>
                </div>

                {/* Phased Roadmap preview */}
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
                  {activeStudyPlan.phases.map((p, idx) => (
                    <div key={idx} className="p-3 bg-slate-50 rounded-xl border border-slate-100">
                      <span className="text-[10px] font-bold text-indigo-700 block uppercase">{p.phase}</span>
                      <span className="font-bold text-slate-900 block mt-0.5">{p.title}</span>
                      <span className="text-[11px] text-slate-500 mt-1 block line-clamp-1">{p.milestone}</span>
                    </div>
                  ))}
                </div>
              </div>
            ) : (
              <div className="py-6 text-center text-xs text-slate-500 space-y-2">
                <p>No active study schedule created yet.</p>
                <button
                  onClick={() => onNavigateToTab("planner")}
                  className="px-4 py-2 bg-gradient-to-r from-blue-600 to-indigo-600 text-white rounded-xl font-bold shadow-xs"
                >
                  Generate AI Study Roadmap
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Right Column (4 cols): Deadlines Radar + Tailored AI Recommendations */}
        <div className="lg:col-span-4 space-y-8">
          {/* Upcoming Deadlines & Reminders */}
          <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <span className="p-1 rounded-lg bg-rose-50 text-rose-600">
                  <Clock className="w-4 h-4" />
                </span>
                <h3 className="text-sm font-bold text-slate-900 font-['Outfit',sans-serif]">
                  Upcoming Milestones Radar
                </h3>
              </div>
              <button
                onClick={() => onNavigateToTab("timeline")}
                className="text-xs text-blue-600 font-semibold"
              >
                Timeline →
              </button>
            </div>

            {reminders.length > 0 ? (
              <div className="space-y-2.5">
                {reminders.map((rem) => (
                  <div
                    key={rem.id}
                    className="p-3 bg-slate-50 rounded-xl border border-slate-200/80 flex items-start justify-between gap-2 text-xs"
                  >
                    <div>
                      <h4 className="font-bold text-slate-900">{rem.eventTitle}</h4>
                      <div className="flex items-center gap-2 mt-1 text-[11px] text-slate-500">
                        <span className="font-mono text-blue-700 font-bold">{rem.eventDate}</span>
                        <span>•</span>
                        <span>Alert active</span>
                      </div>
                    </div>
                    <button
                      onClick={() => onDeleteReminder(rem.id)}
                      className="p-1 text-slate-400 hover:text-rose-600"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))}
              </div>
            ) : (
              <div className="py-4 text-center text-xs text-slate-400">
                No active milestone reminders set.
              </div>
            )}
          </div>

          {/* AI Recommendations Tailored for Student */}
          <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs space-y-4">
            <div className="flex items-center gap-2 pb-2 border-b border-slate-100">
              <Sparkles className="w-4 h-4 text-indigo-600" />
              <h3 className="text-sm font-bold text-slate-900 font-['Outfit',sans-serif]">
                Recommended For Your Degree
              </h3>
            </div>

            <div className="space-y-3">
              {recommendedForProfile.map((exam) => (
                <div
                  key={exam.id}
                  onClick={() => onSelectExam(exam)}
                  className="p-3 bg-slate-50 hover:bg-blue-50/60 rounded-xl border border-slate-200/70 cursor-pointer transition-colors space-y-1"
                >
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-xs text-slate-900">{exam.name}</span>
                    <span className="text-[10px] text-emerald-700 bg-emerald-50 px-1.5 py-0.2 rounded font-bold">
                      Eligible
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-500 line-clamp-1">{exam.fullName}</p>
                  <div className="text-[11px] text-blue-600 font-semibold pt-1 flex items-center justify-between">
                    <span>{exam.upcomingImportantDate.date}</span>
                    <span>View Details →</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
