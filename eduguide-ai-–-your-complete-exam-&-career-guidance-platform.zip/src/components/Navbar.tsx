import React, { useState } from "react";
import {
  Compass,
  Calendar,
  BookOpen,
  Video,
  Sparkles,
  LayoutDashboard,
  Search,
  Bell,
  Bookmark,
  Menu,
  X,
  GraduationCap,
  ChevronRight,
  ShieldCheck,
} from "lucide-react";
import { ExamCategory } from "../types";

interface NavbarProps {
  currentTab: string;
  setCurrentTab: (tab: string) => void;
  savedExamsCount: number;
  unreadNotificationsCount: number;
  onOpenSearch: () => void;
  onOpenNotifications: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentTab,
  setCurrentTab,
  savedExamsCount,
  unreadNotificationsCount,
  onOpenSearch,
  onOpenNotifications,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navItems = [
    { id: "home", label: "Home", icon: GraduationCap },
    { id: "explore", label: "Explore Exams", icon: Compass },
    { id: "timeline", label: "Exam Timeline", icon: Calendar },
    { id: "planner", label: "Study Planner", icon: BookOpen },
    { id: "learning", label: "Learning Hub", icon: Video },
    { id: "ai-assistant", label: "AI Assistant", icon: Sparkles, highlight: true },
    { id: "dashboard", label: "Dashboard", icon: LayoutDashboard },
  ];

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200/80 shadow-xs">
      {/* Top micro announcement bar */}
      <div className="bg-gradient-to-r from-blue-900 via-indigo-900 to-blue-900 text-white text-xs py-1.5 px-4">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="bg-indigo-500/30 text-indigo-200 px-2 py-0.5 rounded text-[11px] font-medium border border-indigo-400/30">
              Official Sync
            </span>
            <span className="text-slate-200 truncate hidden sm:inline">
              Verified notification timelines & official portal guidance for 2026-2027 competitive cycles.
            </span>
            <span className="text-slate-200 sm:hidden truncate">
              Verified 2026-27 exam timelines & guidance.
            </span>
          </div>
          <div className="flex items-center gap-3 text-xs font-medium shrink-0">
            <span className="text-slate-300 flex items-center gap-1">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
              Verified Portals
            </span>
          </div>
        </div>
      </div>

      {/* Main navigation container */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 sm:h-18">
          {/* Brand Logo */}
          <div
            id="brand-logo"
            onClick={() => {
              setCurrentTab("home");
              setMobileMenuOpen(false);
            }}
            className="flex items-center gap-3 cursor-pointer group"
          >
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-blue-600 to-indigo-600 flex items-center justify-center text-white shadow-md shadow-blue-500/20 group-hover:scale-105 transition-transform duration-200">
              <GraduationCap className="w-6 h-6" />
            </div>
            <div className="flex flex-col">
              <div className="flex items-center gap-1.5">
                <span className="text-xl font-bold tracking-tight text-slate-900 font-['Outfit',sans-serif]">
                  EduGuide<span className="text-blue-600">AI</span>
                </span>
                <span className="px-1.5 py-0.5 text-[10px] font-bold bg-blue-50 text-blue-700 rounded-md border border-blue-200">
                  PRO
                </span>
              </div>
              <span className="text-[11px] text-slate-500 hidden md:block tracking-wide">
                One Platform. Every Exam. Complete Guidance.
              </span>
            </div>
          </div>

          {/* Desktop Navigation Links */}
          <nav className="hidden lg:flex items-center gap-1 xl:gap-2">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = currentTab === item.id;
              return (
                <button
                  key={item.id}
                  id={`nav-link-${item.id}`}
                  onClick={() => setCurrentTab(item.id)}
                  className={`flex items-center gap-1.5 px-3 py-2 rounded-lg text-sm font-medium transition-all duration-150 ${
                    isActive
                      ? "bg-blue-50 text-blue-700 font-semibold shadow-xs"
                      : "text-slate-600 hover:text-slate-900 hover:bg-slate-100/80"
                  } ${
                    item.highlight
                      ? "relative bg-gradient-to-r from-indigo-50 to-blue-50 text-indigo-700 border border-indigo-200/60 hover:border-indigo-300"
                      : ""
                  }`}
                >
                  <Icon className={`w-4 h-4 ${isActive ? "text-blue-600" : item.highlight ? "text-indigo-600" : "text-slate-500"}`} />
                  <span>{item.label}</span>
                  {item.highlight && (
                    <span className="flex h-2 w-2 relative">
                      <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-indigo-400 opacity-75"></span>
                      <span className="relative inline-flex rounded-full h-2 w-2 bg-indigo-600"></span>
                    </span>
                  )}
                </button>
              );
            })}
          </nav>

          {/* Right Action Icons */}
          <div className="flex items-center gap-2 sm:gap-3">
            {/* Quick Search Button */}
            <button
              id="global-search-btn"
              onClick={onOpenSearch}
              className="flex items-center gap-2 px-3 py-1.5 text-xs sm:text-sm text-slate-500 bg-slate-100 hover:bg-slate-200/80 rounded-lg border border-slate-200 transition-colors"
              title="Search competitive exams (Press / or click)"
            >
              <Search className="w-4 h-4 text-slate-400" />
              <span className="hidden sm:inline">Search exams...</span>
              <kbd className="hidden sm:inline-block px-1.5 py-0.5 text-[10px] font-semibold text-slate-400 bg-white rounded border border-slate-200">
                ⌘K
              </kbd>
            </button>

            {/* Saved Exams Bookmark shortcut */}
            <button
              id="saved-exams-shortcut-btn"
              onClick={() => setCurrentTab("dashboard")}
              className="relative p-2 text-slate-600 hover:text-blue-600 hover:bg-slate-100 rounded-lg transition-colors"
              title="View Saved Exams in Dashboard"
            >
              <Bookmark className="w-5 h-5" />
              {savedExamsCount > 0 && (
                <span className="absolute top-1 right-1 w-4 h-4 text-[10px] font-bold bg-blue-600 text-white rounded-full flex items-center justify-center">
                  {savedExamsCount}
                </span>
              )}
            </button>

            {/* Notifications Bell */}
            <button
              id="notifications-btn"
              onClick={onOpenNotifications}
              className="relative p-2 text-slate-600 hover:text-blue-600 hover:bg-slate-100 rounded-lg transition-colors"
              title="Don't Miss Any Exam Alerts"
            >
              <Bell className="w-5 h-5" />
              {unreadNotificationsCount > 0 && (
                <span className="absolute top-1 right-1 w-4 h-4 text-[10px] font-bold bg-rose-600 text-white rounded-full flex items-center justify-center animate-pulse">
                  {unreadNotificationsCount}
                </span>
              )}
            </button>

            {/* Mobile Menu Toggle */}
            <button
              id="mobile-menu-toggle"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="lg:hidden p-2 text-slate-600 hover:text-slate-900 rounded-lg hover:bg-slate-100"
              aria-label="Toggle menu"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile dropdown menu */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-white border-b border-slate-200 px-4 pt-2 pb-4 space-y-1 shadow-lg animate-in slide-in-from-top-2 duration-200">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = currentTab === item.id;
            return (
              <button
                key={item.id}
                id={`mobile-nav-${item.id}`}
                onClick={() => {
                  setCurrentTab(item.id);
                  setMobileMenuOpen(false);
                }}
                className={`w-full flex items-center justify-between px-3 py-2.5 rounded-lg text-sm font-medium ${
                  isActive
                    ? "bg-blue-50 text-blue-700 font-semibold"
                    : "text-slate-700 hover:bg-slate-100"
                }`}
              >
                <div className="flex items-center gap-3">
                  <Icon className={`w-5 h-5 ${isActive ? "text-blue-600" : "text-slate-500"}`} />
                  <span>{item.label}</span>
                </div>
                <ChevronRight className="w-4 h-4 text-slate-400" />
              </button>
            );
          })}

          <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500 px-3">
            <span>EduGuide AI v2.4 • 2026-2027</span>
            <span className="text-blue-600 font-medium">Verified Sources</span>
          </div>
        </div>
      )}
    </header>
  );
};
