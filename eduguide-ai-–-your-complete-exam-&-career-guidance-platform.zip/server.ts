import express from "express";
import path from "path";
import { fileURLToPath } from "url";
import dotenv from "dotenv";
import { GoogleGenAI } from "@google/genai";
import { createServer as createViteServer } from "vite";

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = 3000;

app.use(express.json());

// Initialize Google GenAI client lazily if key exists
let aiClient: GoogleGenAI | null = null;
function getAI(): GoogleGenAI | null {
  if (!aiClient && process.env.GEMINI_API_KEY) {
    aiClient = new GoogleGenAI({
      apiKey: process.env.GEMINI_API_KEY,
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build",
        },
      },
    });
  }
  return aiClient;
}

// Health check endpoint
app.get("/api/health", (req, res) => {
  res.json({ status: "ok", timestamp: new Date().toISOString() });
});

// AI Guidance Endpoint
app.post("/api/ai/guidance", async (req, res) => {
  try {
    const { educationLevel, degreeOrBranch, interests, careerGoals, additionalNotes } = req.body;
    const ai = getAI();

    if (!ai) {
      // Fallback smart structured guidance if API key is not yet configured
      return res.json({
        source: "fallback",
        recommendations: [
          {
            examName: degreeOrBranch?.toLowerCase().includes("tech") || degreeOrBranch?.toLowerCase().includes("eng") ? "GATE (Graduate Aptitude Test in Engineering)" : "UPSC Civil Services Examination",
            category: degreeOrBranch?.toLowerCase().includes("tech") ? "Engineering Exams" : "Government Exams",
            matchScore: 96,
            whyRelevant: `Matches your background in ${degreeOrBranch || educationLevel} and your goal to achieve ${careerGoals || "career excellence"}.`,
            eligibilityStatus: "Fully Eligible based on provided criteria",
            suggestedTimeline: "6 - 12 Months Structured Preparation",
            careerScope: "Top PSU executive roles, M.Tech/Ph.D. in IISc/IITs, High job security and prestigious pay scale.",
            keyHighlights: ["Direct PSU recruitment through score", "Global acceptance in NTU & NUS", "Valid for 3 years"]
          },
          {
            examName: "ISRO / DRDO Scientist Technical Recruitment",
            category: "Technology & Research Exams",
            matchScore: 92,
            whyRelevant: `Ideal for candidates interested in technical research and cutting-edge engineering projects.`,
            eligibilityStatus: "First class degree qualification required",
            suggestedTimeline: "4 - 8 Months",
            careerScope: "Scientist 'SC' / Research Officer in premier national defense and space missions.",
            keyHighlights: ["Core technical interviews", "High innovation environment", "Central Govt Group-A Perks"]
          },
          {
            examName: "CAT / Higher Management Entrance (IIMs)",
            category: "Management & Tech Leadership",
            matchScore: 88,
            whyRelevant: `Allows transition into product management, consulting, and techno-managerial executive roles.`,
            eligibilityStatus: "Graduate with minimum 50% aggregate",
            suggestedTimeline: "6 - 9 Months",
            careerScope: "Leadership roles in global Fortune 500 enterprises and consulting firms.",
            keyHighlights: ["Analytical & verbal aptitude focus", "High average placement packages", "Extensive alumni network"]
          }
        ],
        pathways: [
          {
            title: "Core Technical & Research Specialization",
            description: "Direct entry into PSU leadership, R&D labs, and master's specializations.",
            steps: [
              "Master standard undergraduate core syllabus topics with high weightage",
              "Practice previous 10 years question papers (PYQs) under timed test conditions",
              "Target top percentile in GATE/Technical exam for direct PSU interview calls",
              "Join premier PSU or IISc/IIT higher research program"
            ]
          },
          {
            title: "Techno-Administrative / Public Service Pathway",
            description: "Leverage analytical problem-solving in top governmental and administrative positions.",
            steps: [
              "Build strong grasp of General Studies, Current Affairs, and Optional Subject",
              "Develop consistent daily editorial reading and answer-writing practice",
              "Clear Prelims, followed by rigorous Mains mock tests and personality evaluation"
            ]
          }
        ],
        immediateNextSteps: [
          "Download official syllabus for your target exam and mark high-weightage topics",
          "Set up your custom daily study planner with 3-4 focused hours every day",
          "Add critical application registration and exam dates to your EduGuide AI Timeline",
          "Attempt one full-length baseline diagnostic test to gauge current preparation standing"
        ],
        expertAdvice: "Consistency in revision and analyzing mock test mistakes is 3x more effective than merely reading theory. Focus on concept application and previous year trends."
      });
    }

    const prompt = `You are the chief educational counselor and competitive examination expert for EduGuide AI.
Analyze the following student profile and generate a comprehensive, highly personalized exam & career guidance roadmap in valid JSON.

Student Profile:
- Education Level: ${educationLevel || "Undergraduate"}
- Degree / Branch: ${degreeOrBranch || "Not specified"}
- Core Interests: ${interests || "Competitive examinations & career growth"}
- Career Goals: ${careerGoals || "High-growth rewarding career"}
- Additional Notes: ${additionalNotes || "None"}

Requirements:
Return ONLY valid JSON matching this exact structure:
{
  "recommendations": [
    {
      "examName": "Full Exam Name",
      "category": "Exam Category",
      "matchScore": 95,
      "whyRelevant": "Detailed explanation of why this exam matches their education, interests, and aspirations.",
      "eligibilityStatus": "Detailed eligibility match explanation",
      "suggestedTimeline": "Preparation duration",
      "careerScope": "Roles, salary benchmarks, and growth trajectory",
      "keyHighlights": ["Highlight 1", "Highlight 2", "Highlight 3"]
    }
  ],
  "pathways": [
    {
      "title": "Pathway Name",
      "description": "Short explanation",
      "steps": ["Step 1", "Step 2", "Step 3", "Step 4"]
    }
  ],
  "immediateNextSteps": ["Actionable step 1", "Actionable step 2", "Actionable step 3", "Actionable step 4"],
  "expertAdvice": "A paragraph of motivating, realistic, and strategic advice from an expert exam mentor."
}`;

    const response = await ai.models.generateContent({
      model: "gemini-3.7-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
      },
    });

    const text = response.text || "{}";
    const parsedData = JSON.parse(text);
    return res.json({ source: "gemini", ...parsedData });
  } catch (error: any) {
    console.error("AI Guidance error:", error);
    res.status(500).json({ error: "Failed to generate AI guidance. Please try again." });
  }
});

// AI Study Plan Generator Endpoint
app.post("/api/ai/study-plan", async (req, res) => {
  try {
    const { examName, targetExamDate, monthsAvailable, dailyHours, currentPrepLevel, weakAreas } = req.body;
    const ai = getAI();

    if (!ai) {
      // Fallback robust study plan
      return res.json({
        source: "fallback",
        planTitle: `${examName} Personalized Mastery Roadmap`,
        overview: `A structured ${monthsAvailable || 6}-month blueprint allocating ${dailyHours || 4} hours/day with phased milestones, high-yield topic focus, and progressive mock testing.`,
        dailySchedule: [
          { timeSlot: "Slot 1 (Morning - 1.5 hrs)", focus: "Core Conceptual Learning & New Theory", activity: "High-concentration topics from syllabus" },
          { timeSlot: "Slot 2 (Afternoon/Evening - 1.5 hrs)", focus: "Problem Solving & Numerical Practice", activity: "Subject-wise questions & previous year questions (PYQs)" },
          { timeSlot: "Slot 3 (Night - 1 hr)", focus: "Daily Active Recall & Quick Formula Revision", activity: "Flashcards, error log review, and short timed quiz" }
        ],
        phases: [
          {
            phaseName: "Phase 1: Foundation & Core Syllabus Coverage",
            duration: "First 40% of timeframe",
            objective: "Complete 100% of high-weightage chapters with fundamental conceptual clarity.",
            keyTasks: ["Comprehensive syllabus chapter notes", "Basic & intermediate question sets", "Weekly chapter-end mini quizzes"]
          },
          {
            phaseName: "Phase 2: Advanced Problem Solving & PYQ Deep Dive",
            duration: "Next 35% of timeframe",
            objective: "Master previous 10-15 years exam papers and tackle weak areas like " + (weakAreas || "complex problem types") + ".",
            keyTasks: ["Sectional timed mock tests", "Error analysis notebook maintenance", "Formula and reaction cheat-sheet creation"]
          },
          {
            phaseName: "Phase 3: Full-Length Mocks & Speed-Accuracy Calibration",
            duration: "Final 25% of timeframe",
            objective: "Simulate real exam room atmosphere and refine negative marking avoidance strategies.",
            keyTasks: ["Full-length mock exam every 3 days", "In-depth post-exam gap rectification", "Rapid mind-map revisions"]
          }
        ],
        weeklyMilestones: [
          { week: "Weeks 1 - 4", goal: "Complete foundational modules & establish unbroken daily study routine" },
          { week: "Weeks 5 - 8", goal: "Finish 60% of syllabus; begin sectional test series" },
          { week: "Weeks 9 - 16", goal: "Complete 100% syllabus; solve 500+ PYQs across core topics" },
          { week: "Final Month", goal: "Take 10 full-length mocks; achieve target score consistency" }
        ],
        highYieldTopics: [
          "High-frequency recurring topics from previous 5 years papers",
          "Foundational theory that connects multiple inter-disciplinary questions",
          "Calculative/Numerical sections with direct formula application"
        ],
        revisionStrategy: "Follow the 1-3-7-30 Spaced Repetition rule: Review notes after 24 hours, 3 days, 1 week, and 1 month to cement long-term memory."
      });
    }

    const prompt = `You are a world-class academic mentor specializing in competitive examinations.
Create an actionable, high-efficiency, personalized study planner for the student preparing for ${examName}.

Parameters:
- Target Exam: ${examName}
- Target Date: ${targetExamDate || "In 6 months"}
- Available Months: ${monthsAvailable || 6}
- Daily Study Commitment: ${dailyHours || 4} hours per day
- Current Level: ${currentPrepLevel || "Intermediate"}
- Weak / Challenging Areas: ${weakAreas || "General speed and accuracy"}

Return ONLY valid JSON matching this exact structure:
{
  "planTitle": "Title of the study plan",
  "overview": "Summary of approach and strategy",
  "dailySchedule": [
    { "timeSlot": "Slot label & duration", "focus": "Primary focus area", "activity": "Specific task" }
  ],
  "phases": [
    {
      "phaseName": "Phase Title",
      "duration": "Duration (e.g. Weeks 1-4)",
      "objective": "Main milestone",
      "keyTasks": ["Task 1", "Task 2", "Task 3"]
    }
  ],
  "weeklyMilestones": [
    { "week": "Week range", "goal": "Specific measurable milestone" }
  ],
  "highYieldTopics": ["Topic 1", "Topic 2", "Topic 3", "Topic 4", "Topic 5"],
  "revisionStrategy": "Detailed explanation of spaced repetition and revision tactics."
}`;

    const response = await ai.models.generateContent({
      model: "gemini-3.7-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
      },
    });

    const text = response.text || "{}";
    const parsedData = JSON.parse(text);
    return res.json({ source: "gemini", ...parsedData });
  } catch (error: any) {
    console.error("Study Plan error:", error);
    res.status(500).json({ error: "Failed to generate study plan." });
  }
});

// AI Counselor Chat Endpoint
app.post("/api/ai/chat", async (req, res) => {
  try {
    const { message, examContext, chatHistory } = req.body;
    const ai = getAI();

    if (!ai) {
      return res.json({
        reply: `Here is guidance regarding ${examContext ? examContext.name : "your competitive exam inquiry"}: 

1. **Official Verification**: Always verify notifications and eligibility on the conducting body's official portal.
2. **Strategy**: Break down your syllabus into high-yield, moderate, and foundational chapters.
3. **Practice**: Allocate 40% time to concepts and 60% time to active question solving and PYQs.

Feel free to specify your educational background or exact doubt for deeper tactical advice!`
      });
    }

    const systemPrompt = `You are EduGuide AI's Senior Exam & Career Mentor.
You provide accurate, realistic, highly structured, and empathetic guidance to students preparing for competitive exams (Engineering, Medical, Civil Services, Banking, Defense, Railways, Study Abroad, and Tech certifications).
Be concise, clear, and actionable. Use markdown bullet points and bold highlights for readability.
If the student asks about a specific exam, reference accurate eligibility norms, syllabus structure, and preparation strategies.
Always remind students to cross-verify specific cutoff and eligibility details with the official conducting body portal.`;

    const contents = [
      ...(Array.isArray(chatHistory) ? chatHistory.map((m: any) => ({
        role: m.role === "assistant" ? "model" : "user",
        parts: [{ text: m.content }]
      })) : []),
      {
        role: "user",
        parts: [{ text: `${examContext ? `[Context Exam: ${examContext.name} (${examContext.category})] ` : ""}${message}` }]
      }
    ];

    const response = await ai.models.generateContent({
      model: "gemini-3.7-flash",
      contents: contents as any,
      config: {
        systemInstruction: systemPrompt,
        temperature: 0.7,
      },
    });

    return res.json({ reply: response.text });
  } catch (error: any) {
    console.error("AI Chat error:", error);
    res.status(500).json({ error: "Unable to process AI chat message." });
  }
});

// Vite middleware in dev or static serving in prod
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`EduGuide AI Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
